/** @type {import('next').NextConfig} */

const nextConfig = {
  reactStrictMode: false,
  pageExtensions: ['page.tsx', 'api.ts', 'mw.ts'],
  i18n: {
    locales: ['en'],
    defaultLocale: 'en',
  },
  images: {
    remotePatterns: [{ protocol: 'https', hostname: 'emsobject.oss-me-east-1.aliyuncs.com' }],
  },
  transpilePackages: ['@mui/x-charts'],
  // TODO: udpate it
  async redirects() {
    return [{ source: '/', destination: '/auth/login', permanent: true }]
  },
}

export default nextConfig

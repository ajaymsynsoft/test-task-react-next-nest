import toast from 'react-hot-toast'
import { useEffect, useState } from 'react'
import { initializeApp } from 'firebase/app'
import { teal } from '@mui/material/colors'
import { MdClose, MdNotificationsActive } from 'react-icons/md'
import { Avatar, Box, IconButton, Stack, Typography } from '@mui/material'
import { getMessaging, getToken, NotificationPayload, onMessage } from 'firebase/messaging'

import { useReduxSelector } from './redux.hook'
import { useUpdateFcmTokenMutation } from '@/redux/api/user.api'

export function useFcm() {
  const [token, setToken] = useState('')
  const { profile, isLoggedIn } = useReduxSelector((state) => state.layout)
  const [updateFcmToken] = useUpdateFcmTokenMutation()

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker
        .register('/firebase-messaging-sw.js', { scope: '/firebase-cloud-messaging-push-scope' })
        .then((registration) => {
          if (isLoggedIn) {
            retrieveToken()
            const messaging = getMessaging(firebaseApp)
            const unsubscribe = onMessage(messaging, ({ notification }) => {
              showNotification(notification)
            })
            return () => {
              unsubscribe()
            }
          }
        })
        .catch((error) => {
          console.error('Service Worker registration failed:\n\n', error)
        })
    }
  }, [isLoggedIn])

  useEffect(() => {
    if (token && isLoggedIn && profile.fcmToken !== token) {
      updateFcmToken({ userId: profile.id, fcmToken: token })
    }
  }, [isLoggedIn, token])

  const retrieveToken = async () => {
    try {
      const messaging = getMessaging(firebaseApp)
      const permission = await Notification.requestPermission()

      if (permission === 'granted') {
        const token = await getToken(messaging, { vapidKey: process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY })
        setToken(token)
      }
    } catch (error) {
      console.log('An error occurred while retrieving token:\n\n', error)
    }
  }

  const showNotification = (notification: NotificationPayload | undefined) => {
    if (!notification) return

    const audio = new Audio('/audios/notification.mp3')
    audio.play().catch((error) => {
      console.error('Error playing audio:', error)
    })

    toast(
      (t) => (
        <Stack direction="row" sx={{ gap: 1.5, alignItems: 'start', mx: -1 }}>
          <Avatar sx={{ color: teal['500'], bgcolor: teal['50'] }} src={notification.icon}>
            <MdNotificationsActive />
          </Avatar>
          <Stack gap={0.5} flex={1}>
            {notification.title && <Typography variant="subtitle">{notification.title}</Typography>}
            {notification.body && <Typography whiteSpace="pre-wrap" dangerouslySetInnerHTML={{ __html: notification.body }} />}
            {notification.image && <Box component="img" alt="notification image" src={notification.image} sx={{ width: 1, borderRadius: 1, border: 1, borderColor: 'divider', mt: 1 }} />}
          </Stack>
          <IconButton onClick={(_) => toast.dismiss(t.id)}>
            <MdClose />
          </IconButton>
        </Stack>
      ),
      {
        duration: 86_400_000,
        position: 'top-center',
      },
    )
  }
}

const firebaseApp = initializeApp({
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID,
})

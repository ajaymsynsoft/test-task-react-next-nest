export type DisplayPriceProps = {
  price: string | number
  code?: string
}

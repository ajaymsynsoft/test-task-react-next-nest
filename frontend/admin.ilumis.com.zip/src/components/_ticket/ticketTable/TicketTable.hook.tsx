import Link from 'next/link'
import { Button, Chip, Link as MuiLink } from '@mui/material'
import { GridColDef } from '@mui/x-data-grid'
import { RiQuestionAnswerLine } from 'react-icons/ri'

import { TicketDTO } from '@/dto'
import { formatToTitleCase, getStatusColor } from '@/utils'
import { TicketTableProps } from './TicketTable.type'

export const useColumns = ({ onClickChat }: Pick<TicketTableProps, 'onClickChat'>) => {
  const columns: GridColDef<TicketDTO>[] = [
    {
      field: 'id',
      headerName: 'ID',
      sortable: false,
      minWidth: 85,
      width: 85,
      renderCell: ({ row }) => <MuiLink {...(onClickChat ? { onClick: () => onClickChat(row) } : { component: Link, href: `/dashboard/tickets/${row.id}` })}>#{row.id}</MuiLink>,
    },
    {
      field: 'subject',
      headerName: 'Subject',
      sortable: false,
      minWidth: 300,
    },
    {
      field: 'message',
      headerName: 'Message',
      sortable: false,
      minWidth: 250,
      flex: 1,
    },
    {
      field: 'status',
      headerName: 'Status',
      sortable: false,
      minWidth: 100,
      renderCell: (params) => <Chip label={formatToTitleCase(params.value)} variant="outlined" color={getStatusColor(params.value)} />,
    },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      minWidth: 115,
      display: 'flex',
      renderCell: ({ row }) => (
        <Button size="small" startIcon={<RiQuestionAnswerLine />} {...(onClickChat ? { onClick: () => onClickChat(row) } : { component: Link, href: `/dashboard/tickets/${row.id}` })}>
          Chat
        </Button>
      ),
    },
  ]

  return columns
}

import { DataGrid } from '@mui/x-data-grid'

import { usePagination } from '@/hooks'
import { TicketTableProps } from './TicketTable.type'
import { useColumns } from './TicketTable.hook'
import { useRouter } from 'next/router'

export default function TicketTable({ data, loading, onClickChat }: TicketTableProps) {
  const router = useRouter()
  const columns = useColumns({ onClickChat })
  const { paginationModel, setPaginationModel } = usePagination()

  return (
    <>
      <DataGrid loading={loading} columns={columns} rowCount={data?.totalCount || 0} rows={data.list} paginationModel={paginationModel} onPaginationModelChange={setPaginationModel} />
    </>
  )
}

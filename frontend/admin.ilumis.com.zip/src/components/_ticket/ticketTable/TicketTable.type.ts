import { TicketDTO } from '@/dto'
import { PaginationApiResponse } from '@/types'

export type TicketTableProps = {
  data: PaginationApiResponse<TicketDTO>
  loading: boolean
  onClickChat?: (data: TicketDTO) => void
}

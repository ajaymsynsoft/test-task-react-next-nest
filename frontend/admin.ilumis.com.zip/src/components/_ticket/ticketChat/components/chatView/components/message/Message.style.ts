import { Style } from '@/types/Style.type'

export const style: Style = {
  root: {
    gap: 1.5,
    maxWidth: 'max(50%, 275px)',
  },
  messageBox: {
    bgcolor: 'background.bg2',
    p: 1.5,
    borderRadius: 1,
    wordBreak: 'break-word',
  },
  date: {
    whiteSpace: 'nowrap',
  },
  header: {
    gap: 2,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
}

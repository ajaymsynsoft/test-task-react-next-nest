import { Style } from '@/types/Style.type'

export const style: Style = {
  root: {
    overflow: 'auto',
    flex: 1,
    display: 'flex',
    pt: 2,
    pb: 1,
    position: 'relative',
  },
  loader: {
    position: 'absolute',
    top: 'calc(50% - 20px)',
    left: 'calc(50% - 20px)',
  },
}

import { useEffect, useRef } from 'react'
import { CircularProgress, Container, Stack } from '@mui/material'

import Message from './components/message/Message.component'
import Scrollbar from '@/components/scrollbar/Scrollbar.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { style } from './ChatView.style'
import { ChatViewProps } from './ChatView.type'
import { useReduxSelector } from '@/hooks'

export default function ChatView({ data, loading, error }: ChatViewProps) {
  const rootRef = useRef<any>()
  const isMounted = useRef(false)
  const { role } = useReduxSelector((state) => state.layout.profile)
  const isCustomer = role === 'customer'

  useEffect(() => {
    const scrollbar = rootRef.current.getScrollElement()
    scrollbar.scrollTo({ top: scrollbar.scrollHeight, behavior: isMounted.current ? 'smooth' : 'auto' })
    if (!loading) isMounted.current = true
  }, [data])

  return (
    <Scrollbar sx={style.root} ref={rootRef}>
      <Container>
        {loading ? (
          <CircularProgress size={40} sx={style.loader} />
        ) : (
          <RenderContent loading={loading} error={error}>
            <Stack gap={2.5}>{data?.map((item, index) => <Message data={item} side={isCustomer === (item.user.role === 'customer') ? 'right' : 'left'} key={index} />)}</Stack>
          </RenderContent>
        )}
      </Container>
    </Scrollbar>
  )
}

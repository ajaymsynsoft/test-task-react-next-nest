import { TicketChatProps } from '../../TicketChat.type'

export type ChatViewProps = TicketChatProps

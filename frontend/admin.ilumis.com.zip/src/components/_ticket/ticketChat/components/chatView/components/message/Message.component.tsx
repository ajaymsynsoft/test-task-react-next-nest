import moment from 'moment'
import { Avatar, Stack, Typography, alpha } from '@mui/material'

import { MessageProps } from './Message.type'
import { formatToTitleCase } from '@/utils'
import { style } from './Message.style'

export default function Message({ data, side }: MessageProps) {
  const role = data.user.role
  const isLeftSide = side === 'left'

  return (
    <Stack direction={isLeftSide ? 'row' : 'row-reverse'} sx={{ ...style.root, ml: isLeftSide ? undefined : 'auto' }}>
      <Avatar />
      <Stack gap={0.5} overflow="hidden">
        <Stack sx={style.header} direction={isLeftSide ? 'row' : 'row-reverse'}>
          <Typography variant="subtitle" noWrap>
            {role === 'admin' || role === 'superAdmin' ? formatToTitleCase(role) : `${data.user.firstName} ${data.user.lastName}`}
          </Typography>
          <Typography variant="body2" sx={style.date}>
            {moment(data.createdAt).calendar(null, { sameElse: 'MMM DD, YYYY' })}
          </Typography>
        </Stack>
        <Stack
          sx={{
            ...style.messageBox,
            bgcolor: (theme) => (isLeftSide ? 'background.bg2' : alpha(theme.palette.primary.main, 0.1)),
          }}
        >
          <Typography component="pre">{role === 'customer' ? data.message : data.replyMessage}</Typography>
        </Stack>
      </Stack>
    </Stack>
  )
}

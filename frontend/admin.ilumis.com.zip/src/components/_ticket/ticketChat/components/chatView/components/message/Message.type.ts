import { TicketDTO } from '@/dto'

export type MessageProps = {
  data: TicketDTO
  side: 'right' | 'left'
}

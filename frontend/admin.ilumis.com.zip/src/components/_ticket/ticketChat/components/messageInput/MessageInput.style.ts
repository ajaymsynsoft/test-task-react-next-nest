import { Style } from '@/types/Style.type'

export const style: Style = {
  root: {
    gap: 1.5,
    display: 'flex',
    flexFlow: 'row',
    alignItems: 'end',
  },
  sendButton: {
    width: 53,
    height: 53,
    minWidth: 'unset',
    flexShrink: 0,
    p: 0,
    '.icon': {
      fontSize: '23px !important',
    },
  },
  messageInput: {
    outline: 'unset',
    '.MuiOutlinedInput-notchedOutline': {
      borderWidth: '1px !important',
      borderColor: (theme) => `${theme.palette.dividerDark} !important`,
    },
  },
}

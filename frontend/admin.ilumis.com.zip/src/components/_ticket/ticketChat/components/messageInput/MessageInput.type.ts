import { TicketChatProps } from '../../TicketChat.type'

export type MessageInputProps = TicketChatProps

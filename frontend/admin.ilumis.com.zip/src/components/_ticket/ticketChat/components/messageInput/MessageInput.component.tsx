import toast from 'react-hot-toast'
import { Alert, Container } from '@mui/material'
import { useForm } from 'react-hook-form'
import { LoadingButton } from '@mui/lab'
import { yupResolver } from '@hookform/resolvers/yup'
import { RiSendPlaneFill } from 'react-icons/ri'

import InputField from '@/components/_ui/inputField/InputField.component'
import { schema, TSchema } from './MessageInput.config'
import { useReplyOnTicketMutation } from '@/redux/api/ticket.api'
import { useReduxSelector } from '@/hooks'
import { MessageInputProps } from './MessageInput.type'
import { style } from './MessageInput.style'

export default function MessageInput({ error, loading, data }: MessageInputProps) {
  const disabled = error || loading
  const { role } = useReduxSelector((state) => state.layout.profile)
  const [replyOnTicket] = useReplyOnTicketMutation()

  const {
    handleSubmit,
    control,
    getValues,
    reset,
    formState: { isSubmitting },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      ticketId: data?.[0]?.id,
      message: '',
      replyMessage: '',
    },
  })

  const onSubmit = async () => {
    if (disabled) return
    const formData = schema.validateSync(getValues())
    const message = role === 'customer' ? formData.message : formData.replyMessage

    if (!message.trim().length) return toast.error('Please type a message.')
    if (message.trim().length > 3000) return toast.error('Please explain in under 3000 characters.')

    await replyOnTicket(formData).unwrap()
    reset()
  }

  return (
    <Container component="form" sx={style.root} noValidate onSubmit={handleSubmit(onSubmit)}>
      {data?.[0].status !== 'closed' ? (
        <>
          <InputField multiline maxRows={4} disabled={disabled} sx={style.messageInput} control={control} placeholder="Type message..." name={role === 'customer' ? 'message' : 'replyMessage'} autoFocus />
          <LoadingButton variant="contained" size="large" type="submit" disabled={disabled} loading={isSubmitting} sx={style.sendButton}>
            <RiSendPlaneFill />
          </LoadingButton>
        </>
      ) : (
        <Alert severity="success" sx={{ width: 1 }}>
          This ticket has been closed.
        </Alert>
      )}
    </Container>
  )
}

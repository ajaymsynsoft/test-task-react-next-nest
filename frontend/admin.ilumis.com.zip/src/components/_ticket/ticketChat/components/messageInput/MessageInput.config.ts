import * as yup from 'yup'

export const schema = yup.object({
  message: yup.string().trim().defined(),
  replyMessage: yup.string().trim().defined(),
  ticketId: yup.number().required(),
})

export type TSchema = yup.InferType<typeof schema>

import { TicketDTO } from '@/dto'

export type TicketChatProps = {
  data?: TicketDTO[]
  loading: boolean
  updating: boolean
  error: boolean
}

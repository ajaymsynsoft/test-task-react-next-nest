import { Stack } from '@mui/material'

import ChatView from './components/chatView/ChatView.component'
import MessageInput from './components/messageInput/MessageInput.component'
import { TicketChatProps } from './TicketChat.type'

export default function TicketChat(props: TicketChatProps) {
  return (
    <Stack height={1} width={1} pb={1.5} gap={1.5}>
      <ChatView {...props} />
      <MessageInput {...props} key={`${props.loading}`} />
    </Stack>
  )
}

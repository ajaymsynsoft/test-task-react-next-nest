import Link from 'next/link'
import { useState } from 'react'
import { MdCorporateFare, MdMenu, MdOutlineLogout, MdNotificationsNone } from 'react-icons/md'
import { SwipeableDrawer, Box, Stack, Button, IconButton, Avatar, List, Typography, Divider, useTheme, useMediaQuery } from '@mui/material'

import NavItem from '@/components/navItem/NavItem.component'
import { useSidebarOptions } from '@/layouts/rootLayout/components/sidebar/Sidebar.hook'
import { handleLogout } from '@/redux/slice/layout.slice'
import { formatToTitleCase } from '@/utils'
import { useReduxDispatch, useReduxSelector } from '@/hooks/redux.hook'
import { style } from './Drawer.style'

export default function Drawer() {
  const [open, setOpen] = useState<boolean>(false)
  const sidebarOptions = useSidebarOptions()
  const toggleDrawer = (newState: boolean) => () => {
    setOpen(newState)
  }

  const dispatch = useReduxDispatch()
  const profile = useReduxSelector((state) => state.layout.profile)
  const organization = useReduxSelector((state) => state.organization)
  const name = profile.role === 'admin' ? organization.organizationName : `${profile.firstName} ${profile.lastName}`

  const theme = useTheme()
  const isXsUp = useMediaQuery(theme.breakpoints.up('xs'))

  return (
    <>
      <Stack direction="row" spacing={0.5} divider={<Divider orientation="vertical" sx={style.divider} variant="middle" flexItem />}>
        {isXsUp && (
          <IconButton edge="end" LinkComponent={Link} href="/dashboard/notifications">
            <MdNotificationsNone className="icon-xl" />
          </IconButton>
        )}
        <Button variant="text" onClick={toggleDrawer(true)} sx={{ px: 0, m: 0 }} endIcon={<MdMenu className="icon-xl" />}></Button>
      </Stack>

      <SwipeableDrawer anchor="left" open={open} onClose={toggleDrawer(false)} onOpen={toggleDrawer(true)}>
        <Box sx={style.drawerContainer} role="presentation">
          <Stack>
            <Typography sx={style.menuHeading}>MAIN MENU</Typography>

            <List component="nav" disablePadding sx={style.menuContainer}>
              {sidebarOptions.map((item, index) => (
                <NavItem size="large" data={item} key={index} sx={style.menuList} onClick={toggleDrawer(false)} />
              ))}
            </List>

            <Stack sx={style.profileContainer}>
              <Stack sx={style.profileBox}>
                <Avatar sx={style.circleSize}>{profile.role === 'admin' && <MdCorporateFare className="icon-xl" />}</Avatar>
                <Stack overflow="hidden" gap="1px">
                  <Typography color="text.primary" className="line-1" fontWeight={500} title={name}>
                    {name}
                  </Typography>
                  <Typography variant="body2">{formatToTitleCase(profile.role)}</Typography>
                </Stack>
              </Stack>
              <Button sx={style.logoutBtn} endIcon={<MdOutlineLogout />} onClick={() => dispatch(handleLogout())}>
                Logout
              </Button>
            </Stack>
          </Stack>
        </Box>
      </SwipeableDrawer>
    </>
  )
}

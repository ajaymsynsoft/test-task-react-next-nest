import { Style } from '@/types'
import { HEADER_HEIGHT } from '@/layouts/rootLayout/RootLayout.config'

export const style: Style = {
  drawerContainer: {
    width: 250,
    height: 'auto',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    pt: 3,
    pb: 1,
  },
  logoContainer: {
    px: 2,
    height: HEADER_HEIGHT - 1,
    alignItems: 'center',
    flexDirection: 'row',
  },
  menuContainer: {
    flex: 1,
    overflow: 'auto',
    px: 1.5,
  },
  menuHeading: {
    px: 2.5,
    mb: 1.5,
  },
  menuList: {
    '.MuiMenuItem-root.active': {
      position: 'relative',
      ':before': {
        content: `''`,
        position: 'absolute',
        height: '60%',
        width: 5,
        bgcolor: 'primary.light',
        left: -12,
        top: '50%',
        transform: 'translateY(-50%)',
        borderRadius: '0 10px 10px 0',
        pointerEvents: 'none',
      },
    },
  },
  profileContainer: {
    p: 2,
    gap: 2,
  },
  profileBox: {
    flexDirection: { xs: 'row', xl: 'column' },
    gap: 1,
    alignItems: 'center',
    textAlign: { xs: 'left', xl: 'center' },
  },
  circleSize: {
    '--size': { xs: '36px', xl: '50px' },
    width: 'var(--size)',
    height: 'var(--size)',
  },
  logoutBtn: {
    justifyContent: { xs: 'center', lg: 'space-between' },
    px: { xs: undefined, lg: 2 },
    py: { xs: undefined, lg: 0.85 },
  },
  closeBtn: { px: 0, m: 0 },
  divider: {
    height: 20,
    alignSelf: 'center',
    border: 'dividerDark',
    borderWidth: '1px',
  },
}

import { Stack, alpha, useScrollTrigger, SxProps } from '@mui/material'

import Logo from '@/components/logo/Logo.component'
import Drawer from './components/drawer/Drawer.component'
import { HEADER_HEIGHT } from '@/layouts/rootLayout/RootLayout.config'

export default function CompactHeader() {
  const trigger = useScrollTrigger({ threshold: 24, disableHysteresis: true })

  const style = {
    '--border-color': (theme: { palette: { dividerDark: any } }) => theme.palette.dividerDark,
    height: HEADER_HEIGHT,
    borderBottom: 1,
    borderColor: 'transparent',
    backdropFilter: 'blur(8px)',
    position: { xs: 'sticky', md: 'relative' },
    bgcolor: (theme: { palette: { background: { default: string } } }) => alpha(theme.palette.background.default, 0.8),
    zIndex: (theme: { zIndex: { appBar: any } }) => theme.zIndex.appBar,
    top: 0,
    ...(trigger && {
      transition: (theme: { transitions: { create: (arg0: string[]) => any } }) => theme.transitions.create(['border-color']),
      borderColor: 'var(--border-color)',
    }),
  }

  return (
    <Stack direction={'row'} m={1} display={{ xs: 'flex', md: 'none' }} sx={style as SxProps}>
      <Logo sx={{ mr: 'auto' }} />
      <Drawer />
    </Stack>
  )
}

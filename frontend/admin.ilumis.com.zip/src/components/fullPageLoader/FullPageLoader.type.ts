export type FullPageLoaderProps = {
  children?: React.ReactNode
}

import { styled, Tabs } from '@mui/material'

export const StyledTabs = styled(Tabs)(({ theme }) =>
  theme.unstable_sx({
    '--padding': '2px',
    minHeight: 'unset',
    width: 'fit-content',
    overflow: 'unset',
    borderRadius: 1,
    bgcolor: 'action.hover',
    zIndex: 1,
    position: 'relative',
    px: 'var(--padding)',
    '.MuiTab-root': {
      py: 1.188,
      minWidth: 'unset',
      minHeight: 'unset',
      px: 1.5,
      color: 'text.disabled',
      transition: 'color .25s',
      '&.Mui-selected': {
        color: 'text.secondary',
      },
      '.MuiTouchRipple-root': {
        display: 'none',
      },
    },
    '.MuiTabs-scroller': {
      overflow: 'visible !important',
    },
    '.MuiTabs-indicator': {
      height: `calc(100% - calc(var(--padding) * 2))`,
      bottom: 'var(--padding)',
      zIndex: -1,
      bgcolor: 'white',
      borderRadius: `calc(${theme.shape.borderRadius}px - var(--padding))`,
      boxShadow: '0 0 0 1px rgba(0, 0, 0, 0.05)',
    },
  }),
)

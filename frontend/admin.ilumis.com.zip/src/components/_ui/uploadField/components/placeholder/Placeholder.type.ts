import { UploadFieldProps } from '../../UploadField.type'

export type PlaceholderProps = UploadFieldProps<any, any> & {}

import { Stack, Theme, Typography, useMediaQuery } from '@mui/material'
import { FiUpload } from 'react-icons/fi'

import { style } from './Placeholder.style'
import { PlaceholderProps } from './Placeholder.type'

export default function Placeholder(props: PlaceholderProps) {
  let { heading, description, maxFiles } = props
  const isMdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'))

  if (typeof heading === 'object') {
    heading = isMdUp ? heading.desktop : heading.mobile
  }

  if (typeof description === 'object') {
    description = isMdUp ? description.desktop : description.mobile
  }

  return (
    <Stack sx={style.root}>
      {/* Icon */}
      <Stack sx={style.iconContainer}>
        <FiUpload size={21} />
      </Stack>

      {/* Heading */}
      <Typography variant="h4" className="heading" sx={style.heading}>
        {heading || `Upload your file${maxFiles! > 1 ? 's' : ''}`}
      </Typography>

      {/* Description */}
      {description && (
        <Typography color="text.disabled" mt={-0.5}>
          {description}
        </Typography>
      )}
    </Stack>
  )
}

import { alpha } from '@mui/material'
import { Style } from '@/types'

export const style: Style = {
  root: {
    cursor: 'pointer',
    py: 3,
    px: 2,
    alignItems: 'center',
    gap: 1,
    textAlign: 'center',
  },
  iconContainer: {
    width: 50,
    height: 50,
    color: 'primary.main',
    bgcolor: (theme) => alpha(theme.palette.primary.main, 0.07),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '100%',
  },
  heading: {
    color: 'primary.main',
  },
}

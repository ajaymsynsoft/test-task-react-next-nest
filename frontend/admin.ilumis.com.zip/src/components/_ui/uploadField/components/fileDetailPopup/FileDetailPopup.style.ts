import { Style } from '@/types'

export const style: Style = {
  dialogTitle: {
    display: 'flex',
    gap: 1,
    alignItems: 'start',
    py: 1.5,
    borderBottom: 1,
    borderColor: 'divider',
    overflowWrap: 'anywhere',
  },
  dialogContent: {
    p: 0,
    overflow: 'auto',
    display: 'grid',
    bgcolor: 'background.default',
  },
  image: {
    width: 'auto',
    // maxWidth: 'unset',
    height: 'auto',
    margin: 'auto',
  },
}

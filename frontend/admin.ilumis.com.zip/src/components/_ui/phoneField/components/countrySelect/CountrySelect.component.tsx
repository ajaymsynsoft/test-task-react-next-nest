import React, { useMemo } from 'react'
import { MenuItem, Select, SelectChangeEvent } from '@mui/material'
import { IoMdArrowDropdown } from 'react-icons/io'
import { CountrySelectProps, Option } from './CountrySelect.type'

export default function CountrySelect(props: CountrySelectProps) {
  const { value, options, iconComponent: Icon, onChange, disabled, readOnly, ...rest } = props
  const selectedOption = useMemo(() => getSelectedOption(options, value), [])

  const handleChange = (event: SelectChangeEvent<string>) => {
    const selectedValue = event.target.value
    onChange(selectedValue === 'ZZ' ? undefined : selectedValue)
  }

  return (
    <div className="PhoneInputCountry">
      <Select {...rest} disabled={disabled || readOnly} className="PhoneInputCountrySelect" value={value || 'ZZ'} onChange={handleChange}>
        {options.map(({ value, label }, index) => (
          <MenuItem value={value || 'ZZ'} key={index}>
            {label}
          </MenuItem>
        ))}
      </Select>

      {selectedOption && <Icon country={value} label={selectedOption.label} />}

      <IoMdArrowDropdown style={{ opacity: 0.75 }} />
    </div>
  )
}

const getSelectedOption = (options: Option[], value?: string): Option | undefined => {
  for (const option of options) {
    if (!option.divider) {
      if (isSameOptionValue(option.value, value)) {
        return option
      }
    }
  }
  return undefined
}

const isSameOptionValue = (value1?: string, value2?: string): boolean => {
  return value1 == null ? value2 == null : value1 === value2
}

export type Option = {
  value: string | undefined
  label: string
  divider?: boolean
}

export type CountrySelectProps = {
  value?: string
  onChange: (value?: string) => void
  options: Option[]
  className?: string
  iconComponent: React.ElementType<{ country?: string; label: string; aspectRatio?: number }>
  getIconAspectRatio?: (country: string) => number
  arrowComponent?: React.ElementType
  unicodeFlags?: boolean
  disabled?: boolean
  readOnly?: boolean
}

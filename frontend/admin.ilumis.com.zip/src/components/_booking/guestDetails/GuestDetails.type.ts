import { TGuest } from '@/types'

export type GuestDetailsProps = {
  data: TGuest
}

import { Style } from '@/types/Style.type'

export const style: Style = {
  listItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 2,
    py: 0.25,
    ':hover': {
      bgcolor: 'action.hover',
    },
  },
}

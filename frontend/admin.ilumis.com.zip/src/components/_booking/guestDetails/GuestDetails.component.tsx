import moment from 'moment'
import { Avatar, Chip, Divider, Stack, Typography } from '@mui/material'

import GuestInfoCard from '@/components/_card/guestInfoCard/GuestInfoCard.compoent'
import { style } from './GuestDetails.style'
import { formatToTitleCase, getStatusColor } from '@/utils'
import { useReduxSelector } from '@/hooks'
import { GuestDetailsProps } from './GuestDetails.type'

export default function GuestDetails({ data }: GuestDetailsProps) {
  const { role } = useReduxSelector((state) => state.layout.profile)

  const createListItem = (label: string, value: string | number | undefined | null) => {
    return (
      <Stack sx={style.listItem}>
        <Typography color="text.primary" fontWeight={500} whiteSpace="nowrap">
          {label}:
        </Typography>
        <Typography>{value || '-'}</Typography>
      </Stack>
    )
  }

  return (
    <>
      <Stack flex={1} gap={2}>
        {/* Card */}
        <Stack direction="row" justifyContent="space-between" gap={2}>
          <GuestInfoCard data={data}>
            <Stack direction="row">
              {data.passportImage && <Chip variant="outlined" label="View Passport" component="a" href={data.passportImage} clickable target="_blank" sx={{ borderRadius: 0.5, color: 'text.secondary' }} />}
            </Stack>
          </GuestInfoCard>
          <Stack direction="row" gap={1} flexWrap="wrap-reverse" alignItems="start">
            {role !== 'customer' && !data.hotelRoomTypeId && <Chip variant="outlined" label="No hotel" color="default" />}
            <Chip variant="outlined" label={formatToTitleCase(data.status)} color={getStatusColor(data.status)} />
          </Stack>
        </Stack>

        {/* Accessibility */}
        {data.accessibilityInfoData.length > 0 && (
          <Stack direction="row" gap={1}>
            {data.accessibilityInfoData.map((accessibilityItem, accessibilityIndex) => (
              <Chip avatar={<Avatar alt="icon" src={accessibilityItem.imageURL} />} label={accessibilityItem.name} key={accessibilityIndex} />
            ))}
          </Stack>
        )}

        <Stack direction={{ xs: 'column', sm: 'row' }} gap={2} divider={<Divider orientation="vertical" flexItem />}>
          {/* General Information */}
          <Stack flex={1} gap={1}>
            <Typography variant="h3" fontWeight={600}>
              General Information
            </Typography>
            <Stack>
              {createListItem('Passport number', data.passportNumber)}
              {createListItem('Nationality', data.nationality)}
              {createListItem('Passport issue date', data.passportIssueDate && moment(data.passportIssueDate).format())}
              {createListItem('Passport expire date', data.passportExpiryDate && moment(data.passportExpiryDate).format())}
              {createListItem('Date of birth', data.dob && moment(data.dob).format())}
              {createListItem('Occupation', data.occupation)}
              {createListItem('Job title', data.jobTitle)}
              {createListItem('Place of work', data.workPlace)}
            </Stack>
          </Stack>

          {/* Flight Details */}
          <Stack flex={1} gap={1}>
            <Typography variant="h3" fontWeight={600}>
              Flight Details
            </Typography>
            <Stack>
              {createListItem('Arrival airport', data.arrivalFlightAirport)}
              {createListItem('Arrival flight number', data.arrivalFlightNumber)}
              {createListItem('Arrival time', data.arrivalDateTime && moment(data.arrivalDateTime).format('lll'))}
              {createListItem('Arrival notes', data.arrivalNotes)}
              {createListItem('Departure airport', data.departureFlightAirport)}
              {createListItem('Departure flight number', data.departureFlightNumber)}
              {createListItem('Departure time', data.departureDateTime && moment(data.departureDateTime).format('lll'))}
              {createListItem('Departure notes', data.departureNotes)}
            </Stack>
          </Stack>
        </Stack>
      </Stack>
    </>
  )
}

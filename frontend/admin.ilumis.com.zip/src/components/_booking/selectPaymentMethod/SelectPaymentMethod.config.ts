import * as yup from 'yup'
import { PaymentMethods } from '@/types'

export const schema = yup.object({
  orderId: yup.number().required(),
  useWalletBalance: yup.boolean().required(),
  paymentType: yup.string<PaymentMethods>().trim().required('Select a payment method *'),
})

export type TSchema = yup.InferType<typeof schema>

import { Style } from '@/types'

export const style: Style = {
  walletBox: {
    bgcolor: 'background.bg2',
    p: 1.5,
    borderRadius: 1,
    px: 2,
    border: 1,
    borderColor: 'divider',
    flexFlow: 'row',
    alignItems: 'center',
  },
  walletIcon: {
    fontSize: '30px !important',
    color: 'text.secondary',
  },
  paymentMethodOption: {
    '.MuiFormControlLabel-label': {
      width: 1,
    },
  },
  bankDetailsBox: {
    mb: 2,
    p: 2,
    bgcolor: 'background.bg2',
    borderRadius: 1,
  },
}

import { LoadingButton } from '@mui/lab'
import { Controller, useForm } from 'react-hook-form'
import { TSchema, schema } from './SelectPaymentMethod.config'
import { yupResolver } from '@hookform/resolvers/yup'
import { MdRadioButtonChecked, MdRadioButtonUnchecked } from 'react-icons/md'
import { Alert, Checkbox, Collapse, Dialog, DialogActions, DialogContent, DialogTitle, Divider, FormControl, FormControlLabel, FormHelperText, Grid, Radio, RadioGroup, Stack, Typography } from '@mui/material'

import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { style } from './SelectPaymentMethod.style'
import { SelectPaymentMethodProps } from './SelectPaymentMethod.type'
import { useGetWalletBalanceQuery } from '@/redux/api/wallet.api'
import { useGetEventQuery } from '@/redux/api/event.api'

export default function SelectPaymentMethod(props: SelectPaymentMethodProps) {
  const { data, onCancel, paymentMethods, amountPay } = props
  const walletApiState = useGetWalletBalanceQuery()
  const eventApiState = useGetEventQuery({ eventId: data.eventId, bankDetails: true })

  const isWalletBalanceEnough = (walletApiState.data?.amount || 0) >= amountPay
  const bankDetails = eventApiState.data?.paymentMethodSupported.find((item) => item.type === 'bankTransfer')?.data || ''
  const filteredPaymentMethods = (paymentMethods ? eventApiState.data?.paymentMethodSupported.filter((item) => paymentMethods.includes(item.type) && item.value) : eventApiState.data?.paymentMethodSupported) || []

  const {
    handleSubmit,
    control,
    getValues,
    setValue,
    watch,
    formState: { isSubmitting, isValid },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      orderId: data.id,
      useWalletBalance: false,
      paymentType: '' as any,
    },
  })

  const onSubmit = async () => {
    const formData = getValues()
    await props.onSubmit(formData)
  }

  return (
    <Dialog open fullWidth component="form" maxWidth="sm" onClose={() => !isSubmitting && onCancel()} onSubmit={handleSubmit(onSubmit)} {...{ noValidate: true }}>
      <DialogTitle>Select a payment method</DialogTitle>
      <DialogContent dividers>
        <RenderContent error={walletApiState.isError || eventApiState.isError} loading={walletApiState.isLoading || eventApiState.isLoading}>
          {walletApiState.isSuccess && eventApiState.isSuccess && (
            <Grid container spacing={2}>
              {/* Wallet */}
              {walletApiState.data.amount > 0 && (
                <Grid item xs={12}>
                  <Controller
                    name="useWalletBalance"
                    control={control}
                    render={({ fieldState: { error }, field: { ref, value, ...restField } }) => (
                      <FormControl error={!!error} sx={style.walletBox}>
                        <FormControlLabel
                          componentsProps={{ typography: { color: error ? 'error.main' : undefined } }}
                          control={
                            <Checkbox
                              {...restField}
                              inputRef={ref}
                              checked={value}
                              {...(isWalletBalanceEnough && {
                                icon: <MdRadioButtonUnchecked size={24} />,
                                checkedIcon: <MdRadioButtonChecked size={24} />,
                                onChange: (e, value) => {
                                  setValue('paymentType', 'wallet')
                                  restField.onChange(true)
                                },
                              })}
                            />
                          }
                          label={
                            <Stack gap={0.25} pl={1}>
                              <Typography variant="subtitle">Use wallet balance</Typography>
                              <Typography variant="body2">
                                Available balance <DisplayPrice price={walletApiState.data.amount} />
                              </Typography>
                            </Stack>
                          }
                        />
                        <FormHelperText>{error?.message}</FormHelperText>
                      </FormControl>
                    )}
                  />
                </Grid>
              )}

              {/* Payment Methods */}
              {filteredPaymentMethods.length ? (
                <Grid item xs={12}>
                  <Controller
                    name="paymentType"
                    control={control}
                    render={({ fieldState: { error }, field: { ref, ...restField } }) => (
                      <FormControl error={!!error}>
                        <RadioGroup
                          {...restField}
                          {...(isWalletBalanceEnough && {
                            onChange: (e, value) => {
                              setValue('useWalletBalance', false)
                              restField.onChange(value)
                            },
                          })}
                        >
                          <Stack sx={style.paymentMethodOption} divider={<Divider />}>
                            {filteredPaymentMethods.map((item, index) => {
                              const disable = !item.value || (item.type === 'bankTransfer' && !bankDetails)
                              if (disable) return null

                              return (
                                <Stack key={index}>
                                  <FormControlLabel
                                    inputRef={ref}
                                    value={item.type}
                                    control={<Radio />}
                                    label={
                                      <Stack direction="row" alignItems="center" justifyContent="space-between" gap={2} width={1}>
                                        <Typography>{item.label}</Typography>
                                      </Stack>
                                    }
                                  />
                                  <Collapse in={watch('paymentType') === 'bankTransfer' && item.type === 'bankTransfer'}>
                                    <Stack sx={style.bankDetailsBox} className="text-editor-content" dangerouslySetInnerHTML={{ __html: bankDetails }} />
                                  </Collapse>
                                </Stack>
                              )
                            })}
                          </Stack>
                        </RadioGroup>
                        <FormHelperText>{error?.message}</FormHelperText>
                      </FormControl>
                    )}
                  />
                </Grid>
              ) : (
                !isWalletBalanceEnough && (
                  <Grid item xs={12}>
                    <Alert variant="outlined" severity="info">
                      Wallet balance is not enough and there is no any another payment method available.
                    </Alert>
                  </Grid>
                )
              )}
            </Grid>
          )}
        </RenderContent>
      </DialogContent>
      <DialogActions>
        <LoadingButton variant="text" disabled={isSubmitting} onClick={onCancel}>
          Cancel
        </LoadingButton>
        <LoadingButton variant="contained" type="submit" disabled={!isValid} loading={isSubmitting}>
          Continue
        </LoadingButton>
      </DialogActions>
    </Dialog>
  )
}

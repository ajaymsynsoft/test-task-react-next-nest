import { BookingDTO } from '@/dto/Booking.dto'
import { TSchema } from './SelectPaymentMethod.config'
import { PaymentMethods } from '@/types'

export type SelectPaymentMethodProps = {
  data: BookingDTO
  onCancel: () => void
  onSubmit: (formData: TSchema) => Promise<void>
  paymentMethods?: PaymentMethods[]
  amountPay: number
}

import { BookingDTO } from '@/dto/Booking.dto'

export type AccommodationFormPopupProps = {
  data: BookingDTO
  onCancel: () => void
} & (
  | {
      isEditMode: false
      sequenceNo?: void
    }
  | {
      isEditMode: true
      sequenceNo: number
    }
)

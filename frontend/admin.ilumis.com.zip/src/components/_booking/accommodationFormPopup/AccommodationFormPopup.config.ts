import * as yup from 'yup'
import moment from 'moment'

export const schema = yup.object({
  isEditMode: yup.boolean().required(),
  orderId: yup.number().required(),
  eventId: yup.number().required(),
  orderDetailId: yup.number().when('isEditMode', {
    is: true,
    then: (schema) => schema.required(),
    otherwise: (schema) => schema.notRequired(),
  }),
  hotelId: yup.number().required(),
  hotelRoomTypeId: yup.number().required(),
  fromDate: yup.string().required(),
  toDate: yup
    .string()
    .required()
    .test('validate', 'It must be greater than "From date"', function (toDate) {
      const fromDate = this.parent.fromDate
      if (fromDate && toDate) return moment(toDate).isAfter(fromDate)
      return true
    }),
  noOfGuest: yup.number(),
  guestIds: yup.array().of(yup.number().required()).required().min(1, 'Required *'),
  sequenceNo: yup.number().when('isEditMode', {
    is: true,
    then: (schema) => schema.required(),
  }),
})

export type TSchema = yup.InferType<typeof schema>

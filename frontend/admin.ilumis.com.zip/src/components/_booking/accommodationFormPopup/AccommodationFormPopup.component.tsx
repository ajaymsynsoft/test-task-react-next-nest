import toast from 'react-hot-toast'
import moment from 'moment'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import { LoadingButton } from '@mui/lab'
import { Controller, useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { MobileDatePicker } from '@mui/x-date-pickers'
import { FormControl, FormHelperText, Grid, DialogTitle, DialogActions, InputLabel, MenuItem, Select, Stack, Dialog } from '@mui/material'
import { Typography, Alert, FormLabel, FormControlLabel, RadioGroup, Radio, Checkbox, Fade, DialogContent, Chip } from '@mui/material'

import SummaryCard from '@/components/_card/summaryCard/SummaryCard.component'
import HotelInfoCard from '@/components/_card/hotelInfoCard/HotelInfoCard.compoent'
import GuestInfoCard from '@/components/_card/guestInfoCard/GuestInfoCard.compoent'
import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { TSchema, schema } from './AccommodationFormPopup.config'
import { AccommodationFormPopupProps } from './AccommodationFormPopup.type'
import { useAddGuestAccommodationMutation, useUpdateGuestAccommodationMutation } from '@/redux/api/guest.api'
import { TSummaryData } from '@/components/_card/summaryCard/SummaryCard.type'
import { useGetEventQuery } from '@/redux/api/event.api'
import { useGetRoomAvailabilityMutation } from '@/redux/api/hotel.api'

export default function AccommodationFormPopup(props: AccommodationFormPopupProps) {
  const { onCancel, isEditMode, data, sequenceNo } = props
  const router = useRouter()
  const eventId = Number(router.query.eventId)
  const [summary, setSummary] = useState<TSummaryData>()

  const [addGuestAccommodation] = useAddGuestAccommodationMutation()
  const [updateGuestAccommodation] = useUpdateGuestAccommodationMutation()
  const { data: event, isLoading, isError, isSuccess } = useGetEventQuery({ eventId })
  const [getRoomAvailability] = useGetRoomAvailabilityMutation()

  const orderDetailId = data.orderDetails.find((item) => item.type === 'accommodation')?.id
  const accommodationInfo = data.accommodationInfo.find((item) => item.sequenceNo === sequenceNo)!

  const {
    handleSubmit,
    control,
    trigger,
    watch,
    setError,
    setValue,
    getValues,
    formState: { isSubmitting, isSubmitted, dirtyFields },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      isEditMode,
      eventId,
      orderId: data.id,
      orderDetailId,
      guestIds: [],
      ...(isEditMode && {
        sequenceNo: accommodationInfo.sequenceNo,
        fromDate: accommodationInfo.fromDate,
        toDate: accommodationInfo.toDate,
        guestIds: accommodationInfo.guestIds,
        hotelId: accommodationInfo.hotelId,
        hotelRoomTypeId: accommodationInfo.hotelRoomTypeId,
      }),
    },
  })

  const filteredHotels = event?.hotels.filter((hotel) => hotel.roomType.filter((room) => room.status === 'active').length) || []
  const selectedHotel = filteredHotels.find((item) => item.id === watch('hotelId'))
  const selectedRoomType = selectedHotel?.roomType.find((item) => item.id === watch('hotelRoomTypeId'))

  useEffect(() => {
    const subscription = watch(() => handleUpdateSummary())
    return () => {
      subscription.unsubscribe()
    }
  }, [watch])

  const handleUpdateSummary = () => {
    const values = getValues()
    const numberOfNights = values.toDate && values.fromDate ? moment(values.toDate).diff(values.fromDate, 'days') : 0
    const numberOfGuests = values.guestIds!.length
    const selectedRoom = event?.hotels.find((item) => item.id === values.hotelId)?.roomType.find((item) => item.id === values.hotelRoomTypeId)
    const totalAccommodation = numberOfGuests && numberOfNights && selectedRoom ? selectedRoom.nightPrice * numberOfNights * numberOfGuests : 0

    setSummary([
      { label: 'Number of nights', value: numberOfNights },
      { label: 'Number of guests', value: numberOfGuests },
      { label: 'Total accommodation', value: totalAccommodation, type: 'amount', isTotal: true },
    ])
  }

  if (isSuccess && !summary) handleUpdateSummary()

  const onSubmit = async () => {
    const formData = getValues()

    if (formData.guestIds.length < selectedRoomType!.minimumOccupancy || formData.guestIds.length > selectedRoomType!.maximumOccupancy) {
      return setError('guestIds', { type: 'validate', message: '' }, { shouldFocus: true })
    }

    if (!isEditMode || (isEditMode && dirtyFields.hotelRoomTypeId)) {
      const roomAvailability = await getRoomAvailability({ eventId, hotelId: formData.hotelId, roomTypeId: formData.hotelRoomTypeId }).unwrap()
      if (!roomAvailability) return toast.error('Sorry! room is not available')
    }

    formData.noOfGuest = formData.guestIds.length
    if (isEditMode) await updateGuestAccommodation(formData).unwrap()
    else await addGuestAccommodation(formData).unwrap()
    onCancel()
  }

  return (
    <Dialog open fullWidth component="form" maxWidth="sm" onClose={() => !isSubmitting && onCancel()} onSubmit={handleSubmit(onSubmit)} {...{ noValidate: true }}>
      <DialogTitle>{isEditMode ? 'Update' : 'Add'} Hotel Booking</DialogTitle>
      <DialogContent dividers>
        <RenderContent error={isError} loading={isLoading}>
          {isSuccess && !filteredHotels.length ? (
            <Alert severity="info">Sorry, no hotels are linked to this event.</Alert>
          ) : (
            <Grid container spacing={2}>
              {/* Select Hotel */}
              <Grid item xs={12}>
                <Controller
                  name="hotelId"
                  control={control}
                  defaultValue={'' as any}
                  render={({ fieldState: { error }, field: { ref, onChange, ...restField } }) => (
                    <FormControl error={!!error}>
                      <InputLabel>Select hotel *</InputLabel>
                      <Select
                        {...restField}
                        inputRef={ref}
                        label="Select hotel *"
                        onChange={(e) => {
                          onChange(e), setValue('hotelRoomTypeId', '' as any)
                        }}
                        renderValue={(selectedHotelId) => filteredHotels.find((item) => item.id === selectedHotelId)?.name}
                      >
                        {filteredHotels.map((item, index) => (
                          <MenuItem value={item.id} key={index}>
                            <HotelInfoCard data={item} />
                          </MenuItem>
                        ))}
                      </Select>
                      <FormHelperText>{error?.message}</FormHelperText>
                    </FormControl>
                  )}
                />
              </Grid>

              {watch('hotelId') && (
                <>
                  {/* Room Type */}
                  <Grid item xs={12}>
                    <Controller
                      name="hotelRoomTypeId"
                      control={control}
                      defaultValue={null as any}
                      render={({ fieldState: { error }, field: { ref, onChange, ...restField } }) => (
                        <Fade in key={watch('hotelId')} timeout={500}>
                          <FormControl error={!!error}>
                            <FormLabel sx={{ fontWeight: 500 }}>Select room type *</FormLabel>
                            <RadioGroup
                              {...restField}
                              onChange={(_, value) => {
                                onChange(Number(value)), isSubmitted && trigger('guestIds')
                              }}
                            >
                              {selectedHotel!.roomType
                                .filter((item) => item.status === 'active')
                                .map((item, index) => (
                                  <FormControlLabel
                                    key={index}
                                    inputRef={ref}
                                    value={item.id}
                                    control={<Radio size="small" />}
                                    label={
                                      <Stack direction="row" gap={1} alignItems="center">
                                        {item.roomSize}{' '}
                                        <Typography variant="body2">
                                          (<DisplayPrice price={item.nightPrice} /> per person per night)
                                        </Typography>
                                      </Stack>
                                    }
                                  />
                                ))}
                            </RadioGroup>
                            <FormHelperText>{error?.message}</FormHelperText>
                          </FormControl>
                        </Fade>
                      )}
                    />
                  </Grid>

                  {/* From Date */}
                  <Grid item xs={12} sm={6}>
                    <Controller
                      name="fromDate"
                      control={control}
                      render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                        <MobileDatePicker
                          {...restField}
                          label="From *"
                          inputRef={ref}
                          minDate={moment(event!.startDate).subtract(1, 'weeks')}
                          maxDate={moment(event!.endDate).add(1, 'weeks')}
                          value={value ? moment(value) : null}
                          onChange={(value) => onChange(value?.toISOString())}
                          slotProps={{
                            textField: { error: !!error, helperText: error?.message },
                          }}
                        />
                      )}
                    />
                  </Grid>

                  {/* To Date */}
                  <Grid item xs={12} sm={6}>
                    <Controller
                      name="toDate"
                      control={control}
                      render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                        <MobileDatePicker
                          {...restField}
                          label="To *"
                          inputRef={ref}
                          minDate={moment(event!.startDate).subtract(1, 'weeks')}
                          maxDate={moment(event!.endDate).add(1, 'weeks')}
                          value={value ? moment(value) : null}
                          onChange={(value) => onChange(value?.toISOString())}
                          slotProps={{
                            textField: { error: !!error, helperText: error?.message },
                          }}
                        />
                      )}
                    />
                  </Grid>

                  {/* Assign Guest */}
                  <Grid item xs={12}>
                    <Controller
                      name="guestIds"
                      control={control}
                      render={({ fieldState: { error }, field: { ref, ...restField } }) => (
                        <FormControl error={!!error}>
                          <InputLabel>Assign guest *</InputLabel>
                          <Select
                            {...restField}
                            inputRef={ref}
                            multiple
                            label="Assign guest *"
                            renderValue={(selected) => {
                              const selectedItemsLabel = selected.map((item) => {
                                const currentItem = data.guestDetails.find((guest) => guest.id === item)
                                return `${currentItem?.passportFirstName} ${currentItem?.passportLastName}` || 'notFound'
                              })

                              return (
                                <Stack flexWrap="wrap" direction="row" gap={0.5}>
                                  {selectedItemsLabel.map((item, index) => (
                                    <Chip key={index} label={item} />
                                  ))}
                                </Stack>
                              )
                            }}
                          >
                            {data.guestDetails.map((item, index) => {
                              const isBookedGuest = !!item.hotelId && (isEditMode ? accommodationInfo.guestIds.indexOf(item.id) == -1 : true)

                              return (
                                <MenuItem value={item.id} key={index} disabled={isBookedGuest}>
                                  <Stack direction="row" alignItems="center" justifyContent="space-between" width={1} gap={2}>
                                    <Stack direction="row" alignItems="center">
                                      <Checkbox disabled={isBookedGuest} checked={watch('guestIds').indexOf(item.id) > -1} size="small" edge="start" disableRipple />
                                      <GuestInfoCard data={item} />
                                    </Stack>
                                    {isBookedGuest && <Chip label="Already Assigned" />}
                                  </Stack>
                                </MenuItem>
                              )
                            })}
                          </Select>
                          <FormHelperText>
                            {error?.message ||
                              (selectedRoomType &&
                                `You can assign ${
                                  selectedRoomType.minimumOccupancy === selectedRoomType.maximumOccupancy
                                    ? `${selectedRoomType.maximumOccupancy} guest${selectedRoomType.minimumOccupancy > 1 ? 's' : ''}`
                                    : `${selectedRoomType.minimumOccupancy} to ${selectedRoomType.maximumOccupancy} guests`
                                }`)}
                          </FormHelperText>
                        </FormControl>
                      )}
                    />
                  </Grid>

                  {/* Summary */}
                  <Grid item xs={12}>
                    <SummaryCard data={summary!} />
                  </Grid>
                </>
              )}
            </Grid>
          )}
        </RenderContent>
      </DialogContent>
      <DialogActions>
        <LoadingButton variant="text" disabled={isSubmitting} onClick={onCancel}>
          Cancel
        </LoadingButton>
        <LoadingButton variant="contained" type="submit" loading={isSubmitting} disabled={!filteredHotels.length}>
          {isEditMode ? 'Update' : 'Save'}
        </LoadingButton>
      </DialogActions>
    </Dialog>
  )
}

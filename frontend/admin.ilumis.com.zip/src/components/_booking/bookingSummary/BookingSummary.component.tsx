import { Box, Grid, Link as MuiLink, Stack } from '@mui/material'
import { MdOutlineAirplaneTicket, MdOutlineGavel, MdOutlineHotel } from 'react-icons/md'
import { RiBillLine } from 'react-icons/ri'

import SummaryCard from '@/components/_card/summaryCard/SummaryCard.component'
import SummaryCountCard from '@/components/_card/summaryCountCard/SummaryCountCard.component'
import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import SmartPopover from '@/components/smartPopover/SmartPopover.component'
import { useReduxSelector } from '@/hooks'
import { formatToTitleCase } from '@/utils'
import { PiIdentificationBadge } from 'react-icons/pi'
import { TbUsersGroup } from 'react-icons/tb'
import { BookingSummaryProps } from './BookingSummary.type'

export default function BookingSummary({ data }: BookingSummaryProps) {
  const totalRegistrationFee = data.orderDetails.find((item) => item.type === 'registration')?.amount || 0
  const organization = useReduxSelector((state) => state.organization)

  const SUMMARY_COUNTS = [
    { label: 'Number of guests', value: data.guestDetails.length, Icon: TbUsersGroup },
    { label: 'Number of visas', value: data.guestDetails.filter((item) => item.visaAssistanceRequired).length, Icon: PiIdentificationBadge },
    { label: 'Total visas fees', value: data.orderDetails.find((item) => item.type === 'visa')?.amount || 0, type: 'amount' as const, Icon: MdOutlineAirplaneTicket },
    { label: 'Total accommodation', value: data.orderDetails.find((item) => item.type === 'accommodation')?.amount || 0, type: 'amount' as const, Icon: MdOutlineHotel },
    { label: 'Total registration fees', value: totalRegistrationFee, type: 'amount' as const, Icon: RiBillLine },
    ...(data.penalties
      ? [
          {
            label: (
              <Stack direction="row" justifyContent="space-between" columnGap={2} rowGap={0.5} flexWrap="wrap">
                <Box>Total penalty fees</Box>
                <SmartPopover>
                  <SmartPopover.Toggle>
                    <MuiLink variant="body1" color="text.secondary" sx={{ textDecorationColor: '#ccc' }}>
                      Details
                    </MuiLink>
                  </SmartPopover.Toggle>
                  <SmartPopover.Content>
                    <SummaryCard heading={false} data={data.orderPenalties?.map((item) => ({ label: formatToTitleCase(item.penaltyName), value: item.amount, type: 'amount' })) || []} />
                  </SmartPopover.Content>
                </SmartPopover>
              </Stack>
            ),
            value: data.penalties,
            type: 'amount' as const,
            Icon: MdOutlineGavel,
          },
        ]
      : []),
  ]

  return (
    <>
      {/* Counts */}
      <Grid container spacing={2} mb={3}>
        {SUMMARY_COUNTS.map((item, index) => (
          <Grid item xs={6} sm={4} lg={3} key={index}>
            <SummaryCountCard data={item} />
          </Grid>
        ))}
      </Grid>

      {/* Total */}
      <SummaryCard
        data={[
          { label: `Grand Total (${organization.displayCurrency.code})`, value: data.totalAmountInDisplayCurrency, type: 'amount', isTotal: true },
          { label: `Grand Total (${organization.defaultCurrency.code})`, value: <DisplayPrice code={organization.defaultCurrency.code} price={data.totalAmountInDefaultCurrency} />, isTotal: true },
        ]}
      />
    </>
  )
}

import { BookingDTO } from '@/dto/Booking.dto'

export type BookingSummaryProps = {
  data: BookingDTO
}

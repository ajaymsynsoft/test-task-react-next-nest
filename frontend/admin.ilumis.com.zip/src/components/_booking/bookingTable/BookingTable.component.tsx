import { DataGrid } from '@mui/x-data-grid'
import { useRouter } from 'next/router'

import { useColumns } from './BookingTable.hook'
import { usePagination, useReduxSelector } from '@/hooks'
import { BookingTableProps } from './BookingTable.type'

export default function BookingTable(props: BookingTableProps) {
  const { data, loading } = props
  const columns = useColumns()
  const router = useRouter()
  const { role } = useReduxSelector((state) => state.layout.profile)
  const { paginationModel, setPaginationModel } = usePagination()

  return (
    <DataGrid
      loading={loading}
      columns={columns}
      rowCount={data.totalCount || 0}
      rows={data.list}
      paginationModel={paginationModel}
      columnVisibilityModel={{
        user: role !== 'customer',
      }}
      onPaginationModelChange={setPaginationModel}
    />
  )
}

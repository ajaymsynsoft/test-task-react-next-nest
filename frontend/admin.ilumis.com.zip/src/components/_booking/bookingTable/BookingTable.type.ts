import { TBookingList } from '@/redux/api/booking.api'
import { PaginationApiResponse } from '@/types'

export type BookingTableProps = {
  data: PaginationApiResponse<TBookingList>
  loading?: boolean
}

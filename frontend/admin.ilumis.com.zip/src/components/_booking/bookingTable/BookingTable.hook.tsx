import moment from 'moment'
import Link from 'next/link'
import { useRouter } from 'next/router'
import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'
import { Chip, Stack, Link as MuiLink, Typography, Tooltip } from '@mui/material'
import { MdRemoveRedEye } from 'react-icons/md'

import UserInfoCard from '@/components/_card/userInfoCard/UserInfoCard.component'
import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import SmartPopover from '@/components/smartPopover/SmartPopover.component'
import { formatToTitleCase, getStatusColor } from '@/utils'
import { useReduxSelector } from '@/hooks'
import { TBookingList } from '@/redux/api/booking.api'

export const useColumns = () => {
  const router = useRouter()
  const { modules, role } = useReduxSelector((state) => state.layout.profile)

  const columns: GridColDef<TBookingList>[] = [
    {
      field: 'id',
      headerName: 'ID',
      sortable: false,
      minWidth: 85,
      width: 85,
      renderCell: ({ row }) => (
        <MuiLink component={Link} href={role === 'customer' ? `/customer/my-bookings/edit/${row.id}` : `/dashboard/bookings/edit/${row.id}`}>
          #{row.id}
        </MuiLink>
      ),
    },
    {
      field: 'event',
      headerName: 'Event',
      sortable: false,
      flex: 1,
      minWidth: 190,
      valueFormatter: (value: TBookingList['event']) => value!.name,
    },
    {
      field: 'user',
      headerName: 'Customer',
      sortable: false,
      minWidth: 150,
      renderCell: ({ row: { user } }) => (
        <SmartPopover>
          <SmartPopover.Toggle>
            <MuiLink color="text.secondary" noWrap>
              {user!.firstName} {user!.lastName}
            </MuiLink>
          </SmartPopover.Toggle>
          <SmartPopover.Content>
            <UserInfoCard dataType="customer" data={user!} />
          </SmartPopover.Content>
        </SmartPopover>
      ),
    },
    {
      field: 'totalAmountInDisplayCurrency',
      headerName: 'Amount',
      sortable: false,
      minWidth: 130,
      display: 'flex',
      renderCell: ({ row }) => (
        <Stack>
          {row.paymentStatus === 'partiallyPaid' ? (
            <>
              <Typography variant="body2">
                Paid: <DisplayPrice price={row.paidAmount} />
              </Typography>
              <Typography variant="body2">
                Unpaid: <DisplayPrice price={row.unpaidAmount} />
              </Typography>
            </>
          ) : (
            <DisplayPrice price={row.totalAmountInDisplayCurrency} />
          )}
        </Stack>
      ),
    },
    {
      field: 'orderDate',
      headerName: 'Order Date',
      sortable: false,
      minWidth: 125,
      renderCell: ({ row }) => (row.orderDate ? moment(row.orderDate).format() : ''),
    },
    {
      field: 'status',
      headerName: 'Booking Status',
      sortable: false,
      minWidth: 125,
      renderCell: (params) => {
        return <Chip label={formatToTitleCase(params.value)} variant="outlined" color={getStatusColor(params.value)} />
      },
    },
    {
      field: 'paymentStatus',
      headerName: 'Payment Status',
      sortable: false,
      minWidth: 130,
      renderCell: (params) => {
        return <Chip label={formatToTitleCase(params.value)} variant="outlined" color={getStatusColor(params.value)} />
      },
    },
    role === 'customer'
      ? {
          field: 'action',
          headerName: 'Action',
          sortable: false,
          minWidth: 115,
          renderCell: ({ row }) => (
            <MuiLink component={Link} href={`/customer/my-bookings/edit/${row.id}`}>
              View details
            </MuiLink>
          ),
        }
      : {
          field: 'actions',
          headerName: 'Actions',
          sortable: false,
          minWidth: 80,
          width: 80,
          align: 'center',
          type: 'actions',
          getActions: (params) => {
            const actions = []
            if (modules[12].permissions.view)
              actions.push(
                <Tooltip title="View booking" key="view">
                  <GridActionsCellItem label="View booking" icon={<MdRemoveRedEye />} onClick={(_) => router.push(`/dashboard/bookings/edit/${params.id}`)} />
                </Tooltip>,
              )
            return actions
          },
        },
  ]

  return columns
}

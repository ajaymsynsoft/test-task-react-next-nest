import { Card, Grid, Stack, Typography } from '@mui/material'

import RegistrationFeesTable from '@/components/_booking/registrationFeesTable/RegistrationFeesTable.component'
import AccommodationTable from '@/components/_booking/accommodationTable/AccommodationTable.component'
import VisaForm from '@/components/_booking/visaForm/VisaForm.component'
import UserInfoCard from '@/components/_card/userInfoCard/UserInfoCard.component'
import BookingSummary from '@/components/_booking/bookingSummary/BookingSummary.component'
import EventCard from '@/components/_card/eventCard/EventCard.component'
import BankDetails from '../bankDetails/BankDetails.component'
import SummaryCard from '@/components/_card/summaryCard/SummaryCard.component'
import { usePage, useReduxSelector } from '@/hooks'
import { BookingDetailsProps } from './BookingDetails.type'

export default function BookingDetails({ data, slotProps, headingVariant = 'h3' }: BookingDetailsProps) {
  const profile = useReduxSelector((state) => state.layout.profile)
  const { isCustomerDashboard } = usePage()

  return (
    <Grid container spacing={5}>
      {/* Event */}
      {slotProps?.event?.show !== false && (
        <Grid item xs={12}>
          <Stack gap={2}>
            <Typography variant={headingVariant}>Event</Typography>
            <EventCard.dashboard data={data.event!} />
          </Stack>
        </Grid>
      )}

      {/* Account informations */}
      {slotProps?.accountInformation?.show !== false && (
        <Grid item xs={12}>
          <Stack gap={2}>
            <Typography variant={headingVariant}>{slotProps?.accountInformation?.heading || 'Account informations'}</Typography>
            <Card variant="outlined" sx={{ bgcolor: 'transparent' }}>
              {profile.role === 'customer' ? <UserInfoCard dataType="profile" data={profile} /> : <UserInfoCard dataType="customer" data={data.user!} />}
            </Card>
          </Stack>
        </Grid>
      )}

      {/* Registration Fees Table */}
      {slotProps?.guestRegistration?.show !== false && (
        <Grid item xs={12}>
          <Stack gap={2}>
            <Typography variant={headingVariant}>Guests registration fees</Typography>
            <RegistrationFeesTable data={data} />
          </Stack>
        </Grid>
      )}

      {/* Accommodation Table */}
      {slotProps?.accommodation?.show !== false && data.isAccommodationEnabled && (
        <Grid item xs={12}>
          <Stack gap={2}>
            <Typography variant={headingVariant}>Accommodation preferences</Typography>
            <AccommodationTable data={data} actions={false} />
          </Stack>
        </Grid>
      )}

      {/* Visa */}
      {slotProps?.visa?.show !== false && data.isVisaEnabled && (
        <Grid item xs={12}>
          <VisaForm data={data} isViewMode headingVariant={headingVariant} />
        </Grid>
      )}

      {/* Summary */}
      {slotProps?.summary?.show !== false && (
        <Grid item xs={12}>
          <BookingSummary data={data} />
        </Grid>
      )}

      {/* Paid & Unpaid Amount */}
      {slotProps?.amount?.show !== false && (
        <Grid item xs={12} mt={-3}>
          {data.status !== 'draft' && (data.paymentStatus === 'partiallyPaid' || data.paymentStatus === 'unpaid') && (
            <SummaryCard
              heading={false}
              data={[
                { label: 'Paid amount', value: data.paidAmount, type: 'amount' },
                { label: 'Unpaid amount', value: data.unpaidAmount, type: 'amount' },
              ]}
            />
          )}
        </Grid>
      )}

      {/* Bank Details */}
      {slotProps?.bankDetails?.show !== false && isCustomerDashboard && data.paymentType == 'bankTransfer' && data.status !== 'cancelled' && (data.paymentStatus === 'partiallyPaid' || data.paymentStatus === 'unpaid') && (
        <Grid item xs={12} mt={-3}>
          <BankDetails />
        </Grid>
      )}
    </Grid>
  )
}

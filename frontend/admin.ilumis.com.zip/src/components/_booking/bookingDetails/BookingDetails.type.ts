import { BookingDTO } from '@/dto/Booking.dto'

export type BookingDetailsProps = {
  data: BookingDTO
  headingVariant?: 'h2' | 'h3'
  slotProps?: {
    event?: {
      show?: boolean
    }
    accountInformation?: {
      heading?: string
      show?: boolean
    }
    guestRegistration?: {
      show?: boolean
    }
    accommodation?: {
      show?: boolean
    }
    visa?: {
      show?: boolean
    }
    summary?: {
      show?: boolean
    }
    amount?: {
      show?: boolean
    }
    bankDetails?: {
      show?: boolean
    }
  }
}

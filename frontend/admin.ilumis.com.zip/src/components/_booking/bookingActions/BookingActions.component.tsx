import toast from 'react-hot-toast'
import * as yup from 'yup'
import { ChangeEvent, useRef, useState } from 'react'
import { useRouter } from 'next/router'
import { LoadingButton } from '@mui/lab'
import { IoMdArrowDropdown } from 'react-icons/io'
import { ButtonGroup, useMediaQuery, Theme, Button, Menu, MenuItem, ListItemIcon, Box, IconButton, CircularProgress } from '@mui/material'
import { MdEventBusy, MdMoreVert, MdOutlineEdit, MdOutlineFileDownload, MdOutlineLocalPrintshop, MdOutlinePayment, MdOutlineReceiptLong } from 'react-icons/md'

import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import UpdateAmountPopup from './components/updateAmountPopup/UpdateAmountPopup.component'
import SelectPaymentMethod from '@/components/_booking/selectPaymentMethod/SelectPaymentMethod.component'
import { useBookingPaymentMutation, useCancelBookingMutation, useLazyGenerateBookingPdfQuery, useUploadBankReceiptMutation } from '@/redux/api/booking.api'
import { BookingActionsProps, TLoading, TMenuItem } from './BookingActions.type'
import { fileTest, IMAGE_EXTENSIONS } from '@/utils'
import { useUploadFileMutation } from '@/redux/api/common.api'
import { usePage, useReduxSelector } from '@/hooks'

export default function BookingActions({ data }: BookingActionsProps) {
  const router = useRouter()
  const printIframeRef = useRef<HTMLIFrameElement>()
  const bankReceiptInputRef = useRef<HTMLInputElement | null>(null)
  const isMdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'))
  const { isAdminDashboard, isCustomerDashboard } = usePage()
  const { modules } = useReduxSelector((state) => state.layout.profile)

  const canUploadBankReceipt = isCustomerDashboard && data.paymentType === 'bankTransfer' && !data.bankReceiptImage && data.status !== 'cancelled' && (data.paymentStatus === 'partiallyPaid' || data.paymentStatus === 'unpaid')
  const canViewBankReceipt = data.paymentType === 'bankTransfer' && data.bankReceiptImage

  const [loading, setLoading] = useState<TLoading>({ pdf: false, invoice: false, bankReceipt: false, receipt: false })
  const updateLoading = (key: keyof TLoading, value: boolean) => setLoading((prev) => ({ ...prev, [key]: value }))

  const [moreMenuAnchorEl, setMoreMenuAnchorEl] = useState<null | HTMLElement>(null)
  const [showCancelBooking, setShowCancelBooking] = useState(false)
  const [showSelectPaymentMethod, setshowSelectPaymentMethod] = useState(false)
  const [showUpdateAmount, setShowUpdateAmount] = useState(false)

  const handleCloseMenu = () => setMoreMenuAnchorEl(null)

  const [generateBookingPdf] = useLazyGenerateBookingPdfQuery()
  const [cancelBooking, cancelBookingApiState] = useCancelBookingMutation()
  const [bookingPayment] = useBookingPaymentMutation()
  const [uploadFile] = useUploadFileMutation()
  const [uploadBankReceipt] = useUploadBankReceiptMutation()

  const printBookingPdf = async () => {
    const loadingToast = toast.loading('Printing invoice')
    try {
      updateLoading('pdf', true)
      const blob = await generateBookingPdf({ bookingId: router.query.id as string, type: 'invoice' }, true).unwrap()
      const url = URL.createObjectURL(blob)

      const iframe = printIframeRef.current!
      iframe.src = url

      iframe.onload = function () {
        iframe.contentWindow?.focus()
        iframe.contentWindow?.print()
      }
    } finally {
      toast.dismiss(loadingToast)
      updateLoading('pdf', false)
    }
  }

  const downloadBookingPdf = async (type: 'receipt' | 'invoice') => {
    const loadingToast = toast.loading(`Downloading ${type}`)
    try {
      updateLoading(type, true)
      const blob = await generateBookingPdf({ bookingId: router.query.id as string, type }, true).unwrap()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `Booking ${type} #${router.query.id}`
      document.body.appendChild(a)
      a.click()
      a.remove()
    } finally {
      toast.dismiss(loadingToast)
      updateLoading(type, false)
    }
  }

  const handleUploadBankReceipt = async (e: ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return
    updateLoading('bankReceipt', true)
    const loadingToast = toast.loading('Uploading Bank Receipt')

    const validateFile = yup
      .mixed<File | string>()
      .required()
      .test(fileTest({ required: true, size: 5, extensions: IMAGE_EXTENSIONS, message: { extensions: 'Only image file is accepted' } }))

    try {
      const file = validateFile.validateSync(e.target.files[0]) as File
      const [image] = await uploadFile({ files: file, folderName: 'booking' }).unwrap()
      await uploadBankReceipt({ bookingId: data.id, bankReceiptImage: image }).unwrap()
    } catch (err: any) {
      toast.error(err?.message || 'Something went wrong')
    } finally {
      updateLoading('bankReceipt', false)
      toast.dismiss(loadingToast)
      bankReceiptInputRef.current!.value = ''
    }
  }

  const MENU_ITEMS: TMenuItem[] = [
    {
      Icon: MdOutlinePayment,
      label: 'Pay Unpaid Amount',
      show: isCustomerDashboard && (data.paymentStatus === 'partiallyPaid' || data.paymentStatus === 'unpaid') && data.status !== 'cancelled' ? (isMdUp ? 'button' : 'menu') : 'hide',
      onClick: () => setshowSelectPaymentMethod(true),
    },
    { Icon: MdOutlineReceiptLong, label: 'Upload Bank Receipt', loading: loading.bankReceipt, show: canUploadBankReceipt ? (isMdUp ? 'button' : 'menu') : 'hide', onClick: () => bankReceiptInputRef.current!.click() },
    { Icon: MdOutlineReceiptLong, label: 'Bank Receipt', show: canViewBankReceipt ? (isMdUp ? 'button' : 'menu') : 'hide', onClick: () => window.open(data.bankReceiptImage, '_blank') },
    { Icon: MdOutlineFileDownload, label: 'Invoice', loading: loading.invoice, show: isMdUp ? 'button' : 'menu', onClick: () => downloadBookingPdf('invoice') },
    { Icon: MdOutlineLocalPrintshop, label: 'Print Invoice', loading: loading.pdf, show: 'menu', onClick: printBookingPdf },
    { Icon: MdEventBusy, label: 'Cancel Booking', show: isCustomerDashboard && data.status !== 'cancelled' ? 'menu' : 'hide', onClick: () => setShowCancelBooking(true) },
    {
      Icon: MdOutlineEdit,
      label: 'Update Amount',
      show: isAdminDashboard && modules[12].permissions.edit && (data.paymentStatus === 'partiallyPaid' || data.paymentStatus === 'unpaid') && data.status !== 'cancelled' ? 'menu' : 'hide',
      onClick: () => setShowUpdateAmount(true),
    },
    { Icon: MdOutlineFileDownload, label: 'Receipt', loading: loading.receipt, show: isCustomerDashboard ? 'menu' : 'hide', disabled: data.paymentStatus !== 'paid', onClick: () => downloadBookingPdf('receipt') },
  ]

  const filterMenuItems = (show: TMenuItem['show']) => MENU_ITEMS.filter((item) => item.show === show)

  return (
    <>
      {/* Buttons */}
      <ButtonGroup>
        {filterMenuItems('button').map((item, index) => (
          <LoadingButton startIcon={<item.Icon />} onClick={item.onClick} disabled={item.disabled} loading={item.loading} key={index}>
            {item.label}
          </LoadingButton>
        ))}

        {!!filterMenuItems('menu').length && isMdUp && (
          <Button size="small" onClick={(e) => setMoreMenuAnchorEl(e.currentTarget)}>
            <IoMdArrowDropdown />
          </Button>
        )}
      </ButtonGroup>

      {!!filterMenuItems('menu').length && !isMdUp && (
        <IconButton onClick={(e) => setMoreMenuAnchorEl(e.currentTarget)}>
          <MdMoreVert />
        </IconButton>
      )}

      {/* Dropdown Menus */}
      <Menu
        sx={{ mt: 1 }}
        anchorEl={moreMenuAnchorEl}
        open={!!moreMenuAnchorEl}
        onClose={() => setMoreMenuAnchorEl(null)}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        {filterMenuItems('menu').map((item, index) => (
          <MenuItem
            key={index}
            disabled={item.disabled || item.loading}
            onClick={() => {
              handleCloseMenu()
              item.onClick()
            }}
          >
            <ListItemIcon>{item.loading ? <CircularProgress size={20} color="inherit" /> : <item.Icon />}</ListItemIcon>
            {item.label}
          </MenuItem>
        ))}
      </Menu>

      {/* Cancel Booking Confirmation */}
      <ConfirmationPopup
        heading="Cancel booking"
        subheading="Are you sure to cancel this booking?"
        cancelButtonText="Close"
        acceptButtonText="Cancel Booking"
        loading={cancelBookingApiState.isLoading}
        open={showCancelBooking}
        onCancel={() => setShowCancelBooking(false)}
        onAccept={() =>
          cancelBooking(data.id)
            .unwrap()
            .then(() => setShowCancelBooking(false))
        }
      />

      {/* Update Amount Popup */}
      {showUpdateAmount && <UpdateAmountPopup data={data} onCancel={() => setShowUpdateAmount(false)} />}

      {/* Select Payment Method */}
      {showSelectPaymentMethod && (
        <SelectPaymentMethod
          data={data}
          amountPay={data.unpaidAmount}
          paymentMethods={['wallet', 'card']}
          onCancel={() => setshowSelectPaymentMethod(false)}
          onSubmit={async (formData) => {
            const { redirectUrl } = await bookingPayment({
              ...formData,
              successUrl: `${location.origin}${location.pathname}?status=success&bookingUnpaidAmountPopup=true`,
              cancelUrl: `${location.origin}${location.pathname}?status=failed&bookingUnpaidAmountPopup=true`,
              isPayingUnpaidAmount: true,
            }).unwrap()
            window.location.href = redirectUrl
          }}
        />
      )}

      {/* PDF Print */}
      <Box component="iframe" display="none" ref={printIframeRef} />

      {/* Upload Receipt */}
      {canUploadBankReceipt && <Box component="input" type="file" accept="image/*" ref={bankReceiptInputRef} display="none" onChange={handleUploadBankReceipt} />}
    </>
  )
}

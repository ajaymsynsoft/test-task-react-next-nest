import { BookingDTO } from '@/dto/Booking.dto'
import { IconType } from 'react-icons'

export type BookingActionsProps = {
  data: BookingDTO
}

export type TMenuItem = {
  Icon: IconType
  label: string
  show: 'button' | 'menu' | 'hide'
  onClick: () => void
  loading?: boolean
  disabled?: boolean
}

export type TLoading = Record<'pdf' | 'invoice' | 'bankReceipt' | 'receipt', boolean>

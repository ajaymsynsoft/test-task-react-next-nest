import { BookingDTO } from '@/dto/Booking.dto'

export type UpdateAmountPopupProps = {
  onCancel: () => void
  data: BookingDTO
}

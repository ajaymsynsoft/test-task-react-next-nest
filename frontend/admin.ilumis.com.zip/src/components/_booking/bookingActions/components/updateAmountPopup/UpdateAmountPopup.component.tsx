import { useState } from 'react'
import { LoadingButton } from '@mui/lab'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { Box, Dialog, DialogActions, DialogContent, DialogTitle, Grid, Stack, Typography } from '@mui/material'

import InputField from '@/components/_ui/inputField/InputField.component'
import SummaryCard from '@/components/_card/summaryCard/SummaryCard.component'
import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import { UpdateAmountPopupProps } from './UpdateAmountPopup.type'
import { schema, TSchema } from './UpdateAmountPopup.config'
import { useUpdateAmountMutation } from '@/redux/api/booking.api'

export default function UpdateAmountPopup({ onCancel, data }: UpdateAmountPopupProps) {
  const [updateAmount, { isLoading }] = useUpdateAmountMutation()
  const [showConfirmation, setShowConfirmation] = useState(false)

  const {
    handleSubmit,
    control,
    getValues,
    formState: { isSubmitting },
    setError,
    watch,
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      bookingId: data.id,
    },
  })

  const onSubmit = (formData: TSchema) => {
    if (formData.amount > data.unpaidAmount) return setError('amount', { type: 'validate', message: `Amount is more than unpaid amount` }, { shouldFocus: true })
    setShowConfirmation(true)
  }

  const handleUpdateAmount = async () => {
    const formData = schema.validateSync(getValues())

    await updateAmount(formData).unwrap()
    onCancel()
  }

  return !showConfirmation ? (
    <Dialog open fullWidth component="form" onClose={() => !isSubmitting && onCancel()} onSubmit={handleSubmit(onSubmit)} {...{ noValidate: true }}>
      <DialogTitle>Update amount</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <InputField name="amount" label="Amount *" type="number" control={control} inputProps={{ name: 'ignore' }} />
          </Grid>
          <Grid item xs={12} mt={1}>
            <SummaryCard
              heading={false}
              data={[
                { label: 'Paid amount', value: data.paidAmount, type: 'amount' },
                { label: 'Unpaid amount', value: data.unpaidAmount, type: 'amount' },
              ]}
            ></SummaryCard>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <LoadingButton variant="text" disabled={isSubmitting} onClick={onCancel}>
          Cancel
        </LoadingButton>
        <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
          Continue
        </LoadingButton>
      </DialogActions>
    </Dialog>
  ) : (
    <ConfirmationPopup
      heading="Payment confirmation"
      subheading={
        <Stack mt={1}>
          <SummaryCard
            heading={false}
            data={[
              { label: 'Total Outstanding Amount:', value: data.unpaidAmount, type: 'amount' },
              { label: 'Payment Amount:', value: watch('amount'), type: 'amount' },
              { label: 'Remaining Balance:', value: data.unpaidAmount - watch('amount'), type: 'amount' },
            ]}
          ></SummaryCard>
        </Stack>
      }
      cancelButtonText="Back"
      acceptButtonText="Proceed"
      loading={isLoading}
      onCancel={() => setShowConfirmation(false)}
      onAccept={() => handleUpdateAmount().then(() => setShowConfirmation(false))}
    />
  )
}

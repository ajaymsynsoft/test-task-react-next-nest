import * as yup from 'yup'

export const schema = yup.object({
  bookingId: yup.number().required(),
  amount: yup.number().required().positive().max(10000000000),
})

export type TSchema = yup.InferType<typeof schema>

import { BookingDTO } from '@/dto/Booking.dto'
import { MenuOption } from '@/types'

export type BookingDetailsTabProps = {
  data: BookingDTO
  loading: boolean
  disableGutters?: boolean
}

export type TabType = Omit<MenuOption, 'children' | 'id'> & {
  id: string
  Content: React.ComponentType<TabItemProps>
}

export type TabItemProps = {
  data: BookingDTO
  loading: boolean
}

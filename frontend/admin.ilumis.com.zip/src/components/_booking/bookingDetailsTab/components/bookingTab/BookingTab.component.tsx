import BookingDetails from '@/components/_booking/bookingDetails/BookingDetails.component'
import { TabItemProps } from '../../BookingDetailsTab.type'
import { usePage } from '@/hooks'

export default function BookingTab(props: TabItemProps) {
  const { isCustomerDashboard } = usePage()
  return <BookingDetails {...props} slotProps={{ accountInformation: { heading: 'Customer Information', show: !isCustomerDashboard } }} />
}

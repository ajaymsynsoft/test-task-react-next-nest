import * as yup from 'yup'

export const schema = yup.object({
  oldGuestId: yup.number().required(),
  newGuestId: yup
    .string()
    .trim()
    .test('validate', 'Required *', function (value) {
      const isGuestAdd = this.parent.passportFirstName && this.parent.passportLastName && this.parent.passportNumber
      if (isGuestAdd || value) {
        return true
      }
      return false
    }),
  passportFirstName: yup
    .string()
    .trim()
    .when('newGuestId', {
      is: (value: string) => !value,
      then: (schema) => schema.required(),
      otherwise: (schema) => schema.notRequired(),
    }),
  passportLastName: yup
    .string()
    .trim()
    .when('newGuestId', {
      is: (value: string) => !value,
      then: (schema) => schema.required(),
      otherwise: (schema) => schema.notRequired(),
    }),
  passportNumber: yup
    .string()
    .trim()
    .when('newGuestId', {
      is: (value: string) => !value,
      then: (schema) => schema.required(),
      otherwise: (schema) => schema.notRequired(),
    }),
})

export type TSchema = yup.InferType<typeof schema>

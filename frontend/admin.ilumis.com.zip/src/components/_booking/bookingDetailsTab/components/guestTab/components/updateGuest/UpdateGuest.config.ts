import * as yup from 'yup'
import moment from 'moment'

import { fileTest, IMAGE_EXTENSIONS, passportNumberTest, stringTest } from '@/utils'

export const schema = yup.object({
  photo: yup
    .mixed<File | string>()
    .required()
    .test(fileTest({ required: true, size: 5, extensions: IMAGE_EXTENSIONS, message: { extensions: 'Only image file is accepted' } })),
  passportImage: yup
    .mixed<File | string>()
    .required()
    .test(fileTest({ required: true, size: 5, extensions: [...IMAGE_EXTENSIONS, 'pdf'], message: { extensions: 'Image and PDF files are accepted' } })),
  guestId: yup.number().required(),
  orderId: yup.number().required(),
  passportNumber: yup.string().trim().required().test(passportNumberTest),
  passportIssueDate: yup
    .string()
    .nullable()
    .test('validate', 'Did your passport issued before your birth', function (passportIssueDate) {
      const dob = this.parent.dob
      if (dob && passportIssueDate) return moment(passportIssueDate).isAfter(dob)
      return true
    }),
  passportExpiryDate: yup
    .string()
    .nullable()
    .test('validate', 'It must be greater than "Passport issue date"', function (passportExpiryDate) {
      const passportIssueDate = this.parent.passportIssueDate
      if (passportIssueDate && passportExpiryDate) return moment(passportExpiryDate).isAfter(passportIssueDate)
      return true
    }),
  dob: yup.string().nullable(),
  occupation: yup.string().trim().max(300).test(stringTest),
  nationality: yup.string().trim().required(),
  jobTitle: yup.string().trim().max(300).test(stringTest),
  workPlace: yup.string().trim().max(300).test(stringTest),
  accessibilityInfo: yup.array().of(yup.number().defined()).required(),
  departureFlightAirport: yup.string().trim().max(300).test(stringTest),
  departureFlightNumber: yup.string().trim().max(10).test(stringTest),
  departureDateTime: yup.string().nullable(),
  departureNotes: yup.string().trim().max(1000),
  arrivalFlightAirport: yup.string().trim().max(300).test(stringTest),
  arrivalFlightNumber: yup.string().trim().max(10).test(stringTest),
  arrivalDateTime: yup.string().nullable(),
  arrivalNotes: yup.string().trim().max(1000),
})

export type TSchema = yup.InferType<typeof schema>

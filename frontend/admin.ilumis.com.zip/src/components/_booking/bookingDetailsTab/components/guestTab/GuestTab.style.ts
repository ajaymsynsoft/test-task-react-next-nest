import { alpha } from '@mui/material'
import { Style } from '@/types/Style.type'

export const style: Style = {
  card: {
    '--border-radius': '20px',
    borderRadius: 'var(--border-radius)',
    position: 'relative',
    overflow: 'unset',
    '[class*="dashed-border-"]': {
      // border: '1px dashed',
      border: { xs: 'none', md: '1px dashed' },
      borderColor: { xs: 'dividerDark', md: 'dividerDark' },
      position: 'relative',
      ':before, :after': {
        content: { xs: 'none', md: `''` },
        position: 'absolute',
        height: 20,
        width: 20,
        bgcolor: 'background.default',
        borderRadius: '100%',
        border: '1px solid',
        borderColor: (theme) => `${theme.palette.dividerDark} ${theme.palette.dividerDark} transparent transparent`,
      },
      '&.dashed-border-top': {
        borderWidth: '1px 0 0 0',
        ':before': {
          top: -11,
          left: -11,
          transform: 'rotate(45deg)',
        },
        ':after': {
          top: -11,
          right: -11,
          transform: 'rotate(-135deg)',
        },
      },
      '&.dashed-border-left': {
        borderWidth: '0 0 0 1px',
        bgcolor: (theme) => alpha(theme.palette.primary.main, 0.07),
        borderTopRightRadius: 'var(--border-radius)',
        borderBottomRightRadius: 'var(--border-radius)',
        ':before': {
          top: -11,
          left: -11,
          transform: 'rotate(135deg)',
        },
        ':after': {
          bottom: -11,
          left: -11,
          transform: 'rotate(-45deg)',
        },
      },
    },
  },
  backdrop: {
    color: '#fff',
    zIndex: (theme) => theme.zIndex.drawer,
    position: 'absolute',
    bgcolor: 'rgba(255, 255, 255, 0.38)',
  },
}

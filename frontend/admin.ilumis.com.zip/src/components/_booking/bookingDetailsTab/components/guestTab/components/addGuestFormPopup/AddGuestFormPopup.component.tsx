import { LoadingButton } from '@mui/lab'
import { Grid, Stack, Dialog, DialogActions, DialogTitle, DialogContent } from '@mui/material'

import InputField from '@/components/_ui/inputField/InputField.component'
import { AddGuestFormPopupProps } from './AddGuestFormPopup.type'

export default function AddGuestFormPopup(props: AddGuestFormPopupProps) {
  const { onCancel, isEditMode, open, isSubmitting, control, handleSubmit, setValue } = props

  const onSubmit = async () => {
    setValue('newGuestId', 0)
    onCancel()
  }

  return (
    <Dialog open={open} fullWidth component="form" maxWidth="sm" onClose={() => !isSubmitting && onCancel()} onSubmit={handleSubmit(onSubmit)} {...{ noValidate: true }}>
      <DialogTitle>{isEditMode ? 'Update Guest' : 'Add new guest'}</DialogTitle>
      <DialogContent dividers>
        <Grid container component="form" noValidate spacing={2} onSubmit={handleSubmit(onSubmit)}>
          {/* First Name  */}
          <Grid item xs={12} sm={6}>
            <InputField name="passportFirstName" label="First name *" helperText="Must match from passport" control={control} />
          </Grid>

          {/* Last Name  */}
          <Grid item xs={12} sm={6}>
            <InputField name="passportLastName" label="Last name *" helperText="Must match from passport" control={control} />
          </Grid>

          {/* Passport Number */}
          <Grid item xs={12}>
            <InputField name="passportNumber" label="Passport number *" control={control} />
          </Grid>

          {/* Footer */}
          <Grid item xs={12}>
            <Stack direction="row" justifyContent="end" gap={1}></Stack>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <LoadingButton variant="text" disabled={isSubmitting} onClick={onCancel}>
          Cancel
        </LoadingButton>
        <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
          {isEditMode ? 'Update' : 'Save'}
        </LoadingButton>
      </DialogActions>
    </Dialog>
  )
}

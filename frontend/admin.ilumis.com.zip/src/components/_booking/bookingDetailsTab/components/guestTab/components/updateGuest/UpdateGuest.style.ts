import { Style } from '@/types/Style.type'

export const style: Style = {
  accessibilityItem: {
    p: 1.5,
    flexDirection: 'column',
    position: 'relative',
    gap: 1,
    width: 1,
    textAlign: 'center',
    height: 1,
    whiteSpace: 'unset',
    '&:not(:hover)': {
      borderColor: 'divider',
    },
  },
  accessibilityItemCheckBox: {
    position: 'absolute',
    top: 1,
    right: 1,
    pointerEvents: 'none',
  },
}

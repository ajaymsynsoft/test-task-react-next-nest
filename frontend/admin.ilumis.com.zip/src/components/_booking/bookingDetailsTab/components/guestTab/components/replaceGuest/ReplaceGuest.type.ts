import { BookingDTO } from '@/dto/Booking.dto'

export type ReplaceGuestProps = {
  onCancel: () => void
  guestId: number
  data: BookingDTO
}

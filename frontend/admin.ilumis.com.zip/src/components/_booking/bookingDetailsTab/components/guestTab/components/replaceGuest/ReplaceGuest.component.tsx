import { useState } from 'react'
import { LoadingButton } from '@mui/lab'
import { yupResolver } from '@hookform/resolvers/yup'
import { Controller, useForm } from 'react-hook-form'
import { MdAdd, MdClose, MdEdit } from 'react-icons/md'
import { Autocomplete, Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, IconButton, Stack, TextField, Typography } from '@mui/material'

import AddGuestFormPopup from '../addGuestFormPopup/AddGuestFormPopup.component'
import { ReplaceGuestProps } from './ReplaceGuest.type'
import { TSchema, schema } from './ReplaceGuest.config'
import { useGetAvailableGuestListQuery, useGuestReplaceMutation } from '@/redux/api/guest.api'
import GuestInfoCard from '@/components/_card/guestInfoCard/GuestInfoCard.compoent'
import RenderContent from '@/components/renderContent/RenderContent.component'

export default function ReplaceGuest({ data, guestId, onCancel }: ReplaceGuestProps) {
  const guest = data.guestDetails.find((item) => item.id === guestId)!
  const guestListApiState = useGetAvailableGuestListQuery({ guestId: guest.id, orderId: guest.orderId })
  const [guestReplace] = useGuestReplaceMutation()
  const [addGuestOpen, setAddGuestOpen] = useState<boolean>(false)
  const [updateDetail, setUpdateFormDetail] = useState<boolean>(false)

  const {
    handleSubmit,
    control,
    getValues,
    watch,
    setValue,
    formState: { isSubmitting, errors },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      oldGuestId: guest?.id,
    },
  })

  const handleClearGuestForm = () => {
    setValue('passportFirstName', '')
    setValue('passportLastName', '')
    setValue('passportNumber', '')
  }

  const checkGuestValue = () => {
    if (watch('passportFirstName') && watch('passportLastName') && watch('passportNumber')) return true
    return false
  }

  const onSubmit = async () => {
    const formData = getValues()
    const successUrl = `${window.location.origin}/customer/my-bookings/edit/${data.id}`
    const cancelUrl = `${window.location.origin}/customer/my-bookings/edit/${data.id}`

    const { oldGuestId, newGuestId, passportFirstName, passportLastName, passportNumber } = formData
    const result: any = await guestReplace({ orderId: data.id, successUrl, cancelUrl, oldGuestId, newGuestId, passportFirstName, passportLastName, passportNumber })
    if (result?.data?.isPenalityApplied) window.location.href = result?.data?.paymentUrl
    else onCancel()
  }

  return (
    <>
      <Dialog open={!addGuestOpen && !updateDetail} fullWidth component="form" maxWidth="md" onClose={onCancel} onSubmit={handleSubmit(onSubmit)} {...{ noValidate: true }}>
        <DialogTitle>Replace Guest</DialogTitle>
        <DialogContent dividers>
          <RenderContent error={guestListApiState.isError} loading={guestListApiState.isLoading}>
            <Grid container spacing={2}>
              {/* Guest Assigned */}
              <Grid item xs={12} sm={6}>
                <Stack gap={2}>
                  <Typography variant="h4">Guest Assigned</Typography>
                  <GuestInfoCard data={guest} />
                </Stack>
              </Grid>

              {/* Available Guest */}
              <Grid item xs={12} sm={6}>
                <Stack gap={2}>
                  <Typography variant="h4">Select Guest</Typography>
                  {checkGuestValue() ? (
                    <Stack direction="row" justifyContent="space-between" sx={{ border: 1, borderColor: 'divider', borderRadius: 1, p: 2 }}>
                      <Stack gap={2}>
                        <GuestInfoCard data={{ ...guest, ...getValues() }} />
                      </Stack>
                      <Box>
                        <IconButton onClick={() => setUpdateFormDetail(true)}>
                          <MdEdit />
                        </IconButton>
                        <IconButton onClick={() => handleClearGuestForm()}>
                          <MdClose />
                        </IconButton>
                      </Box>
                    </Stack>
                  ) : (
                    <>
                      {/* Select Guest */}
                      <Stack>
                        <Controller
                          name="newGuestId"
                          control={control}
                          render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                            <Autocomplete
                              {...restField}
                              options={guestListApiState!.data}
                              value={guestListApiState!.data.find((item: any) => item.id === value) || null}
                              onChange={(_, value) => {
                                onChange(value?.id)
                                handleClearGuestForm()
                              }}
                              getOptionLabel={(option) => option.passportFirstName + ' ' + option.passportLastName}
                              renderInput={(params) => <TextField {...params} label="Available guest" inputRef={ref} error={!!error} helperText={error?.message} />}
                            />
                          )}
                        />
                      </Stack>

                      <Stack alignSelf="end">
                        <Button startIcon={<MdAdd />} onClick={() => setAddGuestOpen(true)}>
                          Add new guest
                        </Button>
                      </Stack>
                    </>
                  )}
                </Stack>
              </Grid>
            </Grid>
          </RenderContent>
        </DialogContent>
        <DialogActions>
          <LoadingButton variant="text" disabled={isSubmitting} onClick={onCancel}>
            Cancel
          </LoadingButton>
          <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
            Replace Guest
          </LoadingButton>
        </DialogActions>
      </Dialog>

      {/* Add New Guest Popup */}
      <AddGuestFormPopup
        open={addGuestOpen || updateDetail}
        onCancel={() => {
          setAddGuestOpen(false)
          setUpdateFormDetail(false)
        }}
        control={control}
        getValues={getValues}
        setValue={setValue}
        isEditMode={updateDetail}
        handleSubmit={handleSubmit}
        isSubmitting={isSubmitting}
      />
    </>
  )
}

import { Control } from 'react-hook-form'

export type AddGuestFormPopupProps = {
  open: boolean
  onCancel: () => void
  setValue: any
  handleSubmit: any
  control: Control<any>
  isSubmitting: boolean
  getValues: () => void
} & (
  | {
      isEditMode: false
    }
  | {
      isEditMode: true
    }
)

import moment from 'moment'
import { yupResolver } from '@hookform/resolvers/yup'
import { Controller, useForm } from 'react-hook-form'
import { LoadingButton } from '@mui/lab'
import { MobileDatePicker, MobileDateTimePicker } from '@mui/x-date-pickers'
import { MdAccessibility, MdFlightLand, MdFlightTakeoff } from 'react-icons/md'
import { Alert, Autocomplete, Button, Checkbox, Dialog, DialogActions, DialogContent, DialogTitle, FormHelperText, Grid, TextField, Typography } from '@mui/material'

import InputField from '@/components/_ui/inputField/InputField.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import HeadingWithIcon from '@/components/_ui/headingWithIcon/HeadingWithIcon.component'
import UploadField from '@/components/_ui/uploadField/UploadField.component'
import { useGetCountriesQuery, useUploadFileMutation } from '@/redux/api/common.api'
import { UpdateGuestProps } from './UpdateGuest.type'
import { TSchema, schema } from './UpdateGuest.config'
import { style } from './UpdateGuest.style'
import { removeSpace } from '@/utils'
import { useGetEventQuery } from '@/redux/api/event.api'
import { useUpdateGuestTransportationMutation } from '@/redux/api/guest.api'

export default function UpdateGuest({ data, guestId, onCancel }: UpdateGuestProps) {
  const guest = data.guestDetails.find((item) => item.id === guestId)!
  const countriesApiState = useGetCountriesQuery()
  const eventApiState = useGetEventQuery({ eventId: data.eventId })
  const [updateGuestTransportation] = useUpdateGuestTransportationMutation()
  const [uploadFile] = useUploadFileMutation()

  const {
    handleSubmit,
    control,
    getValues,
    setValue,
    setError,
    trigger,
    formState: { isSubmitting, isSubmitted },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      passportImage: guest.passportImage,
      photo: guest.photo,
      accessibilityInfo: guest.accessibilityInfo || [],
      guestId: guest.id,
      orderId: guest.orderId,
      passportNumber: guest.passportNumber,
      arrivalDateTime: guest.arrivalDateTime || null,
      arrivalFlightAirport: guest.arrivalFlightAirport,
      arrivalFlightNumber: guest.arrivalFlightNumber,
      arrivalNotes: guest.arrivalNotes,
      departureDateTime: guest.departureDateTime || null,
      departureFlightAirport: guest.departureFlightAirport,
      departureFlightNumber: guest.departureFlightNumber,
      departureNotes: guest.departureNotes,
      jobTitle: guest.jobTitle,
      nationality: guest.nationality,
      occupation: guest.occupation,
      passportExpiryDate: guest.passportExpiryDate || null,
      passportIssueDate: guest.passportIssueDate || null,
      dob: guest.dob || null,
      workPlace: guest.workPlace,
    },
  })

  const onSubmit = async () => {
    const formData = schema.validateSync(getValues())

    if (formData.photo instanceof File) {
      const [image] = await uploadFile({ files: formData.photo, folderName: 'guest' }).unwrap()
      formData.photo = image
      setValue('photo', image)
    }
    if (formData.passportImage instanceof File) {
      const [image] = await uploadFile({ files: formData.passportImage, folderName: 'guest' }).unwrap()
      formData.passportImage = image
      setValue('passportImage', image)
    }

    const samePassportNumberGuest = data.guestDetails.find((item) => removeSpace(item.passportNumber) === removeSpace(formData.passportNumber) && guestId !== item.id)
    if (samePassportNumberGuest)
      return setError(
        'passportNumber',
        { message: `"${samePassportNumberGuest.passportFirstName} ${samePassportNumberGuest.passportLastName}" guest already have that passport number`, type: 'validate' },
        { shouldFocus: true },
      )

    await updateGuestTransportation({ ...formData, photo: formData.photo as string, passportImage: formData.passportImage as string, userId: data.userId }).unwrap()
    onCancel()
  }

  return (
    <Dialog open fullWidth component="form" maxWidth="md" onClose={() => !isSubmitting && onCancel()} onSubmit={handleSubmit(onSubmit)} {...{ noValidate: true }}>
      <DialogTitle>Update Flight & Visa Details</DialogTitle>
      <DialogContent dividers>
        <RenderContent error={countriesApiState.isError || eventApiState.isError} loading={countriesApiState.isLoading || eventApiState.isLoading}>
          {countriesApiState.isSuccess && eventApiState.isSuccess && (
            <Grid container spacing={2}>
              {/* Passport Photo */}
              <Grid item xs={6}>
                <UploadField name="passportImage" label="Passport photo *" heading="Upload passport photo" description="PDF or image" control={control} accept={{ 'image/*': [], 'application/pdf': ['.pdf'] }} />
              </Grid>

              {/* Profile Photo */}
              <Grid item xs={6}>
                <UploadField name="photo" label="Personal photo *" heading="Upload personal photo" description="Required for accreditation" control={control} accept={{ 'image/*': [] }} />
              </Grid>

              {/* Passport Number */}
              <Grid item xs={12} sm={6}>
                <InputField name="passportNumber" label="Passport number *" control={control} />
              </Grid>

              {/* Nationality */}
              <Grid item xs={12} sm={6}>
                <Controller
                  name="nationality"
                  control={control}
                  render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                    <Autocomplete
                      {...restField}
                      value={value || null}
                      options={countriesApiState.data.map((item) => item.name)}
                      onChange={(_, value) => onChange(value)}
                      renderInput={(params) => <TextField {...params} label="Nationality *" inputRef={ref} error={!!error} helperText={error?.message} />}
                    />
                  )}
                />
              </Grid>

              {/* Passport Issue Date */}
              <Grid item xs={12} sm={6}>
                <Controller
                  name="passportIssueDate"
                  control={control}
                  render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                    <MobileDatePicker
                      {...restField}
                      inputRef={ref}
                      disableFuture={true}
                      disablePast={false}
                      label="Passport issue date"
                      value={value ? moment(value) : null}
                      onChange={(value) => {
                        onChange(value?.toISOString())
                        isSubmitted && trigger('passportExpiryDate')
                      }}
                      slotProps={{
                        textField: { error: !!error, helperText: error?.message },
                      }}
                    />
                  )}
                />
              </Grid>

              {/* Passport Expire Date */}
              <Grid item xs={12} sm={6}>
                <Controller
                  name="passportExpiryDate"
                  control={control}
                  render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                    <MobileDatePicker
                      {...restField}
                      inputRef={ref}
                      disableFuture={false}
                      disablePast={true}
                      label="Passport expire date"
                      value={value ? moment(value) : null}
                      onChange={(value) => onChange(value?.toISOString())}
                      slotProps={{
                        textField: { error: !!error, helperText: error?.message },
                      }}
                    />
                  )}
                />
              </Grid>

              {/* Date Of Birth */}
              <Grid item xs={12} sm={6}>
                <Controller
                  name="dob"
                  control={control}
                  render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                    <MobileDatePicker
                      {...restField}
                      inputRef={ref}
                      disableFuture={true}
                      disablePast={false}
                      label="Date of birth"
                      value={value ? moment(value) : null}
                      onChange={(value) => {
                        onChange(value?.toISOString())
                        isSubmitted && trigger('passportIssueDate')
                      }}
                      slotProps={{
                        textField: { error: !!error, helperText: error?.message },
                      }}
                    />
                  )}
                />
              </Grid>

              {/* Occupation */}
              <Grid item xs={12} sm={6}>
                <InputField name="occupation" label="Occupation" control={control} />
              </Grid>

              {/* Job Title */}
              <Grid item xs={12} sm={6}>
                <InputField name="jobTitle" label="Job title" control={control} />
              </Grid>

              {/* Place of Work */}
              <Grid item xs={12} sm={6}>
                <InputField name="workPlace" label="Place of work" control={control} />
              </Grid>

              {/* Heading */}
              <Grid item xs={12} mt={2}>
                <HeadingWithIcon Icon={MdFlightLand} text="Flight arrival details" />
              </Grid>

              {/* Arrival Airport */}
              <Grid item xs={12} sm={6}>
                <InputField name="arrivalFlightAirport" label="Arrival airport" control={control} />
              </Grid>

              {/* Arrival Flight Number */}
              <Grid item xs={12} sm={3}>
                <InputField name="arrivalFlightNumber" label="Arrival flight number" control={control} />
              </Grid>

              {/* Arrival Date Time */}
              <Grid item xs={12} sm={3}>
                <Controller
                  name="arrivalDateTime"
                  control={control}
                  render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                    <MobileDateTimePicker
                      {...restField}
                      inputRef={ref}
                      disableFuture={false}
                      disablePast={true}
                      label="Arrival date time"
                      value={value ? moment(value) : null}
                      onChange={(value) => onChange(value?.toISOString())}
                      slotProps={{
                        textField: { error: !!error, helperText: error?.message },
                      }}
                    />
                  )}
                />
              </Grid>

              {/* Arrival Notes */}
              <Grid item xs={12} sm={12}>
                <InputField name="arrivalNotes" label="Arrival notes" control={control} multiline minRows={2} maxRows={8} />
              </Grid>
              {/* Heading */}
              <Grid item xs={12} mt={2}>
                <HeadingWithIcon Icon={MdFlightTakeoff} text="Flight departure details" />
              </Grid>

              {/* Departure Airport */}
              <Grid item xs={12} sm={6}>
                <InputField name="departureFlightAirport" label="Departure airport" control={control} />
              </Grid>

              {/* Departure Flight Number */}
              <Grid item xs={12} sm={3}>
                <InputField name="departureFlightNumber" label="Departure flight number" control={control} />
              </Grid>

              {/* Departure Date Time */}
              <Grid item xs={12} sm={3}>
                <Controller
                  name="departureDateTime"
                  control={control}
                  render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                    <MobileDateTimePicker
                      {...restField}
                      inputRef={ref}
                      disableFuture={false}
                      disablePast={true}
                      label="Departure date time"
                      value={value ? moment(value) : null}
                      onChange={(value) => onChange(value?.toISOString())}
                      slotProps={{
                        textField: { error: !!error, helperText: error?.message },
                      }}
                    />
                  )}
                />
              </Grid>

              {/* Departure Notes */}
              <Grid item xs={12} sm={12}>
                <InputField name="departureNotes" label="Departure notes" control={control} multiline minRows={2} maxRows={8} />
              </Grid>

              {/* Heading */}
              <Grid item xs={12} mt={2}>
                <HeadingWithIcon Icon={MdAccessibility} text="Select accessibility" />
              </Grid>

              {/* Accessibility */}
              {!eventApiState.data.accessibilityInfoData.length ? (
                <Grid item xs={12}>
                  <Alert severity="info">Accessibility services are not provided for this event.</Alert>
                </Grid>
              ) : (
                <Grid item container xs={12} spacing={2} alignContent="start">
                  <Controller
                    name="accessibilityInfo"
                    control={control}
                    render={({ fieldState: { error }, field: { value, onChange, ref, ...restField } }) => (
                      <>
                        {eventApiState.data.accessibilityInfoData.map((item, index) => {
                          const isSelected = value.includes(item.id)

                          const handleClick = () => {
                            isSelected ? onChange(value.filter((val) => val != item.id)) : onChange([...value, item.id])
                          }

                          return (
                            <Grid item xs={3} key={index}>
                              <Button {...restField} component="div" sx={style.accessibilityItem} onClick={handleClick}>
                                <Checkbox size="small" inputRef={ref} checked={isSelected} sx={style.accessibilityItemCheckBox} tabIndex={-1} disableRipple />
                                <img src={item.imageURL} width={40} height={40} alt="accessibility icon" />
                                <Typography>{item.name}</Typography>
                              </Button>
                            </Grid>
                          )
                        })}

                        {error?.message && (
                          <Grid item xs={12}>
                            <FormHelperText error>{error?.message}</FormHelperText>
                          </Grid>
                        )}
                      </>
                    )}
                  />
                </Grid>
              )}
            </Grid>
          )}
        </RenderContent>
      </DialogContent>
      <DialogActions>
        <LoadingButton variant="text" disabled={isSubmitting} onClick={onCancel}>
          Cancel
        </LoadingButton>
        <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
          Update
        </LoadingButton>
      </DialogActions>
    </Dialog>
  )
}

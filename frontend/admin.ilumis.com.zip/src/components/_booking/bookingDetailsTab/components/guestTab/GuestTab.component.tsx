import Link from 'next/link'
import { useState } from 'react'
import { MdOutlineFileDownload } from 'react-icons/md'
import { alpha, Backdrop, Button, Card, CircularProgress, Divider, FormHelperText, Grid, Stack } from '@mui/material'

import UpdateGuest from './components/updateGuest/UpdateGuest.component'
import ReplaceGuest from './components/replaceGuest/ReplaceGuest.component'
import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import GuestDetails from '@/components/_booking/guestDetails/GuestDetails.component'
import { TabItemProps } from '../../BookingDetailsTab.type'
import { style } from './GuestTab.style'
import { useReduxSelector } from '@/hooks'
import { TGuest } from '@/types'
import { useGuestCancelMutation } from '@/redux/api/guest.api'

export default function GuestTab({ data, loading }: TabItemProps) {
  const { role } = useReduxSelector((state) => state.layout.profile)
  const [updateId, setUpdateId] = useState<number | null>(null)
  const [replaceId, setReplaceId] = useState<number | null>(null)
  const [cancelGuest, setCancelGuest] = useState<TGuest | null>(null)
  const [guestCancel, guestCancelApiState] = useGuestCancelMutation()

  return (
    <>
      {/* Guest List */}
      <Grid container spacing={3}>
        {data.guestDetails.map((item, index) => (
          <Grid item xs={12} key={index}>
            <Card sx={style.card}>
              <Stack direction={{ xs: 'column', md: 'row' }}>
                {/* Loader */}
                {loading && (
                  <Backdrop open sx={style.backdrop}>
                    <CircularProgress />
                  </Backdrop>
                )}

                {/* Guest Details */}
                <Stack p={3} width={1}>
                  <GuestDetails data={item} />
                </Stack>

                {/* Actions */}
                {role === 'customer' && item.status !== 'cancelled' && data.status !== 'cancelled' && (
                  <Stack className="dashed-border-left" p={3} spacing={2} justifyContent="center" divider={<Divider sx={{ borderColor: (theme) => alpha(theme.palette.primary.main, 0.2) }} />}>
                    <Stack gap={1}>
                      <Button variant="contained" onClick={() => setUpdateId(item.id)}>
                        Update Flight & Visa Details
                      </Button>
                      <Button onClick={() => setReplaceId(item.id)}>Replace Guest</Button>
                      {/* TODO: enable it */}
                      {/* <Button onClick={() => setCancelGuest(item)} color="error">
                        Cancel Guest
                      </Button> */}
                    </Stack>

                    {(item.visaAssistanceRequired || item.visaOfficialLetterRequired) && (
                      <Stack gap={1.25}>
                        {!!item.visaAssistanceRequired && (
                          <Stack>
                            <Button LinkComponent={Link} href={item.visaDocument || '#'} download startIcon={<MdOutlineFileDownload />} disabled={!item.visaDocument}>
                              Download Visa
                            </Button>
                            {!item.visaDocument && <FormHelperText sx={{ textAlign: 'center' }}>Staff will upload visa soon</FormHelperText>}
                          </Stack>
                        )}

                        {!!item.visaOfficialLetterRequired && (
                          <Stack>
                            <Button LinkComponent={Link} href={item.visaOfficialLetterDocument || '#'} download startIcon={<MdOutlineFileDownload />} disabled={!item.visaOfficialLetterDocument}>
                              Download Visa Letter
                            </Button>
                            {!item.visaOfficialLetterDocument && <FormHelperText sx={{ textAlign: 'center' }}>Staff will upload visa letter soon</FormHelperText>}
                          </Stack>
                        )}
                      </Stack>
                    )}
                  </Stack>
                )}
              </Stack>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Update Guest */}
      {updateId && <UpdateGuest data={data} guestId={updateId} onCancel={() => setUpdateId(null)} />}
      {replaceId && <ReplaceGuest data={data} guestId={replaceId} onCancel={() => setReplaceId(null)} />}
      {cancelGuest && (
        <ConfirmationPopup
          heading="Cancel guest"
          subheading={`Sure to cancel "${cancelGuest.passportFirstName} ${cancelGuest.passportLastName}" guest?`}
          acceptButtonText="Cancel Guest"
          cancelButtonText="Close"
          loading={guestCancelApiState.isLoading}
          onCancel={() => setCancelGuest(null)}
          onAccept={() =>
            guestCancel({ guestId: cancelGuest.id, bookingId: cancelGuest.orderId })
              .unwrap()
              .then(() => setCancelGuest(null))
          }
        />
      )}
    </>
  )
}

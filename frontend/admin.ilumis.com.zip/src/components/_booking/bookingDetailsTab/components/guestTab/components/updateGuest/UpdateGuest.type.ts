import { BookingDTO } from '@/dto/Booking.dto'

export type UpdateGuestProps = {
  onCancel: () => void
  guestId: number
  data: BookingDTO
}

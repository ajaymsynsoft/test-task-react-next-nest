import { MdOutlinePeopleAlt, MdOutlineArticle } from 'react-icons/md'

import GuestTab from './components/guestTab/GuestTab.component'
import BookingTab from './components/bookingTab/BookingTab.component'
import { TabType } from './BookingDetailsTab.type'

export const TAB: TabType[] = [
  { id: 'details', label: 'Booking Details', Icon: MdOutlineArticle, Content: BookingTab },
  { id: 'guests', label: 'Guests', Icon: MdOutlinePeopleAlt, Content: GuestTab },
]

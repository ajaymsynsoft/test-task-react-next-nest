import { Style } from '@/types'

export const style: Style = {
  tabHeadings: {
    borderBottom: 1,
    borderColor: 'dividerDark',
  },
  tab: {
    py: 2.3,
    px: 0,
    minHeight: 'unset',
    minWidth: 'unset',
    '&:not(:last-of-type)': {
      mr: 5,
    },
  },
}

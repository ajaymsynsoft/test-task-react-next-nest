import React from 'react'
import { useRouter } from 'next/router'
import { Alert, Container, Fade, Stack, Tab } from '@mui/material'
import { TabContext, TabList, TabPanel } from '@mui/lab'

import { TAB } from './BookingDetailsTab.config'
import { style } from './BookingDetailsTab.style'
import { BookingDetailsTabProps } from './BookingDetailsTab.type'
import { useUrlParams } from '@/hooks'

export default function BookingDetailsTab({ data, loading, disableGutters }: BookingDetailsTabProps) {
  const router = useRouter()
  const tab = String(router.query.tab || TAB[0].id)
  const { setUrlParams } = useUrlParams()

  return (
    <>
      <TabContext value={TAB.find(({ id }) => id === tab) ? tab : 0}>
        {/* Tab Headings */}
        <Stack sx={style.tabHeadings}>
          <Container disableGutters={disableGutters}>
            <TabList onChange={(_, value) => setUrlParams({ params: { tab: value }, options: { scroll: true } })}>
              {TAB.map((item, index) => (
                <Tab key={index} iconPosition="start" label={item.label} value={item.id} sx={style.tab} icon={item.Icon && <item.Icon />} />
              ))}
            </TabList>
          </Container>
        </Stack>

        {/* Tab Content */}
        <Container sx={{ pt: 4 }} disableGutters={disableGutters}>
          {data.status === 'cancelled' && (
            <Alert severity="error" sx={{ mb: 3, mt: -1 }}>
              This booking has been cancelled.
            </Alert>
          )}

          {TAB.map((item, index) => (
            <React.Fragment key={index}>
              <Fade in key={tab} timeout={300}>
                <TabPanel value={String(item.id)}>
                  <item.Content data={data} loading={loading} />
                </TabPanel>
              </Fade>
            </React.Fragment>
          ))}
        </Container>
      </TabContext>
    </>
  )
}

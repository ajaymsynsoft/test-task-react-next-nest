import toast from 'react-hot-toast'
import { useRouter } from 'next/router'
import { forwardRef, useEffect, useImperativeHandle } from 'react'
import { Controller, useFieldArray, useForm } from 'react-hook-form'
import { Stack, Typography, Grid, Checkbox, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Backdrop, CircularProgress, Divider } from '@mui/material'
import { yupResolver } from '@hookform/resolvers/yup'

import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import SummaryCard from '@/components/_card/summaryCard/SummaryCard.component'
import GuestInfoCard from '@/components/_card/guestInfoCard/GuestInfoCard.compoent'
import { TSchema, schema } from './VisaForm.config'
import { VisaFormProps } from './VisaForm.type'
import { useUpdateGuestVisaPreferencesMutation } from '@/redux/api/guest.api'
import { style } from './VisaForm.style'
import { useReduxSelector } from '@/hooks'

const VisaForm = forwardRef((props: VisaFormProps, ref) => {
  const { data, isDataUpdating, isViewMode, headingVariant = 'h2' } = props
  const router = useRouter()
  const eventId = Number(router.query.eventId)
  const organization = useReduxSelector((state) => state.organization)
  const [updateGuestVisaPreferences, { isLoading }] = useUpdateGuestVisaPreferencesMutation()

  const { control, watch, getValues, trigger } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      orderId: data.id,
      visaFeesId: 2,
      eventId,
      guestVisaInfos: data.guestDetails.map((item) => ({
        guestId: item.id,
        visaAssistanceRequired: !!item.visaAssistanceRequired,
        visaOfficialLetterRequired: !!item.visaOfficialLetterRequired,
      })),
    },
  })

  const guestVisaInfosField = useFieldArray({ name: 'guestVisaInfos', control })
  const numberOfVisas = data.guestDetails.filter((item) => item.visaAssistanceRequired).length
  const totalVisaFees = data.orderDetails.find((item) => item.type === 'visa')?.amount || 0

  useImperativeHandle(
    ref,
    () => ({
      async handleNextStep() {},
      async handlePrevStep() {},
    }),
    [],
  )

  useEffect(() => {
    const subscription = watch(async () => {
      await onSubmit()
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [watch])

  const onSubmit = async () => {
    if (isViewMode) return
    const formData = getValues()

    try {
      await schema.validate(formData)
    } catch (error) {
      trigger()
      toast.error('Something is not valid in form')
      throw ''
    }

    await updateGuestVisaPreferences(formData).unwrap()
  }

  return (
    <Grid container spacing={5}>
      {/* Visa Assistance */}
      <Grid item xs={12} md={6}>
        <Stack gap={1}>
          <Stack gap={0.5}>
            <Typography variant={headingVariant}>Visa assistance</Typography>
            <Typography variant="subtitle" color="text.disabled">
              {isViewMode ? 'Guests' : 'Select guests'} who require visa assistance (Visa fees "<DisplayPrice price={organization.visaFees} />" per guest)
            </Typography>
          </Stack>

          <List component={Stack} divider={<Divider />}>
            {guestVisaInfosField.fields.map((item, index) => (
              <Controller
                name={`guestVisaInfos.${index}.visaAssistanceRequired`}
                control={control}
                key={item.id}
                render={({ field: { value, onChange, ref } }) => {
                  const guestDetails = data.guestDetails.find((guest) => guest.id === item.guestId)!
                  return (
                    <ListItem disablePadding>
                      <ListItemButton
                        dense
                        disableGutters
                        disableRipple={isViewMode}
                        onClick={(_) => !isViewMode && onChange(!value)}
                        sx={isViewMode ? { bgcolor: (theme) => `${theme.palette.background.default} !important`, cursor: 'unset' } : {}}
                      >
                        <ListItemIcon>
                          <Checkbox inputRef={ref} checked={value} tabIndex={-1} disableRipple sx={isViewMode ? { pointerEvents: 'none' } : {}} />
                        </ListItemIcon>
                        <ListItemText primary={<GuestInfoCard data={guestDetails} />} />
                      </ListItemButton>
                    </ListItem>
                  )
                }}
              />
            ))}
          </List>
        </Stack>
      </Grid>

      {/* Official Visa Letter */}
      <Grid item xs={12} md={6}>
        <Stack gap={1}>
          <Stack gap={0.5}>
            <Typography variant={headingVariant}>Official visa letter</Typography>
            <Typography variant="subtitle" color="text.disabled">
              {isViewMode ? 'Guests' : 'Select guests'} who require an official visa letter (Visa letter fees "<DisplayPrice price={0} />" per guest)
            </Typography>
          </Stack>

          <List component={Stack} divider={<Divider />}>
            {guestVisaInfosField.fields.map((item, index) => (
              <Controller
                name={`guestVisaInfos.${index}.visaOfficialLetterRequired`}
                control={control}
                key={item.id}
                render={({ field: { value, onChange, ref } }) => {
                  const guestDetails = data.guestDetails.find((guest) => guest.id === item.guestId)!
                  return (
                    <ListItem disablePadding>
                      <ListItemButton
                        dense
                        disableGutters
                        disableRipple={isViewMode}
                        onClick={(_) => !isViewMode && onChange(!value)}
                        sx={isViewMode ? { bgcolor: (theme) => `${theme.palette.background.default} !important`, cursor: 'unset' } : {}}
                      >
                        <ListItemIcon>
                          <Checkbox inputRef={ref} checked={value} tabIndex={-1} disableRipple sx={isViewMode ? { pointerEvents: 'none' } : {}} />
                        </ListItemIcon>
                        <ListItemText primary={<GuestInfoCard data={guestDetails} />} />
                      </ListItemButton>
                    </ListItem>
                  )
                }}
              />
            ))}
          </List>
        </Stack>
      </Grid>

      {/* Summary */}
      {!isViewMode && (
        <Grid item xs={12}>
          <Stack position="relative">
            <SummaryCard
              data={[
                { label: 'Number of visas', value: numberOfVisas },
                { label: 'Total visas fees', value: totalVisaFees, type: 'amount', isTotal: true },
              ]}
            />
            {(isDataUpdating || isLoading) && (
              <Backdrop open sx={style.backdrop}>
                <CircularProgress />
              </Backdrop>
            )}
          </Stack>
        </Grid>
      )}
    </Grid>
  )
})

VisaForm.displayName = 'VisaForm'
export default VisaForm

import { BookingDTO } from '@/dto/Booking.dto'
import { TypographyProps } from '@mui/material'

export type VisaFormProps = {
  data: BookingDTO
  isViewMode: boolean
  headingVariant?: 'h2' | 'h3'
  isDataUpdating?: boolean
}

import { Style } from '@/types'

export const style: Style = {
  backdrop: {
    color: '#fff',
    zIndex: (theme) => theme.zIndex.drawer,
    position: 'absolute',
    bgcolor: 'rgba(255, 255, 255, 0.38)',
  },
}

import * as yup from 'yup'

export const schema = yup.object({
  orderId: yup.number().required(),
  visaFeesId: yup.number().required(),
  eventId: yup.number().required(),
  guestVisaInfos: yup
    .array()
    .of(
      yup.object({
        guestId: yup.number().required(),
        visaAssistanceRequired: yup.boolean().required(),
        visaOfficialLetterRequired: yup.boolean().required(),
      }),
    )
    .required(),
})

export type TSchema = yup.InferType<typeof schema>

import { DataGrid } from '@mui/x-data-grid'

import NoRowMessage from '@/components/noRowMessage/NoRowMessage.component'
import { addSerialNumber } from '@/utils'
import { useColumns } from './AccommodationTable.hook'
import { AccommodationTableProps } from './AccommodationTable.type'

export default function AccommodationTable(props: AccommodationTableProps) {
  const { data, loading } = props
  const columns = useColumns(props)
  const rows = data.accommodationInfo
  const totalAccommodation = data.orderDetails.find((item) => item.type === 'accommodation')?.amount || 0

  return (
    <DataGrid
      hideFooter
      loading={loading}
      columns={columns}
      getRowHeight={() => 'auto'}
      slots={{ noRowsOverlay: () => <NoRowMessage variant="message" message="No hotel bookings" /> }}
      rows={[...addSerialNumber(rows, 1, 1000, true), ...(rows.length ? [{ id: 'total', label: 'Total accommodation', total: totalAccommodation }] : [])]}
    />
  )
}

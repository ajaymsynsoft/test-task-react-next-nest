import { BookingDTO } from '@/dto/Booking.dto'

export type AccommodationTableProps = {
  data: BookingDTO
  actions?: boolean
  loading?: boolean
}

export type UseColumnProps = AccommodationTableProps & {}

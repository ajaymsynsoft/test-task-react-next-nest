import moment from 'moment'
import { useRouter } from 'next/router'
import { useState } from 'react'
import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'
import { Stack, Typography, Link as MuiLink, Popover } from '@mui/material'
import { MdDelete, MdEdit, MdPerson } from 'react-icons/md'

import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import AccommodationFormPopup from '../accommodationFormPopup/AccommodationFormPopup.component'
import SmartPopover from '@/components/smartPopover/SmartPopover.component'
import HotelInfoCard from '@/components/_card/hotelInfoCard/HotelInfoCard.compoent'
import { BookingDTO } from '@/dto/Booking.dto'
import { useDeleteGuestAccommodationMutation } from '@/redux/api/guest.api'
import { UseColumnProps } from './AccommodationTable.type'
import { usePage } from '@/hooks'

export const useColumns = ({ actions, data }: UseColumnProps) => {
  const router = useRouter()
  const { isPdfMakerPage } = usePage()
  const [editItemsequenceNo, setEditItemsequenceNo] = useState<number | null>(null)
  const [deleteItem, setDeleteItem] = useState<{ sequenceNo: number; orderId: number; status: string } | null>(null)
  const [deleteGuestAccommodation, { isLoading }] = useDeleteGuestAccommodationMutation()

  type Columns = (BookingDTO['accommodationInfo'][0] & { serialNumber: number; id: number }) | { id: 'total'; label: string; total: number }

  const columns: GridColDef<Columns>[] = [
    {
      field: 'serialNumber',
      headerName: 'SN',
      sortable: false,
      minWidth: 50,
      width: 50,
      align: 'center',
      headerAlign: 'center',
      colSpan: (value, row) => (row.id === 'total' ? 7 : undefined),
      renderCell: ({ row }) =>
        row.id === 'total' ? (
          <Typography fontWeight={600} textAlign="left" pl={1} width={1}>
            {row.label}
          </Typography>
        ) : (
          row.serialNumber
        ),
    },
    {
      field: 'guestNames',
      headerName: 'Guests Assigned',
      sortable: false,
      flex: 1,
      minWidth: 200,
      width: 200,
      renderCell: ({ row }) =>
        row.id !== 'total' && (
          <Stack gap={0.5}>
            {row.guestNames.map((item, index) => (
              <Stack direction="row" alignItems="center" color="text.disabled" gap={1} title={item} key={index}>
                <MdPerson />
                <Typography>{item}</Typography>
              </Stack>
            ))}
          </Stack>
        ),
    },
    {
      field: 'hotel',
      headerName: 'Hotel',
      sortable: false,
      flex: 1,
      minWidth: 150,
      renderCell: ({ row }) =>
        row.id !== 'total' && (
          <Stack gap={0.5}>
            <SmartPopover>
              <SmartPopover.Toggle>
                <MuiLink color="text.secondary" underline={isPdfMakerPage ? 'none' : 'always'}>
                  {row.hotel.name}
                </MuiLink>
              </SmartPopover.Toggle>
              <SmartPopover.Content>
                <HotelInfoCard data={row.hotel} p={2} />
              </SmartPopover.Content>
            </SmartPopover>
            <Typography variant="body2">Room Type: {row.hotel.roomType.roomSize}</Typography>
          </Stack>
        ),
    },
    { field: 'fromDate', headerName: 'From', sortable: false, minWidth: 110, width: 110, renderCell: ({ value }) => moment(value).format() },
    { field: 'toDate', headerName: 'To', sortable: false, minWidth: 110, width: 110, renderCell: ({ value }) => moment(value).format() },
    { field: 'nightPrice', headerName: 'Nightly Price', sortable: false, minWidth: 110, width: 110, renderCell: ({ row }) => row.id !== 'total' && <DisplayPrice price={row.amount / row.numberOfNights} /> },
    { field: 'numberOfNights', headerName: 'No. of Nights', sortable: false, minWidth: 110, width: 110 },
    {
      field: 'amount',
      headerName: 'Accommodation',
      sortable: false,
      minWidth: 140,
      width: 140,
      colSpan: (value, row) => (row.id === 'total' ? 1 : undefined),
      renderCell: ({ row }) =>
        row.id === 'total' ? (
          <Typography fontWeight={600}>
            <DisplayPrice price={row.total} />
          </Typography>
        ) : (
          <DisplayPrice price={row.amount} />
        ),
    },
  ]

  if (actions !== false) {
    columns.push({
      field: 'actions',
      headerName: 'Actions',
      sortable: false,
      minWidth: 80,
      width: 80,
      align: 'center',
      type: 'actions',
      getActions: ({ row }) =>
        row.id !== 'total'
          ? [
              <GridActionsCellItem key="edit" label="Edit" icon={<MdEdit />} onClick={() => setEditItemsequenceNo(row.sequenceNo)} />,
              <GridActionsCellItem
                key="delete"
                label="Delete"
                icon={<MdDelete />}
                onClick={() => {
                  setDeleteItem({ orderId: row.orderId, sequenceNo: row.sequenceNo, status: 'inactive' })
                }}
              />,
              ...(row.sequenceNo === deleteItem?.sequenceNo
                ? [
                    <ConfirmationPopup
                      key="deletePopup"
                      heading="Delete hotel booking"
                      subheading={`Sure to delete "${row.guestNames.join(', ')}" guest's hotel booking?`}
                      acceptButtonText="Delete"
                      loading={isLoading}
                      onCancel={() => setDeleteItem(null)}
                      onAccept={() =>
                        deleteItem &&
                        deleteGuestAccommodation({ ...deleteItem, eventId: Number(router.query.eventId) })
                          .unwrap()
                          .then((_) => setDeleteItem(null))
                      }
                    />,
                  ]
                : []),
              ...(row.sequenceNo === editItemsequenceNo ? [<AccommodationFormPopup key="editPopup" isEditMode={true} onCancel={() => setEditItemsequenceNo(null)} data={data} sequenceNo={row.sequenceNo} />] : []),
            ]
          : [],
    })
  }

  return columns
}

import { BookingDTO } from '@/dto/Booking.dto'

export type RegistrationFeesTableProps = {
  data: BookingDTO
  loading?: boolean
}

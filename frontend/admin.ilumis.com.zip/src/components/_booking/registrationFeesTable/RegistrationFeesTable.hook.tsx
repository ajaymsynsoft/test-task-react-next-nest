import { Typography } from '@mui/material'
import { GridColDef } from '@mui/x-data-grid'

import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import { TGuest } from '@/types/Guest.type'

export const useColumns = () => {
  type Columns = (TGuest & { serialNumber: number; id: number }) | { id: 'total'; label: string; total: number }

  const columns: GridColDef<Columns>[] = [
    {
      field: 'serialNumber',
      headerName: 'SN',
      sortable: false,
      minWidth: 50,
      width: 50,
      align: 'center',
      display: 'flex',
      headerAlign: 'center',
      colSpan: (value, row) => (row.id === 'total' ? 4 : undefined),
      renderCell: ({ row }) =>
        row.id === 'total' ? (
          <Typography fontWeight={600} textAlign="left" pl={1} width={1}>
            {row.label}
          </Typography>
        ) : (
          row.serialNumber
        ),
    },
    { field: 'name', headerName: 'Guest', sortable: false, flex: 1, minWidth: 200, width: 200, renderCell: ({ row }) => row.id !== 'total' && `${row.passportFirstName} ${row.passportLastName}` },
    { field: 'passportNumber', headerName: 'Passport Number', sortable: false, flex: 1, minWidth: 200, width: 200 },
    { field: 'role', headerName: 'Role', sortable: false, minWidth: 150, width: 150 },
    {
      field: 'registrationFee',
      headerName: 'Fees',
      sortable: false,
      display: 'flex',
      cellClassName: 'test',
      minWidth: 170,
      width: 170,
      colSpan: (value, row) => (row.id === 'total' ? 1 : undefined),
      renderCell: ({ row, value }) =>
        row.id === 'total' ? (
          <Typography fontWeight={600}>
            <DisplayPrice price={row.total} />
          </Typography>
        ) : (
          <DisplayPrice price={value} />
        ),
    },
  ]

  return columns
}

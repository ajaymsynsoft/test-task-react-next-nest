import { DataGrid } from '@mui/x-data-grid'

import NoRowMessage from '@/components/noRowMessage/NoRowMessage.component'
import { RegistrationFeesTableProps } from './RegistrationFeesTable.type'
import { addSerialNumber } from '@/utils'
import { useColumns } from './RegistrationFeesTable.hook'

export default function RegistrationFeesTable({ data, loading }: RegistrationFeesTableProps) {
  const columns = useColumns()
  const rows = data.guestDetails
  const totalRegistrationFee = data.orderDetails.find((item) => item.type === 'registration')?.amount || 0

  return (
    <DataGrid
      hideFooter
      loading={loading}
      columns={columns}
      slots={{ noRowsOverlay: () => <NoRowMessage variant="message" message="No guest added" /> }}
      rows={[...addSerialNumber(rows, 1, 1000, true), ...(rows.length ? [{ id: 'total', label: 'Total registration fees', total: totalRegistrationFee }] : [])]}
    />
  )
}

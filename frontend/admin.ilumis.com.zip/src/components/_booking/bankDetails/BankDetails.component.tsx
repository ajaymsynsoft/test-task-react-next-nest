import RenderContent from '@/components/renderContent/RenderContent.component'
import { useGetPaymentProviderQuery } from '@/redux/api/payment.api'
import { Alert, Card, CardContent, Stack, Typography } from '@mui/material'

export default function BankDetails() {
  const { isLoading, isError, isSuccess, data } = useGetPaymentProviderQuery()

  return (
    <Card variant="outlined" className="pdf-no-break">
      <CardContent component={Stack} gap={2}>
        <Stack>
          <Typography variant="h3">Bank Details:</Typography>
          <Typography variant="subtitle" color="text.secondary">
            (Pay your unpaid booking amount via below bank details then upload bank receipt)
          </Typography>
        </Stack>
        <RenderContent loading={isLoading} error={isError}>
          {isSuccess && data.bankDetails ? (
            <Stack
              sx={{ color: 'text.secondary', opacity: 0.75 }}
              className="text-editor-content"
              dangerouslySetInnerHTML={{
                __html: data.bankDetails,
              }}
            />
          ) : (
            <Alert severity="warning">Sorry! bank details are not available.</Alert>
          )}
        </RenderContent>
      </CardContent>
    </Card>
  )
}

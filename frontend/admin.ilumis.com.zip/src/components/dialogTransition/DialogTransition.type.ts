import { TransitionProps } from '@mui/material/transitions'

export type DialogTransitionProps = TransitionProps & {
  children: React.ReactElement
}

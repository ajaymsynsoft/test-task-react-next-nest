import { forwardRef } from 'react'
import { Slide } from '@mui/material'
import { DialogTransitionProps } from './DialogTransition.type'

const DialogTransition = forwardRef<unknown, DialogTransitionProps>((props, ref) => {
  return <Slide direction="up" ref={ref} in {...props} timeout={300} />
})

DialogTransition.displayName = 'DialogTransition'
export default DialogTransition

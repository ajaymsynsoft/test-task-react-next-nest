import Image from 'next/image'
import { Stack, Typography } from '@mui/material'

import { MemberInfoCardProps } from './MemberInfoCard.type'
import { style } from './MemberInfoCard.style'

export default function MemberInfoCard({ data }: MemberInfoCardProps) {
  return (
    <Stack sx={style.root}>
      <Image style={style.avatarImage as any} src={data.photo} width={40} height={40} alt="photo" />
      <Stack gap={0.5} whiteSpace="wrap">
        <Stack direction="row" alignItems="center" flexWrap="wrap">
          <Typography title="Member Name">
            {data.firstName} {data.lastName}
          </Typography>
          <Typography variant="body2" title="Role">
            &nbsp;&nbsp; - &nbsp;&nbsp;{data.role}
          </Typography>
        </Stack>
        <Stack direction="row" sx={style.bottomDetails}>
          <span title="Email">{data.email}</span>|<span title="Country">{data.country}</span>
        </Stack>
      </Stack>
    </Stack>
  )
}

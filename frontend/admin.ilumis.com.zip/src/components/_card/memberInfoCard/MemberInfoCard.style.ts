import { Style } from '@/types'

export const style: Style = {
  root: {
    flexDirection: 'row',
    gap: 1.5,
    alignItems: 'start',
  },
  avatarImage: {
    borderRadius: '100%',
    aspectRatio: '1/1',
  },
  bottomDetails: {
    gap: 1,
    color: 'text.disabled',
    fontSize: (theme) => `calc(${theme.typography.body1.fontSize} - 1px)`,
  },
}

import { InternalMemberDTO } from '@/dto'

export type MemberInfoCardProps = {
  data: InternalMemberDTO
}

import { Avatar, Stack, Typography } from '@mui/material'
import { GuestInfoCardProps } from './GuestInfoCard.type'
import { style } from './GuestInfoCard.style'
import Image from 'next/image'

export default function GuestInfoCard({ data, children }: GuestInfoCardProps) {
  return (
    <Stack sx={style.root}>
      {data.photo ? <Image style={style.avatarImage as any} src={data.photo} width={40} height={40} alt="photo" /> : <Avatar sx={style.icon} src={data.photo} />}
      <Stack gap={0.5} whiteSpace="wrap">
        <Stack direction="row" alignItems="center" flexWrap="wrap">
          <Typography title="Guest Name">
            {data.passportFirstName} {data.passportLastName}
          </Typography>
          <Typography variant="body2" title="Role">
            &nbsp;&nbsp;-&nbsp;&nbsp;{data.role}
          </Typography>
        </Stack>
        <Typography variant="body2" title="Passport Number">
          {data.passportNumber}
        </Typography>
        <Stack>{children}</Stack>
      </Stack>
    </Stack>
  )
}

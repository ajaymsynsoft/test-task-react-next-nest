import { TGuest } from '@/types/Guest.type'

export type GuestInfoCardProps = {
  data: Pick<TGuest, 'passportFirstName' | 'passportLastName' | 'passportNumber' | 'role' | 'photo'>
  children?: React.ReactNode
}

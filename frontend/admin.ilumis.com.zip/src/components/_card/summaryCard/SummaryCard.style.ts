import { Style } from '@/types/Style.type'

export const style: Style = {
  root: {
    bgcolor: 'background.bg2',
    borderRadius: 1,
    p: 2,
    pb: 1.5,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 3,
    py: 1,
    ':hover': {
      bgcolor: 'action.hover',
    },
    borderWidth: '1px 0 0 0',
    borderColor: 'dividerDark',
    ':first-of-type': {
      border: 'none',
    },
  },
  heading: {
    mb: 1,
    display: 'inline-flex',
    alignItems: 'center',
    gap: 1,
    '.icon': {
      color: 'text.secondary',
    },
  },
  totalRowDivider: {
    mb: 1,
    borderColor: 'dividerDark',
  },
}

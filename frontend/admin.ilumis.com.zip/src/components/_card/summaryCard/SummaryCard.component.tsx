import { Stack, SxProps, Typography } from '@mui/material'
import { LuSigma } from 'react-icons/lu'

import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import { SummaryCardProps } from './SummaryCard.type'
import { style } from './SummaryCard.style'
import { formatNumber } from '@/utils'

export default function SummaryCard(props: SummaryCardProps) {
  const { heading = 'Summary', data, children } = props

  const createItem = (item: SummaryCardProps['data'][0], key: number) => {
    const sx: SxProps = item.isTotal ? { fontWeight: 500, color: 'text.primary' } : {}

    return (
      <Stack sx={{ ...style.row, borderStyle: item.isTotal ? 'solid' : 'dashed' }} key={key}>
        <Stack gap={0.5}>
          {<Typography sx={sx}>{item.label}</Typography>}
          {item.helperText && (
            <Typography variant="body2" fontWeight={500}>
              {item.helperText}
            </Typography>
          )}
        </Stack>
        <Typography dir="auto" sx={sx}>
          {item.type === 'amount' ? <DisplayPrice price={item.value as number} /> : formatNumber(item.value as number)}
        </Typography>
      </Stack>
    )
  }

  return (
    <Stack sx={style.root}>
      {heading && (
        <Typography variant="h2" sx={style.heading}>
          <LuSigma className="icon-lg" /> {heading}
        </Typography>
      )}
      <Stack>{data.map((item, index) => createItem(item, index))}</Stack>
      {children}
    </Stack>
  )
}

export type SummaryCardProps = {
  heading?: string | false
  data: TSummaryData
  children?: React.ReactNode
}

export type TSummaryData = {
  label: React.ReactNode
  value: React.ReactNode
  helperText?: React.ReactNode
  type?: 'number' | 'amount'
  isTotal?: boolean
}[]

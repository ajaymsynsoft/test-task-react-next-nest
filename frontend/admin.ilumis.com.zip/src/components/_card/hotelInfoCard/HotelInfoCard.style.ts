import { Style } from '@/types'

export const style: Style = {
  root: {
    flexDirection: 'row',
    gap: 1.5,
    alignItems: 'center',
  },
  icon: {
    bgcolor: 'unset',
    border: 1,
    borderColor: 'divider',
    color: 'text.disabled',
  },
}

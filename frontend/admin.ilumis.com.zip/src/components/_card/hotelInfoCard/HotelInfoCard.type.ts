import { HotelDTO } from '@/dto'
import { StackProps } from '@mui/material'

export type HotelInfoCardProps = StackProps & {
  data: Omit<HotelDTO, 'roomType'>
}

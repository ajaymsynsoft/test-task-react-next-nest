import { Avatar, Rating, Stack, SxProps, Typography } from '@mui/material'
import { HiOutlineBuildingOffice } from 'react-icons/hi2'

import { HotelInfoCardProps } from './HotelInfoCard.type'
import { style } from './HotelInfoCard.style'

export default function HotelInfoCard({ data, ...props }: HotelInfoCardProps) {
  return (
    <Stack {...props} sx={{ ...style.root, ...props.sx } as SxProps}>
      <Avatar sx={style.icon}>
        <HiOutlineBuildingOffice />
      </Avatar>
      <Stack gap={0.5} whiteSpace="wrap">
        <Stack direction="row" alignItems="center" flexWrap="wrap" gap={1} divider={<>-</>}>
          <Typography>{data.name}</Typography>
          <Rating value={data.rating} readOnly size="small" />
        </Stack>
        <Typography variant="body2">
          {data.address}, {data.city}, {data.state}, {data.country} - {data.postalCode}
        </Typography>
      </Stack>
    </Stack>
  )
}

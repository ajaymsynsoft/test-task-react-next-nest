import { Style } from '@/types/Style.type'
import { alpha } from '@mui/material'

export const style: Style = {
  root: {
    bgcolor: 'background.paper',
    height: 1,
    ['@media print']: {
      boxShadow: 'unset',
      bgcolor: 'background.paper',
      border: 1,
      borderColor: 'divider',
    },
  },
  content: {
    display: 'flex',
    flexFlow: 'column',
    justifyContent: 'space-between',
    height: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 2,
    mb: 3,
  },
  icon: {
    color: (theme) => alpha(theme.palette.primary.main, 0.7),
  },
}

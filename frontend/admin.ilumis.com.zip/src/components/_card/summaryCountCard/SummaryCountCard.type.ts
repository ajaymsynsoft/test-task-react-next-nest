import { IconType } from 'react-icons'

export type SummaryCountCardProps = {
  data: {
    label: React.ReactNode
    value: number | string
    Icon: IconType
    type?: 'number' | 'amount'
  }
}

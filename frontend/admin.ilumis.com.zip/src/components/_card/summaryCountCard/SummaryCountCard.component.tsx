import { Card, CardContent, Stack, Typography, Box } from '@mui/material'

import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import { SummaryCountCardProps } from './SummaryCountCard.type'
import { style } from './SummaryCountCard.style'
import { formatNumber } from '@/utils'

export default function SummaryCountCard({ data }: SummaryCountCardProps) {
  return (
    <Card sx={style.root}>
      <CardContent sx={style.content}>
        <Stack sx={style.header}>
          <Typography variant="h2" dir="auto">
            {data.type === 'amount' ? <DisplayPrice price={data.value as number} /> : formatNumber(data.value)}
          </Typography>
          <Box component={data.Icon} className="icon-xl" sx={style.icon} />
        </Stack>
        <Typography fontWeight={500} component="div">
          {data.label}
        </Typography>
      </CardContent>
    </Card>
  )
}

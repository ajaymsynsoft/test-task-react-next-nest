import { Style } from '@/types/Style.type'
import { grey } from '@mui/material/colors'

export const style: Style = {
  detailItem: {
    display: 'flex',
    alignItems: 'start',
    gap: 1.5,
    minHeight: 21,
    '.icon': {
      color: 'text.disabled',
    },
  },
  otherDetailsBox: {
    wordBreak: 'break-word',
    m: -2,
    mt: -1,
    py: 1.25,
    px: 2,
    bgcolor: grey['50'],
    borderTop: 1,
    borderColor: 'divider',
    gap: 1.25,
  },
  otherDetailsItem: {
    columnGap: 2,
    flexFlow: 'row',
  },
  otherDetailsItemHeading: {
    color: 'text.disabled',
    minWidth: 130,
  },
}

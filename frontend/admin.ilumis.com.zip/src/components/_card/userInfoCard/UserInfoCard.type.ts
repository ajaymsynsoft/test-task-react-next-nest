import { CustomerDTO, ProfileDTO } from '@/dto'

export type UserInfoCardProps = { dataType: 'profile'; data: ProfileDTO } | { dataType: 'customer'; data: CustomerDTO }

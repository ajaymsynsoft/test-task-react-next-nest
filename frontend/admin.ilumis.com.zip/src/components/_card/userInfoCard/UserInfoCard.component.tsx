import { Avatar, Divider, Stack, Typography, Link as MuiLink } from '@mui/material'
import { MdOutlineMailOutline, MdOutlinePhoneIphone, MdOutlineFlag } from 'react-icons/md'

import { UserInfoCardProps } from './UserInfoCard.type'
import { style } from './UserInfoCard.style'

export default function UserInfoCard({ data, dataType }: UserInfoCardProps) {
  return (
    <Stack p={2} gap={2}>
      <Stack direction="row" gap={2}>
        {/* TODO: pass user profile image link */}
        <Avatar />
        <Stack gap={0.25}>
          <Typography variant="h2">
            {data!.firstName} {data!.lastName}
          </Typography>
          <Typography variant="body2">User ID: #{data!.id}</Typography>
        </Stack>
      </Stack>

      <Stack divider={<Divider />} spacing={0.5} sx={{ wordBreak: 'break-word' }}>
        <Typography sx={style.detailItem} component={MuiLink} href={`mailto:${data!.email}`} underline="hover">
          <MdOutlineMailOutline />
          {data!.email}
        </Typography>
        <Typography sx={style.detailItem} component={MuiLink} href={`tel:${data!.phone}`} underline="hover">
          <MdOutlinePhoneIphone />
          {data!.phone}
        </Typography>
        <Typography sx={style.detailItem}>
          <MdOutlineFlag />
          {data!.country}
        </Typography>
      </Stack>

      <Stack sx={style.otherDetailsBox}>
        <Stack sx={style.otherDetailsItem}>
          <Typography sx={style.otherDetailsItemHeading}>Organization name:</Typography>
          <Typography>{dataType === 'customer' ? data.customerOrganizationName : data.role === 'customer' ? data.customerOrganizationName : 'n/a'}</Typography>
        </Stack>
        <Stack sx={style.otherDetailsItem}>
          <Typography sx={style.otherDetailsItemHeading}>Organization type:</Typography>
          <Typography>{dataType === 'customer' ? data.customerOrganizationType : data.role === 'customer' ? data.customerOrganizationType : 'n/a'}</Typography>
        </Stack>
      </Stack>
    </Stack>
  )
}

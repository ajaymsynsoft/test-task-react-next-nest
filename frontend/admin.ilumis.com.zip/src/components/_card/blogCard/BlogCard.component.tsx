import moment from 'moment'
import Image from 'next/image'
import { Stack, Typography, Card, ButtonBase } from '@mui/material'
import { MdAccessTime } from 'react-icons/md'
import { GrLocation } from 'react-icons/gr'

import { htmlToText } from '@/utils'
import { BlogCardProps } from './BlogCard.type'
import { style } from './BlogCard.style'

export default function BlogCard({ data }: BlogCardProps) {
  const LIST = [
    { Icon: MdAccessTime, label: data.time },
    { Icon: GrLocation, label: data.location },
  ]

  return (
    <Card sx={style.root}>
      <ButtonBase sx={style.box}>
        {/* Date */}
        <Stack sx={style.dateBox}>
          <Typography variant="h1" component="div" fontWeight={800} color="inherit">
            {moment(data.date).format('DD')}
          </Typography>
          <Typography component="div" fontWeight={500} color="inherit">
            {moment(data.date).format('MMM')}
          </Typography>
        </Stack>

        {/* Thumbnail */}
        <Stack sx={style.thumbnailBox}>
          {/* TODO: use size attribute */}
          <Image src={data.image} fill alt="thumbnail" sizes="(min-width:900px) 270px, (min-width:600px) 50vw, 100vw" />
        </Stack>

        {/* Content */}
        <Stack sx={style.contentBox} gap={0.75}>
          <Typography variant="h3">{data.eventName}</Typography>
          <Typography className="line-1">{htmlToText(data.description).slice(0, 100)}</Typography>
          <Stack gap={1.25} mt={1.5}>
            {LIST.map((item, index) => (
              <Stack sx={style.listItem} key={index}>
                <item.Icon />
                <Typography sx={style.listItemLabel}>{item.label}</Typography>
              </Stack>
            ))}
          </Stack>
        </Stack>
      </ButtonBase>
    </Card>
  )
}

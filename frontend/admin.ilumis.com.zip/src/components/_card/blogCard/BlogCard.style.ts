import { alpha } from '@mui/material'
import { Style } from '@/types'

export const style: Style = {
  root: {
    height: 1,
    '--border-radius': '12px',
    borderRadius: 'var(--border-radius)',
    ':hover': {
      boxShadow: '4',
    },
  },
  box: {
    display: 'flex',
    flexFlow: 'column',
    alignItems: 'start',
    textAlign: 'left',
  },
  dateBox: {
    position: 'absolute',
    zIndex: 2,
    top: 15,
    right: 15,
    bgcolor: alpha('#fff', 0.9),
    backdropFilter: 'blur(8px)',
    borderRadius: 1,
    textAlign: 'center',
    py: 1,
    px: 1.5,
    color: 'primary.dark',
  },
  thumbnailBox: {
    width: 1,
    bgcolor: 'divider',
    // TODO: think about it
    aspectRatio: '4/3',
    position: 'relative',
    borderBottomLeftRadius: 'var(--border-radius)',
    borderBottomRightRadius: 'var(--border-radius)',
    overflow: 'hidden',
  },
  contentBox: {
    p: 2,
  },
  listItem: {
    gap: 1.5,
    flexDirection: 'row',
    overflow: 'hidden',
    color: 'primary.main',
  },
  listItemLabel: {
    color: 'inherit',
  },
}

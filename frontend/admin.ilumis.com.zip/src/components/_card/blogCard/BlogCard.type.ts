import { BlogDTO } from '@/dto/Blog.dto'

export type BlogCardProps = {
  data: BlogDTO
}

import Link from 'next/link'
import Image from 'next/image'
import { Stack } from '@mui/material'

import logo from '@/../public/images/logo.svg'
import { LogoProps } from './Logo.type'

export default function Logo(props: LogoProps) {
  const { sx = {}, disableLink = true } = props

  return (
    <Stack className="logo-box" sx={{ width: 'max-content', ...sx }} {...(!disableLink ? { component: Link, href: 'https://www.ilumis.com/' } : {})}>
      <Image src={logo} alt="logo" priority />
    </Stack>
  )
}

import { SxProps, Theme } from '@mui/material'

export type LogoProps = {
  sx?: SxProps<Theme>
  disableLink?: boolean
}

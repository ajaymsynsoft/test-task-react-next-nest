import * as yup from 'yup'

export const schema = yup.object({
  userId: yup.number().required(),
  oldPassword: yup.string().trim().required().max(100),
  password: yup.string().trim().required().max(100),
  confirmPassword: yup
    .string()
    .trim()
    .required()
    .oneOf([yup.ref('password')], 'New password and confirm new password is different'),
})

export type TSchema = yup.InferType<typeof schema>

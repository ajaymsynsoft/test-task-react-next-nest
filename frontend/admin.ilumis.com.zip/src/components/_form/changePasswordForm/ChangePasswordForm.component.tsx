import { useState } from 'react'
import { yupResolver } from '@hookform/resolvers/yup'
import { useForm } from 'react-hook-form'
import { Grid, IconButton, Stack } from '@mui/material'
import { MdVisibility, MdVisibilityOff } from 'react-icons/md'
import { LoadingButton } from '@mui/lab'

import InputField from '@/components/_ui/inputField/InputField.component'
import { schema, TSchema } from './ChangePasswordForm.config'
import { useReduxSelector } from '@/hooks'
import { useChangePasswordMutation } from '@/redux/api/user.api'

export default function ChangePasswordForm() {
  const profile = useReduxSelector((state) => state.layout.profile)
  const [showPassword, setShowPassword] = useState<boolean>(false)
  const [showOldPassword, setShowOldPassword] = useState<boolean>(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false)
  const { modules } = useReduxSelector((state) => state.layout.profile)
  const [changePassword] = useChangePasswordMutation()

  const {
    handleSubmit,
    control,
    reset,
    trigger,
    formState: { isSubmitting, isSubmitted },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      userId: profile.id,
    },
  })

  const onSubmit = async (formData: TSchema) => {
    if (!modules[14].permissions.edit) return
    await changePassword(formData).unwrap()
    reset()
  }

  return (
    <Grid container noValidate component="form" onSubmit={handleSubmit(onSubmit)} spacing={2}>
      {/* Old Password */}
      <Grid item xs={12}>
        <InputField
          name="oldPassword"
          label="Old password"
          type={showOldPassword ? 'text' : 'password'}
          control={control}
          InputProps={{
            endAdornment: <IconButton onClick={() => setShowOldPassword((v) => !v)}>{showOldPassword ? <MdVisibility /> : <MdVisibilityOff />}</IconButton>,
          }}
        />
      </Grid>

      {/* New Password */}
      <Grid item xs={12}>
        <InputField
          name="password"
          label="New password"
          type={showPassword ? 'text' : 'password'}
          control={control}
          onChange={(event, field, value) => {
            field.onChange(value)
            isSubmitted && trigger('confirmPassword')
          }}
          InputProps={{
            endAdornment: <IconButton onClick={() => setShowPassword((v) => !v)}>{showPassword ? <MdVisibility /> : <MdVisibilityOff />}</IconButton>,
          }}
        />
      </Grid>

      {/*Confirm New Password */}
      <Grid item xs={12}>
        <InputField
          name="confirmPassword"
          label="Confirm new password"
          type={showConfirmPassword ? 'text' : 'password'}
          control={control}
          InputProps={{
            endAdornment: <IconButton onClick={() => setShowConfirmPassword((v) => !v)}>{showConfirmPassword ? <MdVisibility /> : <MdVisibilityOff />}</IconButton>,
          }}
        />
      </Grid>

      {/* Footer */}
      <Grid item xs={12}>
        <Stack direction="row" justifyContent="end">
          <LoadingButton loading={isSubmitting} variant="contained" type="submit">
            Update
          </LoadingButton>
        </Stack>
      </Grid>
    </Grid>
  )
}

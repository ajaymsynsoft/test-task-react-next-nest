import * as yup from 'yup'
import { phoneTest, stringTest, emailTest } from '@/utils'
import { Roles } from '@/types'

export const schema = yup.object({
  role: yup.string<Roles>().required(),
  firstName: yup.string().trim().required().max(100).test(stringTest),
  lastName: yup.string().trim().required().max(100).test(stringTest),
  email: yup.string().email().trim().required().max(300).test(emailTest),
  phone: yup.string().trim().required().test(phoneTest),
  countryId: yup.number().required(),
  customerOrganizationTypeId: yup.number().when('role', {
    is: (value: Roles) => value === 'customer',
    then: (schema) => schema.required(),
  }),
  customerOrganizationName: yup
    .string()
    .trim()
    .when('role', {
      is: (value: Roles) => value === 'customer',
      then: (schema) => schema.required().max(300),
    }),
})

export type TSchema = yup.InferType<typeof schema>

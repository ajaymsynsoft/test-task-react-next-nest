import { yupResolver } from '@hookform/resolvers/yup'
import { Controller, useForm } from 'react-hook-form'
import { Autocomplete, FormControl, FormHelperText, Grid, InputLabel, MenuItem, Select, Stack, TextField } from '@mui/material'

import InputField from '@/components/_ui/inputField/InputField.component'
import PhoneField from '@/components/_ui/phoneField/PhoneField.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { schema, TSchema } from './ProfileForm.config'
import { LoadingButton } from '@mui/lab'
import { useReduxSelector } from '@/hooks'
import { useGetCountriesQuery } from '@/redux/api/common.api'
import { useUpdateProfileMutation } from '@/redux/api/user.api'
import { useGetOrganizationTypeListQuery } from '@/redux/api/organization.api'

export default function ProfileForm() {
  const profile = useReduxSelector((state) => state.layout.profile)
  const canEdit = profile.modules[15].permissions.edit

  const [updateProfile] = useUpdateProfileMutation()
  const countriesApiState = useGetCountriesQuery()
  const organizationTypeListApiState = useGetOrganizationTypeListQuery()

  const {
    handleSubmit,
    control,
    formState: { isSubmitting },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      role: profile.role,
      firstName: profile.firstName,
      lastName: profile.lastName,
      email: profile.email,
      phone: profile.phone,
      countryId: profile.countryId as number,
      ...(profile.role === 'customer' && {
        customerOrganizationTypeId: profile.customerOrganizationTypeId,
        customerOrganizationName: profile.customerOrganizationName,
      }),
    },
  })

  const onSubmit = async (formData: TSchema) => {
    if (!canEdit) return
    await updateProfile(formData).unwrap()
  }

  return (
    <RenderContent loading={countriesApiState.isLoading || organizationTypeListApiState.isLoading} error={countriesApiState.isError || organizationTypeListApiState.isError}>
      {countriesApiState.data && organizationTypeListApiState.data && (
        <Grid container noValidate component="form" onSubmit={handleSubmit(onSubmit)} spacing={2}>
          {/* First Name  */}
          <Grid item xs={12}>
            <InputField
              name="firstName"
              label="First name *"
              control={control}
              InputProps={{
                readOnly: !canEdit,
              }}
            />
          </Grid>

          {/* Last Name */}
          <Grid item xs={12}>
            <InputField
              name="lastName"
              label="Last name *"
              control={control}
              InputProps={{
                readOnly: !canEdit,
              }}
            />
          </Grid>

          {/* Email */}
          <Grid item xs={12}>
            <InputField
              name="email"
              label="Email *"
              control={control}
              disabled={canEdit ? true : false}
              InputProps={{
                readOnly: true,
              }}
            />
          </Grid>

          {/* Phone */}
          <Grid item xs={12}>
            <PhoneField name="phone" placeholder="Phone *" control={control} readOnly={!canEdit} />
          </Grid>

          {profile.role === 'customer' && (
            <>
              {/* Organization Type */}
              <Grid item xs={12} sm={6}>
                <Controller
                  name="customerOrganizationTypeId"
                  control={control}
                  render={({ fieldState: { error }, field: { ref, ...restField } }) => (
                    <FormControl error={!!error}>
                      <InputLabel>Organization type *</InputLabel>
                      <Select {...restField} inputRef={ref} label="Organization type *" readOnly={!canEdit}>
                        {organizationTypeListApiState.data?.map((item, index) => (
                          <MenuItem value={item.id} key={index}>
                            {item.type}
                          </MenuItem>
                        ))}
                      </Select>
                      <FormHelperText>{error?.message}</FormHelperText>
                    </FormControl>
                  )}
                />
              </Grid>

              {/* Organization Name */}
              <Grid item xs={12} sm={6}>
                <InputField
                  name="customerOrganizationName"
                  label="Organization name *"
                  control={control}
                  InputProps={{
                    readOnly: !canEdit,
                  }}
                />
              </Grid>
            </>
          )}

          {/* Country */}
          <Grid item xs={12}>
            <Controller
              name="countryId"
              control={control}
              render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                <Autocomplete
                  {...restField}
                  readOnly={!canEdit}
                  options={countriesApiState.data!}
                  value={countriesApiState.data!.find((item) => item.id === value) || null}
                  onChange={(_, value) => onChange(value?.id)}
                  getOptionLabel={(option) => option.name}
                  renderInput={(params) => <TextField {...params} label="Country *" inputRef={ref} error={!!error} helperText={error?.message} inputProps={{ ...params.inputProps, autoComplete: 'new-password' }} />}
                />
              )}
            />
          </Grid>

          {/* Footer */}
          {canEdit && (
            <Grid item xs={12}>
              <Stack direction="row" justifyContent="end">
                <LoadingButton loading={isSubmitting} variant="contained" type="submit">
                  Update
                </LoadingButton>
              </Stack>
            </Grid>
          )}
        </Grid>
      )}
    </RenderContent>
  )
}

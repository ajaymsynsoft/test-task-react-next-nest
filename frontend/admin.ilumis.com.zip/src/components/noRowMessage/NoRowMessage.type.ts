export type NoRowMessageProps = {
  variant?: 'standard' | 'message'
  message?: string
}

export type Roles = 'customer' | 'admin' | 'superAdmin' | 'supportStaff' | 'accommodationStaff' | 'financeStaff' | 'transportationStaff'

export type PaymentMethods = 'cash' | 'card' | 'bankTransfer' | 'wallet'

import { SxProps, Theme } from '@mui/material'

export type Style = Record<string, SxProps<Theme>>

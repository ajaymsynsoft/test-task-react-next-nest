export type Pagination = {
  sortColumn?: string
  sortOrder?: string
  searchText?: string
  pageNo: number
  pageSize: number
}

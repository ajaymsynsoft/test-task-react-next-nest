export type CustomerLayoutProps = {
  children: React.ReactNode
}

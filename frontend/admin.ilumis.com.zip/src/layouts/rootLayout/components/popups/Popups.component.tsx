import dynamic from 'next/dynamic'
import { useRouter } from 'next/router'

import { useReduxSelector } from '@/hooks'

const BookingUnpaidAmountPopup = dynamic(() => import('./bookingUnpaidAmountPopup/BookingUnpaidAmountPopup.component'))
const WalletPaymentPopup = dynamic(() => import('./walletPaymentPopup/WalletPaymentPopup.component'))
const BookingPaymentPopup = dynamic(() => import('./bookingPaymentPopup/BookingPaymentPopup.component'))

export default function Popups() {
  const router = useRouter()
  const { role } = useReduxSelector((state) => state.layout.profile)

  return (
    <>
      {/* Booking UnpaidAmount Popup */}
      {role === 'customer' && router.query.bookingUnpaidAmountPopup === 'true' && <BookingUnpaidAmountPopup />}

      {/* Wallet Payment Popup */}
      {role === 'customer' && router.query.walletPaymentPopup === 'true' && <WalletPaymentPopup />}

      {/* Booking Payment Popup */}
      {role === 'customer' && router.query.bookingPaymentPopup === 'true' && <BookingPaymentPopup />}
    </>
  )
}

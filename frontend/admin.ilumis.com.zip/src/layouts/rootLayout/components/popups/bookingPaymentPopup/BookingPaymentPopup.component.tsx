import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import { Dialog, DialogContent, Stack, Typography } from '@mui/material'

import DialogClose from '@/components/dialogClose/DialogClose.component'
import DialogTransition from '@/components/dialogTransition/DialogTransition.component'
import { useUrlParams } from '@/hooks'

export default function BookingPaymentPopup() {
  const router = useRouter()
  const isSuccess = router.query.status == 'success'

  const [showPopup, setShowPopup] = useState(false)
  const { setUrlParams } = useUrlParams()

  const DATA = {
    video: isSuccess ? `/videos/card-success.mp4` : `/videos/card-declined.mp4`,
    heading: isSuccess ? 'Success!' : 'Failed!',
    description: isSuccess ? `Payment successful.` : `Payment was unsuccessful. Please try again.`,
  }

  useEffect(() => {
    setTimeout(() => {
      setShowPopup(true)
    }, 1000)
  }, [])

  const handleClose = () => {
    setUrlParams({ params: { status: '', bookingPaymentPopup: '' } })
    setShowPopup(false)
  }

  return (
    <Dialog open={showPopup} TransitionComponent={DialogTransition} onClose={handleClose} fullWidth maxWidth="xs" scroll="body">
      <DialogContent>
        {/* Close */}
        <DialogClose onClick={handleClose} variant="absolute" />

        {/* Icon */}
        <Stack alignItems="center" mt={-2}>
          <video width={120} height={120} muted autoPlay playsInline>
            <source src={DATA.video} type="video/mp4" />
          </video>
        </Stack>

        {/* Header */}
        <Stack gap={1}>
          <Typography variant="h2" color={isSuccess ? 'success.dark' : 'error.dark'}>
            {DATA.heading}
          </Typography>
          <Typography variant="subtitle" color="text.secondary">
            {DATA.description}
          </Typography>
        </Stack>
      </DialogContent>
    </Dialog>
  )
}

import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'

import { getCookie } from '@/utils'
import { usePage, useReduxDispatch, useReduxSelector } from '@/hooks'
import { useLazyProfileQuery } from '@/redux/api/user.api'
import { handleWebsiteLoader, updateLoggedIn } from '@/redux/slice/layout.slice'
import { RootLayoutProps } from '@/layouts/rootLayout/RootLayout.type'
import { useLazyGetSubscriptionPlanQuery } from '@/redux/api/subscription.api'
import { useLazyGetPublicOrganizationQuery } from '@/redux/api/organization.api'

export const useAuth = ({ pageType, roles, module }: RootLayoutProps) => {
  const { isAdminDashboard } = usePage()
  const router = useRouter()
  const token = getCookie('token')
  const dispatch = useReduxDispatch()
  const { isLoggedIn, profile } = useReduxSelector((state) => state.layout)

  const [loading, setLoading] = useState(true)
  const [permission, setPermission] = useState(true)
  const [error, setError] = useState(false)

  const [getProfile] = useLazyProfileQuery()
  const [getSubscriptionPlan, subscriptionPlanApiState] = useLazyGetSubscriptionPlanQuery()
  const [getOrganization] = useLazyGetPublicOrganizationQuery()

  useEffect(() => {
    if (!loading) dispatch(handleWebsiteLoader(loading))
  }, [loading])

  useEffect(() => {
    ;(async () => {
      try {
        if (!token) return
        // TODO: update it
        const response = await getProfile(undefined, true).unwrap()
        if (response.role !== 'superAdmin' && response.role !== 'customer') {
          await getOrganization({ id: response.organizationId }).unwrap()
          await getSubscriptionPlan(undefined, true).unwrap()
        }
        dispatch(updateLoggedIn(true))
      } catch (e) {
        setError(true), setLoading(false)
      }
    })()
  }, [])

  useEffect(() => {
    ;(async () => {
      if (!token && pageType === 'protected') await router.replace(`/auth/login?returnTo=${location.pathname}${location.search}${location.hash}`)
      else if (!token) setLoading(false)
      else if (token && pageType === 'auth') await router.replace('/dashboard/home')
      else if (isLoggedIn && pageType === 'protected') {
        let isPermission: boolean = true
        if (module && isPermission) isPermission = profile.modules[module.id]?.permissions[module.permission]
        if (roles && isPermission) isPermission = roles?.includes(profile.role)
        setPermission(!!isPermission)
        setLoading(false)
      }
    })()
  }, [router.pathname, profile, isLoggedIn])

  // TODO: update it, also apply condition on other role along with admin
  if (isAdminDashboard && profile && profile.role === 'admin' && subscriptionPlanApiState.isSuccess && !subscriptionPlanApiState.data && !loading) {
    setLoading(true)
    setTimeout(() => router.replace('/subscription').finally(() => setLoading(false)), 500)
  }

  return {
    isLoading: pageType === 'public' ? false : loading,
    isPermission: pageType !== 'protected' ? true : permission,
    isError: error,
  }
}

export const HEADER_HEIGHT = 74
export const SIDEBAR_WIDTH = 275

export type WalletDTO = {
  amount: number
  id: number
  userId: number
}

export type VisaFeesDTO = {
  countryId: number
  fees: number
}

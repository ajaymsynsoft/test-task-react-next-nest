import { EventDTO } from './Event.dto'
import { InternalMemberDTO } from './InternalMember.dto'

export interface InternalBookingDTO {
  id: number
  userId: number
  eventId: number
  hotelId?: number
  hotelRoomTypeId?: number
  fromDate?: string
  toDate?: string
  visaAssistanceRequired: boolean
  visaOfficialLetterRequired: boolean
  event: Pick<EventDTO, 'id' | 'name'>
  member: InternalMemberDTO
  orderDate: string
  hotelAmount: number
  visaFee: number
  totalAmountInDisplayCurrency: number
  totalAmountInDefaultCurrency: number
}

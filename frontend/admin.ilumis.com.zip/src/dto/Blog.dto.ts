import BLOG_DATA from '../pages/home/components/blogSection/BlogSection.data.json'

export type BlogDTO = (typeof BLOG_DATA)[0]

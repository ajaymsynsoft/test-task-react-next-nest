export interface InternalMemberDTO {
  id: number
  firstName: string
  lastName: string
  email: string
  role: string
  photo: string
  accessCode: string
  country: string
  countryId: number
}

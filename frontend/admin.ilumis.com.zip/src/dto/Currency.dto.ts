export type CurrencyDTO = {
  id: number
  code: string
  name: string
  symbol: string
}

import { CurrencyDTO } from './Currency.dto'

export interface OrganizationDTO {
  id: number
  organizationName: string
  logo: string
  bannerImage?: string
  website?: string
  email: string
  phone: string
  domainName?: string
  theme: Theme
  visaFees: number
  status: 'pending' | 'active' | 'inactive'
  defaultCurrency?: CurrencyDTO
  displayCurrency?: CurrencyDTO
  displayCurrencyRate?: number
  bannerHeading?: string
  bannerSubHeading?: string
  subscriptionId?: string
}

type Theme = {
  color: {
    primary: string
    secondary?: string
    accent?: string
  }
}

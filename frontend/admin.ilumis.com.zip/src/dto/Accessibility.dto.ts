export type AccessibilityDTO = {
  id: number
  name: string
  imageURL: string
}

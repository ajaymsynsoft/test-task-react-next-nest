export type NotificationDTO = {
  id: number
  notificationTypeId: number
  actionType: number
  userId: number
  notificationDateTime: string
  messageTitle: string
  message: string
  isRead: boolean
  createdDate: string
}

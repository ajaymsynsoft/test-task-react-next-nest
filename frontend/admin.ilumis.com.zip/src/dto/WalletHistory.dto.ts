export type WalletHistoryDTO = {
  amount: number
  date: string
  id: number
  orderId: number
  status: 'creditOut' | 'creditIn'
}

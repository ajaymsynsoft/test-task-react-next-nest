import { TGuest } from '@/types/Guest.type'
import { HotelDTO } from './Hotel.dto'
import { CustomerDTO } from './Customer.dto'
import { EventDTO } from './Event.dto'

export type BookingDTO = {
  id: number
  userId: number
  totalAmountInDefaultCurrency: number
  totalAmountInDisplayCurrency: number
  amountPaid: number
  guestDetails: TGuest[]
  orderDate: string | null
  eventId: number
  event?: Pick<EventDTO, 'id' | 'name' | 'description' | 'bannerImage' | 'startDate' | 'endDate' | 'address' | 'city' | 'state' | 'country'>
  accommodationInfo: AccommodationInfo[]
  orderDetails: OrderDetails[]
  user?: CustomerDTO
  createdDate: string
  updatedDate: string | null
  currencyCode: string
  status: 'pending' | 'active' | 'inactive' | 'deleted' | 'draft' | 'cancelled' | 'booked'
  paymentStatus: 'unpaid' | 'paid' | 'partiallyPaid' | 'failed'
  paymentType: 'cash' | 'card' | 'bankTransfer' | 'wallet'
  isVisaEnabled: boolean
  isAccommodationEnabled: boolean
  paidAmount: number
  unpaidAmount: number
  penalties: number
  orderPenalties?: OrderPenalty[]
  bankReceiptImage?: string
}

type OrderPenalty = {
  id: number
  amount: number
  penaltyName: string
  penaltyType: number
}

type OrderDetails = {
  id: number
  type: 'accommodation' | 'registration' | 'visa'
  amount: number
  orderId: number
}

type AccommodationInfo = {
  amount: number
  guestIds: number[]
  guestNames: string[]
  fromDate: string
  toDate: string
  hotelId: number
  hotelRoomTypeId: number
  numberOfNights: number
  orderDetailId: 24
  orderId: 22
  sequenceNo: number
  hotel: Omit<HotelDTO, 'roomType'> & {
    roomType: HotelDTO['roomType'][0]
  }
}

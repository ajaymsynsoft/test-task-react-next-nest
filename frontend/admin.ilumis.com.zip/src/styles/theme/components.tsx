import NoRowMessage from '@/components/noRowMessage/NoRowMessage.component'
import { Theme, Typography, alpha } from '@mui/material'
import type {} from '@mui/x-data-grid/themeAugmentation'
import type {} from '@mui/x-date-pickers/themeAugmentation'

export const overridesComponent = (theme: Theme) => {
  return {
    MuiTypography: {
      defaultProps: {
        variantMapping: {
          display1: 'h1',
          display2: 'h2',
          subtitle: 'div',
        },
      },
    },
    MuiButton: {
      defaultProps: {
        disableElevation: true,
        variant: 'outlined',
      },
      styleOverrides: {
        root: ({ ownerState }) => ({
          variants: [
            {
              props: { variant: 'rounded' },
              style: theme.unstable_sx({
                color: 'background.paper',
                borderRadius: 100,
                py: 1.5,
                px: 3,
                transition: theme.transitions.create(['background-color']),
                bgcolor: 'primary.main',
                zIndex: 1,
                '&:hover': {
                  bgcolor: 'primary.dark',
                },
                '.MuiButton-endIcon': {
                  bgcolor: 'background.paper',
                  color: 'primary.main',
                  height: 30,
                  width: 30,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: '100%',
                  ml: 1.5,
                  mr: -1,
                },
                '&.MuiLoadingButton-loading': {
                  bgcolor: 'action.disabledBackground',
                  '.MuiButton-endIcon': {
                    visibility: 'hidden',
                  },
                },
              }),
            },
            {
              props: { variant: 'rounded', color: 'inherit' },
              style: theme.unstable_sx({
                bgcolor: 'background.paper',
                color: 'primary.main',
                ':before': {
                  content: `''`,
                  position: 'absolute',
                  inset: 0,
                  borderRadius: 'inherit',
                  bgcolor: alpha(theme.palette.primary.main, 0.07),
                  zIndex: -1,
                  opacity: 0,
                  transition: theme.transitions.create(['opacity']),
                },
                '&:hover': {
                  bgcolor: 'background.paper',
                  ':before': {
                    opacity: 1,
                  },
                },
                '.MuiButton-endIcon': {
                  bgcolor: 'primary.main',
                  color: 'background.paper',
                },
              }),
            },
          ],
          textTransform: 'unset',
          whiteSpace: 'nowrap',
          ...(ownerState.variant === 'contained' && {
            color: '#fff',
            fontWeight: 400,
          }),
        }),
        sizeLarge: theme.unstable_sx({
          py: 1.25,
          fontSize: 'body1.fontSize',
        }),
        contained: theme.unstable_sx({
          wordSpacing: 2,
        }),
      },
    },
    MuiTextField: {
      defaultProps: {
        fullWidth: true,
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        notchedOutline: theme.unstable_sx({
          borderColor: 'dividerDark',
        }),
      },
    },
    MuiCheckbox: {
      styleOverrides: {
        root: theme.unstable_sx({
          color: 'rgba(0,0,0,.5)',
        }),
      },
    },
    MuiRadio: {
      styleOverrides: {
        root: theme.unstable_sx({
          color: 'rgba(0,0,0,.5)',
        }),
      },
    },
    MuiAutocomplete: {
      defaultProps: {
        disableClearable: true,
        clearOnBlur: true,
        autoHighlight: true,
        disablePortal: true,
      },
    },
    MuiLink: {
      styleOverrides: {
        root: { cursor: 'pointer' },
      },
    },
    MuiPaper: {
      defaultProps: {
        elevation: 8,
      },
    },
    MuiRating: {
      defaultProps: {
        precision: 0.5,
      },
    },
    MuiSwitch: {
      styleOverrides: {
        root: theme.unstable_sx({
          '--width': '38px',
          '--height': '22px',
          width: 'var(--width)',
          height: 'var(--height)',
          padding: 0,
          '& .MuiSwitch-switchBase': {
            padding: 0,
            margin: '2px',
            transitionDuration: '300ms',
            '&.Mui-checked': {
              transform: 'translateX(calc(var(--width) - var(--height)))',
              color: '#fff',
              '& + .MuiSwitch-track': {
                opacity: 1,
                border: 0,
              },
              '&.Mui-disabled + .MuiSwitch-track': {
                opacity: 0.5,
              },
            },
            '&.Mui-focusVisible .MuiSwitch-thumb': {
              color: '#33cf4d',
              border: '6px solid #fff',
            },
            '&.Mui-disabled .MuiSwitch-thumb': {
              color: theme.palette.grey[100],
            },
            '&.Mui-disabled + .MuiSwitch-track': {
              opacity: 0.7,
            },
          },
          '& .MuiSwitch-thumb': {
            boxSizing: 'border-box',
            width: 'calc(var(--height) - 4px)',
            height: 'calc(var(--height) - 4px)',
          },
          '& .MuiSwitch-track': {
            borderRadius: 100,
            backgroundColor: '#E9E9EA',
            opacity: 1,
            transition: theme.transitions.create(['background-color'], {
              duration: 500,
            }),
          },
        }),
      },
    },
    MuiFormHelperText: {
      styleOverrides: {
        root: theme.unstable_sx({
          ':empty': {
            mt: 0,
          },
          mx: 1.75,
          '&:not(.Mui-error)': {
            fontWeight: 500,
          },
        }),
      },
    },
    MuiInputAdornment: {
      styleOverrides: {
        root: theme.unstable_sx({
          fontSize: '1.375rem',
        }),
      },
    },
    MuiChip: {
      defaultProps: {
        size: 'small',
      },
      styleOverrides: {
        sizeSmall: theme.unstable_sx({
          fontSize: 'body2.fontSize',
        }),
        sizeMedium: theme.unstable_sx({
          fontWeight: 500,
          color: 'text.secondary',
        }),
      },
    },
    MuiFab: {
      defaultProps: { color: 'primary', size: 'small' },
      styleOverrides: {
        root: {
          boxShadow: 'unset',
        },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: theme.unstable_sx({
          textTransform: 'unset',
        }),
      },
    },
    MuiTooltip: {
      styleOverrides: {
        tooltip: theme.unstable_sx({
          fontSize: 'body2.fontSize',
          fontWeight: 300,
        }),
      },
    },
    MuiAlert: {
      styleOverrides: {
        root: theme.unstable_sx({
          typography: 'body1',
        }),
      },
    },
    MuiDialogContent: {
      styleOverrides: {
        root: theme.unstable_sx({
          p: 3,
        }),
      },
    },
    MuiDialogTitle: {
      defaultProps: {
        component: Typography,
        variant: 'h2',
      },
    },
    MuiDialogActions: {
      styleOverrides: {
        root: theme.unstable_sx({
          px: 3,
          py: 1.5,
        }),
      },
    },
    MuiMenuItem: {
      styleOverrides: {
        root: theme.unstable_sx({
          '&.Mui-disabled': {
            opacity: 0.7,
          },
        }),
      },
    },
    MuiDataGrid: {
      defaultProps: {
        autoHeight: true,
        rowCount: 0,
        rowHeight: 60,
        columnHeaderHeight: 60,
        disableRowSelectionOnClick: true,
        disableColumnMenu: true,
        paginationMode: 'server',
        pageSizeOptions: [10, 25, 50, 100],
        slots: {
          noRowsOverlay: NoRowMessage,
        },
      },
      styleOverrides: {
        root: ({ ownerState }) =>
          theme.unstable_sx({
            '--DataGrid-rowBorderColor': theme.palette.divider,
            '--unstable_DataGrid-radius': '20px',
            color: 'text.secondary',
            typography: 'body1',
            wordBreak: 'break-word',
            display: 'grid',
            overflow: 'hidden',
            animation: 'fadeIn 0.5s forwards',
            ...(!ownerState?.hideFooter && { '--DataGrid-overlayHeight': '300px' }),
            '&.MuiDataGrid-withBorderColor, .MuiDataGrid-withBorderColor': {
              borderColor: 'var(--DataGrid-rowBorderColor)',
            },
            '.MuiDataGrid-columnSeparator': theme.unstable_sx({
              color: 'dividerDark',
            }),
            '.MuiDataGrid-columnHeaders': {
              '--DataGrid-containerBackground': 'transparent',
              bgcolor: alpha(theme.palette.primary.main, 0.07),
              borderTopLeftRadius: 'calc(var(--unstable_DataGrid-radius) - 1px)',
              borderTopRightRadius: 'calc(var(--unstable_DataGrid-radius) - 1px)',
            },
            '.MuiDataGrid-columnHeader, .MuiDataGrid-cell': {
              outline: 'unset !important',
            },
            '.MuiDataGrid-columnHeaderTitle': {
              fontWeight: 600,
              color: 'primary.main',
            },
            '.MuiDataGrid-topContainer': {
              breakInside: 'avoid',
            },
            '.MuiDataGrid-row--dynamicHeight': {
              '.MuiDataGrid-cell': {
                py: 2.5,
                display: 'flex',
                alignItems: 'center',
                minHeight: 60,
              },
            },
          }),
      },
    },
    MuiTablePagination: {
      styleOverrides: {
        selectLabel: theme.unstable_sx({
          typography: 'body1',
          color: 'text.secondary',
        }),
        displayedRows: theme.unstable_sx({
          typography: 'body1',
          color: 'text.secondary',
        }),
      },
    },
    MuiMobileDatePicker: {
      defaultProps: {
        slotProps: {
          toolbar: {
            sx: theme.unstable_sx({
              '.MuiDatePickerToolbar-title': {
                fontSize: '1.5rem',
              },
            }),
          },
        },
      },
    },
    MuiMobileTimePicker: {
      defaultProps: {
        slotProps: {
          toolbar: {
            sx: theme.unstable_sx({
              '.MuiTimePickerToolbar-hourMinuteLabel .MuiPickersToolbarText-root': {
                fontSize: '2rem',
              },
              '.MuiTimePickerToolbar-ampmLabel.Mui-selected': {
                color: 'primary.main',
              },
            }),
          },
        },
      },
    },
    MuiMobileDateTimePicker: {
      defaultProps: {
        slotProps: {
          toolbar: {
            sx: theme.unstable_sx({
              '.MuiPickersToolbarText-root.MuiTypography-h4': {
                fontSize: '1.5rem',
                color: 'text.primary',
              },
              '.MuiDateTimePickerToolbar-timeDigitsContainer .MuiPickersToolbarText-root': {
                fontSize: '2rem',
              },
              '.MuiDateTimePickerToolbar-timeDigitsContainer': {
                alignItems: 'center',
              },
              '.MuiDateTimePickerToolbar-ampmLabel.Mui-selected': {
                color: 'primary.main',
              },
            }),
          },
        },
      },
    },
    MuiTabPanel: {
      styleOverrides: {
        root: theme.unstable_sx({
          p: 0,
        }),
      },
    },
    MuiPagination: {
      defaultProps: {
        shape: 'rounded',
        color: 'primary',
      },
      styleOverrides: {
        root: theme.unstable_sx({
          '.MuiPaginationItem-page': {
            fontSize: 'body1.fontSize',
          },
        }),
      },
    },
    MuiCard: {
      defaultProps: {
        elevation: 3,
      },
    },
    MuiCardContent: {
      styleOverrides: {
        root: theme.unstable_sx({
          '&, &:last-child': {
            p: '16px',
          },
        }),
      },
    },
    MuiFormControlLabel: {
      styleOverrides: {
        root: theme.unstable_sx({
          '.MuiSwitch-root': {
            mx: 1.5,
          },
        }),
      },
    },
    MuiFormControl: {
      defaultProps: {
        fullWidth: true,
      },
      styleOverrides: {
        root: theme.unstable_sx({
          '& > .MuiInputLabel-outlined': {
            '&.MuiInputLabel-shrink, &.MuiInputLabel-shrink ~ div > fieldset.MuiOutlinedInput-notchedOutline': {
              fontSize: `calc(${theme.typography.body1.fontSize} + 2px) !important`,
            },
          },
          '.MuiFormLabel-root + .MuiFormControlLabel-root > .MuiSwitch-root, .MuiFormLabel-root + .MuiFormControlLabel-root > .MuiFormControlLabel-label': {
            mt: 1.5,
          },
        }),
      },
    },
  } as Theme['components']
}

declare module '@mui/material/Button' {
  interface ButtonPropsVariantOverrides {
    rounded: true
  }
}

import { OrganizationDTO } from '@/dto'
import { Theme } from '@mui/material'
import { lime } from '@mui/material/colors'

export const createPalette = (orgTheme?: OrganizationDTO['theme']) => {
  return {
    mode: 'light',
    divider: '#e8e8e8',
    dividerDark: '#dddddd',
    primary: {
      main: '#00a76f',
    },
    secondary: {
      main: lime['800'],
    },
    background: {
      bg1: '#fafafa',
      bg2: '#f6f6f6',
      default: '#FDFBFB',
      paper: '#ffffff',
    },
    text: {
      secondary: 'rgba(0, 0, 0, .67)',
      disabled: 'rgba(0, 0, 0, 0.45)',
    },
    success: {
      main: '#00A76F',
    },
  } as Theme['palette']
}

/* Typescript
======================== */
declare module '@mui/material/styles' {
  interface Palette {
    dividerDark: Palette['divider']
  }
  interface PaletteOptions {
    dividerDark?: PaletteOptions['divider']
  }
}

declare module '@mui/material/styles' {
  interface TypeBackground {
    bg1: string
    bg2: string
  }
}

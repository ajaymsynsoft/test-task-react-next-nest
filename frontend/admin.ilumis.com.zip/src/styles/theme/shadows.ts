import { Theme } from '@mui/material'

export const overridesShadows = ({ shadows }: Theme) => {
  shadows[3] = '0px 0px 11.7px 0px rgba(126, 126, 126, 0.11)'
  shadows[4] = '0px 0px 11.7px 0px rgba(126, 126, 126, 0.3)'

  return shadows
}

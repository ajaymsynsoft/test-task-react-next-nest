import moment from 'moment'

moment.defaultFormat = 'll'

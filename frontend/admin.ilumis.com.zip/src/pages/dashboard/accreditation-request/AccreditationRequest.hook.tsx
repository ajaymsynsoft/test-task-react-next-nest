import Image from 'next/image'
import { Chip, Stack, Typography } from '@mui/material'
import { GridColDef } from '@mui/x-data-grid'

import { formatToTitleCase, getStatusColor } from '@/utils'
import { AccreditationRequestDTO } from '@/dto/AccreditationRequest.dto'

export const useColumns = () => {
  const columns: GridColDef<AccreditationRequestDTO>[] = [
    { field: 'id', headerName: 'ID', sortable: false, minWidth: 85, width: 85, valueFormatter: (value) => `#${value}` },
    {
      field: 'image',
      headerName: 'Image',
      sortable: false,
      minWidth: 180,
      renderCell: ({ row }) => (
        <Stack sx={{ img: { borderRadius: 1, border: 1, borderColor: 'divider', bgcolor: 'background.bg1' } }}>
          <Image src={row.templateImage} alt="accreditation image" width={160} height={82} />
        </Stack>
      ),
    },
    {
      field: 'instruction',
      headerName: 'Instruction',
      sortable: false,
      minWidth: 100,
      flex: 1,
      renderCell: ({ row }) => <Typography className="line-1">{row.instruction || '-'}</Typography>,
    },
    {
      field: 'status',
      headerName: 'Status',
      sortable: false,
      minWidth: 100,
      renderCell: (params) => {
        return <Chip label={formatToTitleCase(params.value)} variant="outlined" color={getStatusColor(params.value)} />
      },
    },
  ]

  return columns
}

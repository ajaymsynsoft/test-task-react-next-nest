import { Container } from '@mui/material'
import { DataGrid } from '@mui/x-data-grid'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { usePagination } from '@/hooks'
import { useGetAccreditationRequestListQuery } from '@/redux/api/accreditation.api'
import { useColumns } from './AccreditationRequest.hook'

const AccreditationRequest: Page = () => {
  const columns = useColumns()
  const { paginationModel, setPaginationModel, page, pageSize } = usePagination()
  const { data, isFetching, isError, isLoading } = useGetAccreditationRequestListQuery({ pageNo: page, pageSize })

  return (
    <>
      <PageHeader heading="Accreditation Request" count={data?.totalCount} />

      <Container>
        <RenderContent loading={isLoading} error={isError}>
          <DataGrid loading={isFetching} columns={columns} rowCount={data?.totalCount || 0} rows={data?.list || []} getRowHeight={() => 'auto'} paginationModel={paginationModel} onPaginationModelChange={setPaginationModel} />
        </RenderContent>
      </Container>
    </>
  )
}

AccreditationRequest.rootLayoutProps = {
  title: 'Accreditation Change Request',
  pageType: 'protected',
  roles: ['superAdmin'],
}

export default AccreditationRequest

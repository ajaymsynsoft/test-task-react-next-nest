import { Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import OrganizationForm from '../components/organizationForm/OrganizationForm.component'
import { Page } from '@/types'

const AddOrganization: Page = () => {
  return (
    <>
      <PageHeader heading="Add Organization" backUrl="/dashboard/organizations" />

      <Container>
        <OrganizationForm isEditMode={false} />
      </Container>
    </>
  )
}

AddOrganization.rootLayoutProps = {
  title: 'Add Organization',
  pageType: 'protected',
  module: {
    id: 1,
    permission: 'add',
  },
}

export default AddOrganization

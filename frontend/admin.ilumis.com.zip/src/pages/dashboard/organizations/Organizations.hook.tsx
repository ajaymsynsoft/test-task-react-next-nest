import Image from 'next/image'
import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/router'
import { MdDelete, MdEdit } from 'react-icons/md'
import { Chip, Stack, Typography, Link as MuiLink } from '@mui/material'
import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'

import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import { formatToTitleCase, getStatusColor } from '@/utils'
import { OrganizationDTO } from '@/dto'
import { useDeleteOrganizationMutation } from '@/redux/api/organization.api'
import { useReduxSelector } from '@/hooks'

export const useColumns = () => {
  const router = useRouter()
  const [deleteItemId, setDeleteItemId] = useState<number | null>(null)
  const [deleteOrganization, { isLoading }] = useDeleteOrganizationMutation()
  const { modules } = useReduxSelector((state) => state.layout.profile)

  const columns: GridColDef<OrganizationDTO>[] = [
    {
      field: 'id',
      headerName: 'ID',
      sortable: false,
      minWidth: 85,
      width: 85,
      renderCell: ({ row }) => (
        <MuiLink component={Link} href={`/dashboard/organizations/edit/${row.id}`}>
          #{row.id}
        </MuiLink>
      ),
    },
    {
      field: 'organizationName',
      headerName: 'Organization',
      sortable: false,
      display: 'flex',
      flex: 1,
      minWidth: 300,
      renderCell: (params) => (
        <Stack direction="row" alignItems="center" gap={1}>
          <Image src={params.row.logo} alt="logo" width={40} height={40} style={{ objectFit: 'contain', maxHeight: 40 }} />
          <Typography noWrap>{params.row.organizationName}</Typography>
        </Stack>
      ),
    },
    {
      field: 'email',
      headerName: 'Email',
      sortable: false,
      flex: 1,
      minWidth: 150,
    },
    {
      field: 'phone',
      headerName: 'Phone',
      sortable: false,
      minWidth: 150,
    },
    {
      field: 'status',
      headerName: 'Status',
      sortable: false,
      minWidth: 100,
      renderCell: (params) => {
        return <Chip label={formatToTitleCase(params.value)} variant="outlined" color={getStatusColor(params.value)} />
      },
    },
    {
      field: 'actions',
      headerName: 'Actions',
      sortable: false,
      minWidth: 80,
      width: 80,
      align: 'center',
      type: 'actions',
      getActions: (params) => {
        const actions = []

        if (modules[1].permissions.edit) actions.push(<GridActionsCellItem showInMenu key="edit" label="Edit" icon={<MdEdit />} onClick={(_) => router.push(`/dashboard/organizations/edit/${params.id}`)} />)

        if (modules[1].permissions.delete)
          actions.push(
            <GridActionsCellItem showInMenu key="delete" label="Delete" icon={<MdDelete />} onClick={(_) => setDeleteItemId(params.row.id)} />,
            <ConfirmationPopup
              key="deletePopup"
              heading="Delete organization"
              subheading={`Sure to delete "${params.row.organizationName}" organization?`}
              acceptButtonText="Delete"
              loading={isLoading}
              open={params.id === deleteItemId}
              onCancel={() => setDeleteItemId(null)}
              onAccept={() =>
                deleteOrganization(params.row.id)
                  .unwrap()
                  .then(() => setDeleteItemId(null))
              }
            />,
          )

        return actions
      },
    },
  ]

  return columns
}

import { useRouter } from 'next/router'
import { Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import OrganizationForm from '../components/organizationForm/OrganizationForm.component'
import { Page } from '@/types'
import { useGetOrganizationQuery } from '@/redux/api/organization.api'

const EditOrganization: Page = () => {
  const router = useRouter()
  const { isFetching, isError, data } = useGetOrganizationQuery(Number(router.query.id))

  return (
    <>
      <PageHeader heading="Edit Organization" backUrl="/dashboard/organizations" />

      <Container>
        <RenderContent loading={isFetching} error={isError}>
          {data && <OrganizationForm isEditMode data={data} />}
        </RenderContent>
      </Container>
    </>
  )
}

EditOrganization.rootLayoutProps = {
  title: 'Edit Organization',
  pageType: 'protected',
  module: {
    id: 1,
    permission: 'edit',
  },
}

export default EditOrganization

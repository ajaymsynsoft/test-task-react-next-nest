import { useState } from 'react'
import { useRouter } from 'next/router'
import { MdVisibility, MdVisibilityOff } from 'react-icons/md'
import { Controller, useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { LoadingButton } from '@mui/lab'
import { FormControl, FormHelperText, Grid, IconButton, InputLabel, MenuItem, Select, Stack } from '@mui/material'

import InputField from '@/components/_ui/inputField/InputField.component'
import ImageField from '@/components/_ui/imageField/ImageField.component'
import PhoneField from '@/components/_ui/phoneField/PhoneField.component'
import ColorField from '@/components/_ui/colorField/ColorField.component'
import { jsonToFormData } from '@/utils'
import { useUploadFileMutation } from '@/redux/api/common.api'
import { OrganizationFormProps } from './OrganizationForm.type'
import { useAddOrganizationMutation, useUpdateOrganizationMutation } from '@/redux/api/organization.api'
import { TSchema, schema } from './OrganizationForm.config'

export default function OrganizationForm({ isEditMode, data }: OrganizationFormProps) {
  const router = useRouter()
  const [showPassword, setShowPassword] = useState<boolean>(false)
  const [uploadFile] = useUploadFileMutation()
  const [addOrganization] = useAddOrganizationMutation()
  const [updateOrganization] = useUpdateOrganizationMutation()

  const {
    handleSubmit,
    control,
    setValue,
    getValues,
    formState: { isSubmitting },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      isEditMode,
      ...(isEditMode && {
        organizationName: data.organizationName,
        status: data.status,
        email: data.email,
        phone: data.phone,
        domainName: data.domainName,
        logo: data.logo,
        theme: data.theme,
        visaFees: data.visaFees,
      }),
    },
  })

  const onSubmit = async () => {
    const formData = getValues()
    if (isEditMode) {
      if (formData.logo instanceof File) {
        const [image] = await uploadFile({ files: formData.logo, folderName: 'organization' }).unwrap()
        formData.logo = image
        setValue('logo', image)
      }

      await updateOrganization({ ...formData, id: data.id, logo: formData.logo }).unwrap()
    } else {
      // INFO:  Removing optional empty fields
      if (!formData.website) delete formData.website
      await addOrganization(jsonToFormData(formData)).unwrap()
    }

    router.push('/dashboard/organizations')
  }

  return (
    <Grid container component="form" noValidate onSubmit={handleSubmit(onSubmit)} spacing={2}>
      {/* Organization Name */}
      <Grid item xs={12} sm={9}>
        <InputField name="organizationName" label="Organization name *" control={control} />
      </Grid>

      {/* Status */}
      <Grid item xs={12} sm={3}>
        <Controller
          name="status"
          control={control}
          defaultValue={'' as any}
          render={({ fieldState: { error }, field: { ref, ...restField } }) => (
            <FormControl error={!!error}>
              <InputLabel>Status *</InputLabel>
              <Select {...restField} inputRef={ref} label="Status *">
                <MenuItem value="pending">Pending</MenuItem>
                <MenuItem value="active">Active</MenuItem>
                <MenuItem value="inactive">Inactive</MenuItem>
              </Select>
              <FormHelperText>{error?.message}</FormHelperText>
            </FormControl>
          )}
        />
      </Grid>

      {/* Email */}
      <Grid item xs={12} sm={6}>
        <InputField name="email" label="Email *" control={control} disabled={isEditMode} />
      </Grid>

      {/* Phone */}
      <Grid item xs={12} sm={6}>
        <PhoneField name="phone" placeholder="Phone *" control={control} />
      </Grid>

      {/* Select Color */}
      <Grid item xs={12}>
        <ColorField name="theme.color.primary" control={control} />
      </Grid>

      <Grid container item spacing={2} xs={12} sm={9} alignContent="start">
        {/* Domain Name */}
        <Grid item xs={12}>
          <InputField name="domainName" label="Domain name *" control={control} />
        </Grid>

        {/* Password */}
        {!isEditMode && (
          <Grid item xs={12}>
            <InputField
              name="password"
              label="Password *"
              type={showPassword ? 'text' : 'password'}
              control={control}
              InputProps={{
                endAdornment: <IconButton onClick={() => setShowPassword((v) => !v)}>{showPassword ? <MdVisibility /> : <MdVisibilityOff />}</IconButton>,
              }}
            />
          </Grid>
        )}
      </Grid>

      {/* Logo */}
      <Grid item xs={12} sm={3}>
        <ImageField name="logo" label="Organization logo *" control={control} />
      </Grid>

      {/* Footer */}
      <Grid item xs={12}>
        <Stack direction="row" justifyContent="end" gap={1}>
          <LoadingButton variant="text" disabled={isSubmitting} onClick={() => router.push('/dashboard/organizations')}>
            Cancel
          </LoadingButton>
          <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
            {isEditMode ? 'Update' : 'Save'}
          </LoadingButton>
        </Stack>
      </Grid>
    </Grid>
  )
}

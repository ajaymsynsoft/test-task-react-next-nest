import { OrganizationDTO } from '@/dto'

export type OrganizationFormProps =
  | {
      isEditMode: false
      data?: void
    }
  | {
      isEditMode: true
      data: OrganizationDTO
    }

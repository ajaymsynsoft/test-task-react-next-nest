import Link from 'next/link'
import { Button, Container } from '@mui/material'
import { MdAdd } from 'react-icons/md'
import { DataGrid } from '@mui/x-data-grid'
import { useRouter } from 'next/router'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { useColumns } from './Organizations.hook'
import { usePagination, useReduxSelector } from '@/hooks'
import { useGetOrganizationListQuery } from '@/redux/api/organization.api'

const Organizations: Page = () => {
  const columns = useColumns()
  const router = useRouter()
  const { paginationModel, setPaginationModel, page, pageSize } = usePagination()
  const { modules } = useReduxSelector((state) => state.layout.profile)
  const { data, isFetching, isLoading, isError } = useGetOrganizationListQuery({ pageNo: page, pageSize })

  return (
    <>
      <PageHeader
        heading="Organizations"
        count={data?.totalCount}
        actions={
          modules[1].permissions.add && (
            <Button startIcon={<MdAdd />} LinkComponent={Link} variant="contained" href="/dashboard/organizations/add">
              Add organization
            </Button>
          )
        }
      />

      <Container>
        <RenderContent loading={isLoading} error={isError}>
          <DataGrid loading={isFetching} columns={columns} rowCount={data?.totalCount || 0} rows={data?.list || []} paginationModel={paginationModel} onPaginationModelChange={setPaginationModel} />
        </RenderContent>
      </Container>
    </>
  )
}

Organizations.rootLayoutProps = {
  title: 'Organizations',
  pageType: 'protected',
  module: {
    id: 1,
    permission: 'view',
  },
}

export default Organizations

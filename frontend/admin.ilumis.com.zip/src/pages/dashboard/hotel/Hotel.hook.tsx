import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/router'
import { MdDelete, MdEdit } from 'react-icons/md'
import { Rating, Link as MuiLink } from '@mui/material'
import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'

import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import { HotelDTO } from '@/dto'
import { useDeleteHotelMutation } from '@/redux/api/hotel.api'
import { useReduxSelector } from '@/hooks'

export const useColumns = () => {
  const router = useRouter()
  const [deleteItemId, setDeleteItemId] = useState<number | null>(null)
  const [deleteHotel, { isLoading }] = useDeleteHotelMutation()
  const { modules } = useReduxSelector((state) => state.layout.profile)

  const columns: GridColDef<HotelDTO>[] = [
    {
      field: 'id',
      headerName: 'ID',
      sortable: false,
      minWidth: 85,
      width: 85,
      renderCell: ({ row }) => (
        <MuiLink component={Link} href={`/dashboard/hotel/edit/${row.id}`}>
          #{row.id}
        </MuiLink>
      ),
    },
    {
      field: 'name',
      headerName: 'Name',
      sortable: false,
      minWidth: 250,
    },
    {
      field: 'address',
      headerName: 'Address',
      sortable: false,
      flex: 1,
      minWidth: 250,
      renderCell: ({ row }) => `${row.address}, ${row.city}, ${row.state}, ${row.country} - ${row.postalCode}`,
    },
    {
      field: 'rating',
      headerName: 'Rating',
      sortable: false,
      minWidth: 130,
      renderCell: (params) => <Rating value={params.row.rating} readOnly size="small" />,
    },
    {
      field: 'actions',
      headerName: 'Actions',
      sortable: false,
      minWidth: 80,
      width: 80,
      align: 'center',
      type: 'actions',
      getActions: (params) => {
        const actions = []

        if (modules[4].permissions.edit) actions.push(<GridActionsCellItem showInMenu key="edit" label="Edit" icon={<MdEdit />} onClick={(_) => router.push(`/dashboard/hotel/edit/${params.id}`)} />)

        if (modules[4].permissions.delete)
          actions.push(
            <GridActionsCellItem showInMenu key="delete" label="Delete" icon={<MdDelete />} onClick={(_) => setDeleteItemId(params.row.id)} />,
            <ConfirmationPopup
              key="deletePopup"
              heading="Delete hotel"
              subheading={`Sure to delete "${params.row.name}" hotel?`}
              acceptButtonText="Delete"
              loading={isLoading}
              open={params.id === deleteItemId}
              onCancel={() => setDeleteItemId(null)}
              onAccept={() =>
                deleteHotel(params.row.id)
                  .unwrap()
                  .then(() => setDeleteItemId(null))
              }
            />,
          )

        return actions
      },
    },
  ]

  return columns
}

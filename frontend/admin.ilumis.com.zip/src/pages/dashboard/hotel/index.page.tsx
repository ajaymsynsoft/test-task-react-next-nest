import Link from 'next/link'
import { Button, Container } from '@mui/material'
import { MdAdd } from 'react-icons/md'
import { DataGrid } from '@mui/x-data-grid'
import { useRouter } from 'next/router'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { useColumns } from './Hotel.hook'
import { useGetHotelListQuery } from '@/redux/api/hotel.api'
import { usePagination, useReduxSelector } from '@/hooks'

const Hotel: Page = () => {
  const columns = useColumns()
  const router = useRouter()
  const { modules } = useReduxSelector((state) => state.layout.profile)
  const { paginationModel, setPaginationModel, page, pageSize } = usePagination()
  const { data, isFetching, isError, isLoading } = useGetHotelListQuery({ pageNo: page, pageSize })

  return (
    <>
      <PageHeader
        heading="Hotel"
        count={data?.totalCount}
        actions={
          modules[4].permissions.add && (
            <Button startIcon={<MdAdd />} LinkComponent={Link} variant="contained" href="/dashboard/hotel/add">
              Add Hotel
            </Button>
          )
        }
      />

      <Container>
        <RenderContent loading={isLoading} error={isError}>
          <DataGrid loading={isFetching} columns={columns} rowCount={data?.totalCount || 0} rows={data?.list || []} getRowHeight={() => 'auto'} paginationModel={paginationModel} onPaginationModelChange={setPaginationModel} />
        </RenderContent>
      </Container>
    </>
  )
}

Hotel.rootLayoutProps = {
  title: 'Hotel',
  pageType: 'protected',
  module: {
    id: 4,
    permission: 'view',
  },
}

export default Hotel

import { useState } from 'react'
import { useRouter } from 'next/router'
import { Controller, useFieldArray, useForm } from 'react-hook-form'
import { Autocomplete, Button, Checkbox, FormControl, FormHelperText, FormLabel, Grid, Rating, Stack, TextField } from '@mui/material'
import { yupResolver } from '@hookform/resolvers/yup'
import { LoadingButton } from '@mui/lab'
import { MdAdd, MdOutlineHotel, MdOutlinePlace } from 'react-icons/md'
import { DataGrid } from '@mui/x-data-grid'

import InputField from '@/components/_ui/inputField/InputField.component'
import HeadingWithIcon from '@/components/_ui/headingWithIcon/HeadingWithIcon.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import RoomTypeForm from './components/roomTypeForm/RoomTypeForm.component'
import NoRowMessage from '@/components/noRowMessage/NoRowMessage.component'
import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import { TRoomTypeSchema, TSchema, schema } from './HotelForm.config'
import { HotelFormProps, Mode } from './HotelForm.type'
import { useGetEventsListQuery } from '@/redux/api/event.api'
import { useAddHotelMutation, useDeleteRoomTypeMutation, useUpdateHotelMutation } from '@/redux/api/hotel.api'
import { useGetCountriesQuery } from '@/redux/api/common.api'
import { useColumns } from './HotelForm.hook'
import { addSerialNumber } from '@/utils'

export default function HotelForm({ isEditMode, data }: HotelFormProps) {
  const router = useRouter()
  const columns = useColumns({ handleEditRoomType, handleDeleteRoomType })
  const [editRoomTypeIndex, setEditRoomTypeIndex] = useState<number | null>(null)
  const [deleteRoomTypeIndex, setDeleteRoomTypeIndex] = useState<number | null>(null)
  const [roomTypeFormMode, setRoomTypeFormMode] = useState<null | Mode>(null)

  const eventListApiState = useGetEventsListQuery({ pageNo: 1, pageSize: 1000 })
  const countriesApiState = useGetCountriesQuery()
  const [addHotel] = useAddHotelMutation()
  const [updateHotel] = useUpdateHotelMutation()
  const [deleteRoomType, deleteRoomTypeApiState] = useDeleteRoomTypeMutation()

  const {
    handleSubmit,
    control,
    formState: { isSubmitting },
    getValues,
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      isEditMode,
      ...(isEditMode && {
        id: data.id,
        name: data.name,
        rating: data.rating,
        eventIds: data.eventIds,
        address: data.address,
        city: data.city,
        state: data.state,
        countryId: data.countryId,
        postalCode: data.postalCode,
        roomType: data.roomType.map((item) => ({
          roomId: item.id,
          availability: item.availability,
          currencyId: item.currencyId,
          maximumOccupancy: item.maximumOccupancy,
          minimumOccupancy: item.minimumOccupancy,
          nightPrice: item.nightPrice,
          packagePrice: item.packagePrice,
          roomSize: item.roomSize,
          status: item.status,
        })),
      }),
    },
  })

  const roomTypeField = useFieldArray({ name: 'roomType', control })

  const handleSaveRoomType = (formData: TRoomTypeSchema, mode: Mode) => {
    if (mode === 'add') roomTypeField.append(formData)
    else roomTypeField.update(editRoomTypeIndex as number, formData)
  }

  function handleEditRoomType(index: number) {
    setRoomTypeFormMode('edit')
    setEditRoomTypeIndex(index)
  }

  function handleDeleteRoomType(index: number) {
    setDeleteRoomTypeIndex(index)
  }

  const onSubmit = async () => {
    const formData = schema.validateSync(getValues())

    if (isEditMode) await updateHotel({ ...formData, id: data.id, roomType: formData.roomType.map((item) => ({ ...item, id: item.roomId! })) }).unwrap()
    else await addHotel(formData).unwrap()
    router.push('/dashboard/hotel')
  }

  return (
    <RenderContent loading={eventListApiState.isLoading || countriesApiState.isLoading} error={eventListApiState.isError || countriesApiState.isError}>
      <Grid container noValidate component="form" onSubmit={handleSubmit(onSubmit)} spacing={2}>
        {/* Hotel Name */}
        <Grid item xs={12} sm>
          <InputField name="name" label="Hotel name *" control={control} />
        </Grid>

        {/* Rating */}
        <Grid item xs={12} sm="auto">
          <Stack position="relative" overflow="hidden">
            <Controller
              name="rating"
              control={control}
              defaultValue={null as any}
              render={({ fieldState: { error }, field: { onChange, ref, ...restField } }) => (
                <FormControl error={!!error}>
                  <FormLabel sx={{ mb: 0.5 }}>Hotel rating *</FormLabel>
                  <Rating {...restField} onChange={(_, value) => onChange(value)} />
                  <FormHelperText>{error?.message}</FormHelperText>
                  {/* INFO: This input is only for error focus */}
                  <input ref={ref} style={{ position: 'absolute', zIndex: -99, opacity: 0.01, width: 1, height: 1 }} />
                </FormControl>
              )}
            />
          </Stack>
        </Grid>

        {/* Select Event */}
        <Grid item xs={12}>
          <Controller
            name="eventIds"
            control={control}
            defaultValue={[]}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <Autocomplete
                {...restField}
                multiple
                disableCloseOnSelect
                value={eventListApiState.data?.list.filter((item) => value.includes(item.id)) || []}
                options={eventListApiState.data?.list || []}
                onChange={(_, value) => onChange(value.map((item) => item.id))}
                getOptionLabel={(option) => option.name}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                renderInput={(params) => <TextField {...params} label="Select events" inputRef={ref} error={!!error} helperText={error?.message || 'Assign this hotel to events'} />}
                renderOption={(props, option, { selected }) => (
                  <li {...props} key={props.key}>
                    <Checkbox edge="start" size="small" checked={selected} disableRipple />
                    {option.name}
                  </li>
                )}
              />
            )}
          />
        </Grid>

        {/* Heading */}
        <Grid item xs={12} mt={2}>
          <HeadingWithIcon Icon={MdOutlinePlace} text="Address" />
        </Grid>

        {/* Address */}
        <Grid item xs={12}>
          <InputField name="address" label="Address *" control={control} />
        </Grid>

        {/* City */}
        <Grid item xs={12} sm={6}>
          <InputField name="city" label="City *" control={control} />
        </Grid>

        {/* State */}
        <Grid item xs={12} sm={6}>
          <InputField name="state" label="State *" control={control} />
        </Grid>

        {/* Country */}
        <Grid item xs={12} sm={6}>
          <Controller
            name="countryId"
            control={control}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <Autocomplete
                {...restField}
                options={countriesApiState.data || []}
                value={countriesApiState.data!.find((item) => item.id === value) || null}
                onChange={(_, value) => onChange(value?.id)}
                getOptionLabel={(option) => option.name}
                renderInput={(params) => <TextField {...params} label="Country *" inputRef={ref} error={!!error} helperText={error?.message} inputProps={{ ...params.inputProps, autoComplete: 'new-password' }} />}
              />
            )}
          />
        </Grid>

        {/* Postal Code */}
        <Grid item xs={12} sm={6}>
          <InputField name="postalCode" label="Postal Code *" control={control} />
        </Grid>

        {/* Heading */}
        <Grid item xs={12} mt={2}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" gap={2}>
            <HeadingWithIcon Icon={MdOutlineHotel} text="Room Type" />
            <Button size="small" startIcon={<MdAdd />} onClick={() => setRoomTypeFormMode('add')}>
              Add Room Type
            </Button>
          </Stack>
        </Grid>

        {/* Room Type Table */}
        <Grid item xs={12}>
          <DataGrid
            hideFooter
            columns={columns}
            rows={addSerialNumber(roomTypeField.fields, 1, 1000)}
            slots={{
              noRowsOverlay: () => <NoRowMessage variant="message" message="No room type added" />,
            }}
          />
        </Grid>

        {/* Footer */}
        <Grid item xs={12}>
          <Stack direction="row" justifyContent="end" gap={1}>
            <LoadingButton variant="text" disabled={isSubmitting} onClick={() => router.push('/dashboard/hotel')}>
              Cancel
            </LoadingButton>
            <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
              {isEditMode ? 'Update' : 'Save'}
            </LoadingButton>
          </Stack>
        </Grid>
      </Grid>

      {/* Room Type Form */}
      <RoomTypeForm
        key={`${roomTypeFormMode}`}
        open={!!roomTypeFormMode}
        onSave={handleSaveRoomType}
        hotelData={getValues()}
        onCancel={() => {
          setRoomTypeFormMode(null)
          setEditRoomTypeIndex(null)
        }}
        {...(roomTypeFormMode === 'edit'
          ? {
              isEditMode: true,
              roomData: roomTypeField.fields[editRoomTypeIndex as number],
              indexNumber: editRoomTypeIndex!,
            }
          : { isEditMode: false })}
      />

      {/* Delete Room Type */}
      {deleteRoomTypeIndex !== null && (
        <ConfirmationPopup
          key="deletePopup"
          heading="Delete room type"
          subheading={`Sure to delete "${roomTypeField.fields[deleteRoomTypeIndex].roomSize}" room type?`}
          acceptButtonText="Delete"
          loading={deleteRoomTypeApiState.isLoading}
          onCancel={() => setDeleteRoomTypeIndex(null)}
          onAccept={() => {
            if (isEditMode && roomTypeField.fields[deleteRoomTypeIndex].roomId) {
              deleteRoomType({ hotelId: data.id, roomId: roomTypeField.fields[deleteRoomTypeIndex].roomId })
                .unwrap()
                .then(() => {
                  setDeleteRoomTypeIndex(null)
                  roomTypeField.remove(deleteRoomTypeIndex)
                })
            } else {
              setDeleteRoomTypeIndex(null)
              roomTypeField.remove(deleteRoomTypeIndex)
            }
          }}
        />
      )}
    </RenderContent>
  )
}

import * as yup from 'yup'
import { stringTest } from '@/utils'
import { HotelDTO } from '@/dto'

export const roomTypeSchema = yup.object({
  roomId: yup.number().when('isEditMode', {
    is: true,
    then: (schema) => schema.required(),
  }),
  roomSize: yup.string().required().trim().max(300).test(stringTest),
  packagePrice: yup.number().required().min(0).max(10000000000),
  nightPrice: yup.number().required().min(0).max(10000000000),
  availability: yup.number().required().min(0).max(10000000000),
  minimumOccupancy: yup.number().required().min(1, `"Minimum occupancy" can't be less than 1`).max(10000000000),
  maximumOccupancy: yup.number().required().min(yup.ref('minimumOccupancy'), 'It must be greater than or equal to "Minimum occupancy"').max(10000000000),
  status: yup.string<HotelDTO['roomType'][0]['status']>().required(),
  currencyId: yup.number().required(),
})

export const schema = yup.object({
  isEditMode: yup.boolean().required(),
  name: yup.string().trim().required().max(100).test(stringTest),
  rating: yup.number().required().positive().max(5),
  eventIds: yup.array().of(yup.number().defined()).required(),
  address: yup.string().trim().required().max(300),
  city: yup.string().trim().required().max(100).test(stringTest),
  state: yup.string().trim().required().max(100).test(stringTest),
  countryId: yup.number().required(),
  postalCode: yup.string().required().max(20),
  roomType: yup.array().of(roomTypeSchema).required(),
  // TODO: use it
  // locationLatLong: yup.string().required(),
})

export type TSchema = yup.InferType<typeof schema>
export type TRoomTypeSchema = yup.InferType<typeof roomTypeSchema>

import { HotelDTO } from '@/dto'

export type HotelFormProps =
  | {
      isEditMode: false
      data?: void
    }
  | {
      isEditMode: true
      data: HotelDTO
    }

export type Mode = 'add' | 'edit'

export type useColumnsProps = {
  handleEditRoomType: (index: number) => void
  handleDeleteRoomType: (index: number) => void
}

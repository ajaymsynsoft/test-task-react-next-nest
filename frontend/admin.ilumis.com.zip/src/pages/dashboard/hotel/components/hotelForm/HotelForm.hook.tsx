import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'
import { Chip } from '@mui/material'
import { MdDelete, MdEdit } from 'react-icons/md'

import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import { formatToTitleCase, getStatusColor } from '@/utils'
import { TRoomTypeSchema } from './HotelForm.config'
import { useColumnsProps } from './HotelForm.type'

export const useColumns = (props: useColumnsProps) => {
  const { handleDeleteRoomType, handleEditRoomType } = props

  const columns: GridColDef<TRoomTypeSchema & { serialNumber: number }>[] = [
    { field: 'serialNumber', headerName: 'SN', sortable: false, width: 50, align: 'center', headerAlign: 'center' },
    { field: 'roomSize', headerName: 'Room Size', sortable: false, flex: 1, width: 200 },
    { field: 'availability', headerName: 'Rooms Available', sortable: false, width: 140 },
    { field: 'packagePrice', headerName: 'Package Price', sortable: false, width: 120, renderCell: ({ value }) => <DisplayPrice price={value} /> },
    { field: 'nightPrice', headerName: 'Nightly Price', sortable: false, width: 120, renderCell: ({ value }) => <DisplayPrice price={value} /> },
    { field: 'minimumOccupancy', headerName: 'Min. Occupancy', sortable: false, width: 140 },
    { field: 'maximumOccupancy', headerName: 'Max. Occupancy', sortable: false, width: 140 },
    {
      field: 'status',
      headerName: 'Status',
      sortable: false,
      width: 100,
      renderCell: (params) => {
        return <Chip label={formatToTitleCase(params.value)} variant="outlined" color={getStatusColor(params.value)} />
      },
    },
    {
      field: 'actions',
      headerName: 'Actions',
      sortable: false,
      width: 80,
      align: 'center',
      type: 'actions',
      getActions: ({ row }) => [
        <GridActionsCellItem key="edit" label="Edit" icon={<MdEdit />} onClick={(_) => handleEditRoomType(row.serialNumber - 1)} />,
        <GridActionsCellItem key="delete" label="Delete" icon={<MdDelete />} onClick={(_) => handleDeleteRoomType(row.serialNumber - 1)} />,
      ],
    },
  ]

  return columns
}

import { Controller, useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { FormControl, FormHelperText, Grid, InputLabel, MenuItem, Select, Stack, Dialog, Typography, Divider, Button, InputAdornment, DialogContent } from '@mui/material'

import InputField from '@/components/_ui/inputField/InputField.component'
import { TRoomTypeSchema, roomTypeSchema } from '../../HotelForm.config'
import { RoomTypeFormProps } from './RoomTypeForm.type'
import { useReduxSelector } from '@/hooks'

export default function RoomTypeForm(props: RoomTypeFormProps) {
  const { onCancel, isEditMode, roomData, hotelData, open, onSave, indexNumber } = props
  const organization = useReduxSelector((state) => state.organization)
  const currencyId = organization.displayCurrency.id
  const currencyCode = organization.displayCurrency.code

  const {
    handleSubmit,
    control,
    trigger,
    formState: { isSubmitted },
    setError,
  } = useForm<TRoomTypeSchema>({
    resolver: yupResolver(roomTypeSchema),
    defaultValues: {
      ...(isEditMode ? roomData : { currencyId }),
    },
  })

  const onSubmit = async (formData: TRoomTypeSchema) => {
    if (hotelData.roomType.find((item, index) => item.roomSize.toLowerCase() === formData.roomSize.toLowerCase() && index !== indexNumber)) {
      return setError('roomSize', { type: 'validate', message: `"${formData.roomSize}" room size already used` }, { shouldFocus: true })
    }

    onSave(formData, isEditMode ? 'edit' : 'add')
    onCancel()
  }

  return (
    <Dialog open={open} fullWidth maxWidth="sm" onClose={() => onCancel()}>
      <DialogContent>
        <Stack gap={2}>
          {/* Heading */}
          <Typography variant="h2">Add Room Type</Typography>
          <Divider sx={{ mb: 1 }} />

          <Grid container component="form" noValidate onSubmit={handleSubmit(onSubmit)} spacing={2}>
            {/* Room Size */}
            <Grid item xs={12}>
              <InputField name="roomSize" label="Room size" control={control} helperText="Example: Single, Double" />
            </Grid>

            {/* Availability */}
            <Grid item xs={12} sm={6}>
              <InputField name="availability" label="Rooms available" type="number" control={control} />
            </Grid>

            {/* Status */}
            <Grid item xs={12} sm={6}>
              <Controller
                name="status"
                control={control}
                defaultValue={'' as any}
                render={({ fieldState: { error }, field: { ref, ...restField } }) => (
                  <FormControl error={!!error}>
                    <InputLabel>Room status *</InputLabel>
                    <Select {...restField} inputRef={ref} label="Room status *">
                      <MenuItem value="active">Active</MenuItem>
                      <MenuItem value="inactive">Inactive</MenuItem>
                    </Select>
                    <FormHelperText>{error?.message}</FormHelperText>
                  </FormControl>
                )}
              />
            </Grid>

            {/* Package Price */}
            <Grid item xs={12} sm={6}>
              <InputField
                name="packagePrice"
                label="Package price"
                type="number"
                control={control}
                helperText="Per person"
                InputProps={{
                  endAdornment: <InputAdornment position="end">{currencyCode}</InputAdornment>,
                }}
              />
            </Grid>

            {/* Nightly Price */}
            <Grid item xs={12} sm={6}>
              <InputField
                name="nightPrice"
                label="Nightly price"
                type="number"
                control={control}
                helperText="Per person"
                InputProps={{
                  endAdornment: <InputAdornment position="end">{currencyCode}</InputAdornment>,
                }}
              />
            </Grid>

            {/* Minimum Occupancy */}
            <Grid item xs={12} sm={6}>
              <InputField
                name="minimumOccupancy"
                label="Minimum occupancy"
                type="number"
                control={control}
                onChange={(event, field, value) => {
                  field.onChange(value)
                  isSubmitted && trigger('maximumOccupancy')
                }}
              />
            </Grid>

            {/* Maximum Occupancy */}
            <Grid item xs={12} sm={6}>
              <InputField name="maximumOccupancy" label="Maximum occupancy" type="number" control={control} />
            </Grid>

            {/* Footer */}
            <Grid item xs={12}>
              <Stack direction="row" justifyContent="end" gap={1}>
                <Button variant="text" onClick={onCancel}>
                  Cancel
                </Button>
                <Button variant="contained" type="submit">
                  {isEditMode ? 'Update' : 'Add'}
                </Button>
              </Stack>
            </Grid>
          </Grid>
        </Stack>
      </DialogContent>
    </Dialog>
  )
}

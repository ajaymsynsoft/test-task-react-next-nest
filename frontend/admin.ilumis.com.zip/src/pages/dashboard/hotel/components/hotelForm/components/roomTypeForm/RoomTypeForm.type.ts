import { TRoomTypeSchema, TSchema } from '../../HotelForm.config'
import { Mode } from '../../HotelForm.type'

export type RoomTypeFormProps = {
  open: boolean
  onCancel: () => void
  onSave: (data: TRoomTypeSchema, mode: Mode) => void
  hotelData: TSchema
} & (
  | {
      isEditMode: false
      roomData?: void
      indexNumber?: void
    }
  | {
      isEditMode: true
      roomData: TRoomTypeSchema
      indexNumber: number
    }
)

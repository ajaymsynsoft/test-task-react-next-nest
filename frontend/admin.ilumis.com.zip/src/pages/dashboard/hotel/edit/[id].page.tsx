import { useRouter } from 'next/router'
import { Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import HotelForm from '../components/hotelForm/HotelForm.component'
import { Page } from '@/types'
import { useGetHotelQuery } from '@/redux/api/hotel.api'

const EditHotel: Page = () => {
  const router = useRouter()
  const { isLoading, isError, data, isSuccess } = useGetHotelQuery(Number(router.query.id))

  return (
    <>
      <PageHeader heading="Edit Hotel" backUrl="/dashboard/hotel" />

      <Container>
        <RenderContent loading={isLoading} error={isError}>
          {isSuccess && <HotelForm data={data} isEditMode />}
        </RenderContent>
      </Container>
    </>
  )
}

EditHotel.rootLayoutProps = {
  title: 'Edit Hotel',
  pageType: 'protected',
  module: {
    id: 4,
    permission: 'edit',
  },
}

export default EditHotel

import { Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import HotelForm from '../components/hotelForm/HotelForm.component'
import { Page } from '@/types'

const AddHotel: Page = () => {
  return (
    <>
      <PageHeader heading="Add Hotel" backUrl="/dashboard/hotel" />

      <Container>
        <HotelForm isEditMode={false} />
      </Container>
    </>
  )
}

AddHotel.rootLayoutProps = {
  title: 'Add Hotel',
  pageType: 'protected',
  module: {
    id: 4,
    permission: 'add',
  },
}

export default AddHotel

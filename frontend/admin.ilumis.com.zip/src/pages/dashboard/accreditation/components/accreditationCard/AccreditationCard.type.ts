import { TCardSides } from '@/pages/dashboard/accreditation/Accreditation.type'

export type AccreditationCardProps = {
  template: string
  cardSide: TCardSides
}

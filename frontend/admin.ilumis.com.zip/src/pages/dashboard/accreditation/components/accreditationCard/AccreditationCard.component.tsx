import { memo, useEffect, useRef, useState } from 'react'
import { Box, CircularProgress, Stack, useTheme } from '@mui/material'

import { AccreditationCardProps } from './AccreditationCard.type'
import { useReduxSelector } from '@/hooks'

let scrollTop = 0

function AccreditationCard({ template, cardSide }: AccreditationCardProps) {
  const elRef = useRef<HTMLDivElement>()
  const organization = useReduxSelector((state) => state.organization)
  const [loading, setLoading] = useState(true)
  const theme = useTheme()

  useEffect(() => {
    const accreditationParentEl = elRef.current!.parentElement!

    accreditationParentEl.addEventListener('scroll', (e) => {
      scrollTop = (e.target as HTMLElement)!.scrollTop
    })
  }, [])

  useEffect(() => {
    elRef.current!.innerHTML = ''

    const iframe = document.createElement('iframe')
    elRef.current!.appendChild(iframe)

    const iframeDoc = iframe.contentDocument || iframe.contentWindow!.document

    iframeDoc.open()
    iframeDoc.write(template)
    iframeDoc.close()
    ;(iframeDoc.querySelector(`#${cardSide === 'front' ? 'back' : 'front'}`) as HTMLElement)!.style.display = 'none'
    iframeDoc.body.style.overflow = 'hidden'

    iframeDoc.querySelectorAll('#front, #back').forEach((el) =>
      Object.assign((el as HTMLElement).style, {
        outline: 'unset',
        margin: '0px',
      }),
    )

    const setStyle = () =>
      Object.assign(iframe.style, {
        width: `${iframeDoc.body.scrollWidth + 1}px`,
        height: `${iframeDoc.body.scrollHeight + 1}px`,
        border: `1px solid ${theme.palette.divider}`,
      })

    if (!loading) setStyle()

    iframe.onload = () => {
      setTimeout(() => {
        setStyle()
        setLoading(false)
      }, 350)
    }

    const accreditationParentEl = elRef.current!.parentElement!
    accreditationParentEl.scrollTop = scrollTop
  }, [template, cardSide])

  return (
    <>
      {loading && (
        <Stack justifyContent="center" alignItems="center" m={5}>
          <CircularProgress />
        </Stack>
      )}
      <Box sx={{ m: 'auto', display: 'flex', opacity: loading ? 0 : 1 }} ref={elRef} />
    </>
  )
}

export default memo(AccreditationCard)

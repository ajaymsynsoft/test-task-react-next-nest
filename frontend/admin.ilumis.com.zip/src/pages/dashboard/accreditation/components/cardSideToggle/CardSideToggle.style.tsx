import { Style } from '@/types/Style.type'

export const style: Style = {
  cardSideTabs: {
    mt: 1.25,
    mx: 'auto',
    mb: 1,
    '--padding': '2px',
  },
  cardSideTab: {
    textTransform: 'capitalize',
  },
}

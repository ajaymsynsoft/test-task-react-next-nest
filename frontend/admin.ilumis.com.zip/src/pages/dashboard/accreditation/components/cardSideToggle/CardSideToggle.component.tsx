import { useRouter } from 'next/router'
import { Tab } from '@mui/material'

import { CARD_SIDES } from '@/pages/dashboard/accreditation/Accreditation.config'
import { style } from './CardSideToggle.style'
import { TCardSides } from '../../Accreditation.type'
import { StyledTabs } from '@/components/_styled/styledTabs/StyledTabs.style'
import { useUrlParams } from '@/hooks'

export default function CardSideToggle() {
  const router = useRouter()
  const { setUrlParams } = useUrlParams()

  let cardSide: TCardSides = router.query.cardSide as TCardSides
  if (!CARD_SIDES.includes(cardSide)) cardSide = CARD_SIDES[0]

  const toggleCardSide = () => setUrlParams({ params: { cardSide: cardSide === 'front' ? 'back' : 'front' } })

  return (
    <StyledTabs value={cardSide} sx={style.cardSideTabs} onClick={() => toggleCardSide()}>
      {CARD_SIDES.map((item, index) => (
        <Tab label={item} value={item} key={index} sx={style.cardSideTab} />
      ))}
    </StyledTabs>
  )
}

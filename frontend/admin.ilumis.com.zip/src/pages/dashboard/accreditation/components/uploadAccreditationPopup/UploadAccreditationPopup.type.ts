export type UploadAccreditationPopupProps = {
  onCancel: () => void
}

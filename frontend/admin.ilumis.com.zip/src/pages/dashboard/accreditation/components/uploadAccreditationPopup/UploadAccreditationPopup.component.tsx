import { LoadingButton } from '@mui/lab'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { Dialog, DialogActions, DialogContent, DialogTitle, Grid } from '@mui/material'

import ImageField from '@/components/_ui/imageField/ImageField.component'
import InputField from '@/components/_ui/inputField/InputField.component'
import { UploadAccreditationPopupProps } from './UploadAccreditationPopup.type'
import { useUploadFileMutation } from '@/redux/api/common.api'
import { useReduxSelector } from '@/hooks'
import { schema, TSchema } from './UploadAccreditationPopup.config'
import { useAccreditationRequestMutation } from '@/redux/api/accreditation.api'

export default function UploadAccreditationPopup({ onCancel }: UploadAccreditationPopupProps) {
  const [uploadFile] = useUploadFileMutation()
  const [accreditationRequest] = useAccreditationRequestMutation()

  const {
    handleSubmit,
    control,
    setValue,
    getValues,
    formState: { isSubmitting },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
  })

  const onSubmit = async () => {
    const formData = getValues()

    if (formData.templateImage instanceof File) {
      const [image] = await uploadFile({ files: formData.templateImage, folderName: 'accreditationTemplate' }).unwrap()
      formData.templateImage = image
      setValue('templateImage', image)
    }

    await accreditationRequest({ ...formData, templateImage: formData.templateImage }).unwrap()
    onCancel()
  }

  return (
    <Dialog open fullWidth component="form" maxWidth="md" onClose={() => !isSubmitting && onCancel()} onSubmit={handleSubmit(onSubmit)} {...{ noValidate: true }}>
      <DialogTitle>Upload your own</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2}>
          {/* Image */}
          <Grid item xs={12}>
            <ImageField name="templateImage" control={control} placeholder="accreditation image" />
          </Grid>

          {/* Instructions */}
          <Grid item xs={12}>
            <InputField name="instruction" label="Instructions for designer" control={control} multiline minRows={4} />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <LoadingButton variant="text" disabled={isSubmitting} onClick={onCancel}>
          Cancel
        </LoadingButton>
        <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
          Upload
        </LoadingButton>
      </DialogActions>
    </Dialog>
  )
}

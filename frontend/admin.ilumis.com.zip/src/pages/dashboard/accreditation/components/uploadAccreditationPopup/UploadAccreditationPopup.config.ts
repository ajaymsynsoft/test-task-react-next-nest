import * as yup from 'yup'
import { fileTest, IMAGE_EXTENSIONS } from '@/utils'

export const schema = yup.object({
  templateImage: yup
    .mixed<File | string>()
    .required()
    .test(fileTest({ required: true, size: 5, extensions: IMAGE_EXTENSIONS, message: { extensions: 'Only image file is accepted' } })),
  instruction: yup.string().trim().defined().max(10000, 'Explain under 10,000 characters'),
})

export type TSchema = yup.InferType<typeof schema>

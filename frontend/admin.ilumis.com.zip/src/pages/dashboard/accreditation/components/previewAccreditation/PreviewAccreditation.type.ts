export type PreviewAccreditationProps = {
  onCancel: () => void
  template: string
}

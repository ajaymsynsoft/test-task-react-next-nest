import { MdClose } from 'react-icons/md'
import { Dialog, DialogContent, DialogTitle, IconButton, Stack } from '@mui/material'

import AccreditationCard from '../accreditationCard/AccreditationCard.component'
import { PreviewAccreditationProps } from './PreviewAccreditation.type'

export default function PreviewAccreditation({ template, onCancel }: PreviewAccreditationProps) {
  return (
    <Dialog open fullWidth maxWidth="sm" onClose={() => onCancel()}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" pr={3} gap={3}>
        <DialogTitle>Accreditation preview</DialogTitle>
        <IconButton onClick={onCancel} edge="end">
          <MdClose className="icon-lg" />
        </IconButton>
      </Stack>
      <DialogContent dividers>
        <Stack alignItems="center">
          <AccreditationCard template={template} cardSide="front" />
        </Stack>
      </DialogContent>
    </Dialog>
  )
}

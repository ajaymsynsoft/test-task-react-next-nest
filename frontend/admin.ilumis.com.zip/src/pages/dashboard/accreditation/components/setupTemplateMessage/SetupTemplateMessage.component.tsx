import { useState } from 'react'
import { MdOutlineBadge, MdOutlineSettings } from 'react-icons/md'
import { Box, Button, Card, Typography } from '@mui/material'

import SelectThemePopup from '../selectThemePopup/SelectThemePopup.component'
import { style } from './SetupTemplateMessage.style'

export default function SetupTemplateMessage() {
  const [showSelectTheme, setShowSelectTheme] = useState(false)

  return (
    <>
      <Card variant="outlined" sx={style.root}>
        <Box component={MdOutlineBadge} sx={style.icon} />
        <Typography variant="subtitle">Accreditation template is not setup</Typography>
        <Button variant="contained" startIcon={<MdOutlineSettings />} onClick={() => setShowSelectTheme(true)}>
          Setup Accreditation Template
        </Button>
      </Card>

      {showSelectTheme && <SelectThemePopup onCancel={() => setShowSelectTheme(false)} />}
    </>
  )
}

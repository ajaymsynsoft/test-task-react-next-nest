import { Style } from '@/types/Style.type'

export const style: Style = {
  root: {
    px: 2,
    py: 4,
    gap: 2,
    display: 'flex',
    flexFlow: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    fontSize: '65px !important',
    color: 'text.disabled',
  },
}

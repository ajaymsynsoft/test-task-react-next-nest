import { useState } from 'react'
import { LoadingButton } from '@mui/lab'
import { Dialog, DialogActions, DialogContent, DialogTitle, Grid, Button, ButtonBase } from '@mui/material'

import AccreditationCard from '../accreditationCard/AccreditationCard.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { useReduxSelector } from '@/hooks'
import { SelectThemePopupProps } from './SelectThemePopup.type'
import { useSaveAccreditationTemplateMutation } from '@/redux/api/accreditation.api'
import { useGetAccreditationTemplateListQuery } from '@/redux/api/accreditation.api'
import { applyCardValues } from '../../Accreditation.util'
import { style } from './SelectThemePopup.style'

export default function SelectThemePopup({ onCancel }: SelectThemePopupProps) {
  const organization = useReduxSelector((state) => state.organization)
  const [selectedTemplate, setSelectTemplate] = useState<{ id: number; template: string } | null>(null)
  const [saveAccreditationTemplate, saveAccreditationTemplateApiState] = useSaveAccreditationTemplateMutation()
  const { data, isSuccess, isLoading, isError } = useGetAccreditationTemplateListQuery({ type: 'customer' })

  const handleSubmit = async () => {
    if (!selectedTemplate) return
    await saveAccreditationTemplate({ template: selectedTemplate.template }).unwrap()
    onCancel(true)
  }

  return (
    <Dialog open fullWidth maxWidth="md" onClose={() => onCancel()}>
      <DialogTitle>Select theme</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={3}>
          <RenderContent loading={isLoading} error={isError}>
            {isSuccess &&
              data.map((item, index) => {
                const { template: modifiedTemplate } = applyCardValues({ test: true, template: item.template, organization })

                return (
                  <Grid item xs="auto" key={index}>
                    <ButtonBase className={`${item.id === selectedTemplate?.id ? 'selected' : ''}`} sx={style.cardItem} onClick={() => setSelectTemplate({ ...item })}>
                      <AccreditationCard template={modifiedTemplate} cardSide="front" />
                    </ButtonBase>
                  </Grid>
                )
              })}
          </RenderContent>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button variant="text" onClick={() => onCancel()}>
          Cancel
        </Button>
        <LoadingButton variant="contained" type="submit" disabled={!selectedTemplate} loading={saveAccreditationTemplateApiState.isLoading} onClick={() => handleSubmit()}>
          Select theme
        </LoadingButton>
      </DialogActions>
    </Dialog>
  )
}

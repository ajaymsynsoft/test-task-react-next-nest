import { Style } from '@/types'

export const style: Style = {
  cardItem: {
    borderRadius: 1,
    '&.selected': {
      outline: 2,
      outlineColor: 'primary.main',
      outlineOffset: 2,
    },
    iframe: {
      pointerEvents: 'none',
      borderRadius: 1,
    },
  },
}

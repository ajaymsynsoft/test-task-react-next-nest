export type SelectThemePopupProps = {
  onCancel: (isSubmitted?: boolean) => void
}

import { Style } from '@/types'

export const style: Style = {
  downloadBtn: {
    p: 0,
    minWidth: 'auto',
    width: 30,
    height: 30,
    color: 'action.active',
    borderRadius: '100%',
    ':hover': {
      bgcolor: (theme) => `${theme.palette.action.hover} !important`,
    },
  },
}

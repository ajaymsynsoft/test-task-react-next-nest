import { TCardSides } from './Accreditation.type'

export const CARD_SIDES: TCardSides[] = ['front', 'back']

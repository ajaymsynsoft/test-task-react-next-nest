import moment from 'moment'
import Link from 'next/link'
import { useState } from 'react'
import { GridColDef, GridActionsCellItem } from '@mui/x-data-grid'
import { LoadingButton } from '@mui/lab'
import { Chip, Typography, Link as MuiLink, Stack, Tooltip } from '@mui/material'
import { MdCheck, MdClose, MdRemoveRedEye, MdDownload } from 'react-icons/md'

import GuestInfoCard from '@/components/_card/guestInfoCard/GuestInfoCard.compoent'
import PreviewAccreditation from './components/previewAccreditation/PreviewAccreditation.component'
import { formatToTitleCase, getStatusColor } from '@/utils'
import { EventDTO } from '@/dto'
import { TGuest } from '@/types/Guest.type'
import { useReduxSelector } from '@/hooks'
import { applyCardValues } from './Accreditation.util'
import { style } from './Accreditation.style'
import { useGenerateAccreditationPdfMutation } from '@/redux/api/accreditation.api'

export const useColumns = (template: string) => {
  type TRow = { guest: TGuest; event: EventDTO }
  type TFileDownloadStatus = 'Downloading' | 'Downloaded' | 'Failed'

  const organization = useReduxSelector((state) => state.organization)
  const { downloadAccreditation } = useDownloadAccreditation(template)
  const { modules } = useReduxSelector((state) => state.layout.profile)

  const [fileDownloadStatus, setFileDownloadStatus] = useState<Record<number, TFileDownloadStatus>>({})
  const [showAccreditationPreview, setShowAccreditationPreview] = useState<number | null>(null)
  const [modifiedTemplate, setModifiedTemplate] = useState<string>('')

  const handlePreviewAccreditation = async ({ event, guest }: TRow) => {
    const data = applyCardValues({ template, organization, guest, event })
    setModifiedTemplate(data.template)
    setShowAccreditationPreview(guest.id)
  }

  const downloadSingelAccreditation = async ({ event, guest }: TRow) => {
    try {
      setFileDownloadStatus((items) => ({ ...items, [guest.id]: 'Downloading' }))
      await downloadAccreditation([{ event, guest }])
      setFileDownloadStatus((items) => ({ ...items, [guest.id]: 'Downloaded' }))
    } catch (error) {
      setFileDownloadStatus((items) => ({ ...items, [guest.id]: 'Failed' }))
    }
  }

  const columns: GridColDef<TRow>[] = [
    { field: 'guestId', headerName: 'Guest ID', sortable: false, width: 85, minWidth: 85, renderCell: ({ row }) => `#${row.guest.id}` },
    {
      field: 'guest',
      headerName: 'Guest',
      sortable: false,
      flex: 1,
      minWidth: 250,
      renderCell: ({ row }) => <GuestInfoCard data={row.guest} />,
    },
    {
      field: 'event',
      headerName: 'Event',
      sortable: false,
      flex: 1,
      minWidth: 170,
      renderCell: ({ row }) => (
        <Typography noWrap width={1} title={row.event.name}>
          {row.event.name}
        </Typography>
      ),
    },
    {
      field: 'orderId',
      headerName: 'Booking ID',
      sortable: false,
      minWidth: 100,
      display: 'flex',
      renderCell: ({ row }) =>
        modules[12].permissions.edit ? (
          <MuiLink component={Link} href={`/dashboard/bookings/edit/${row.guest.orderId}`} target="_blank">
            #{row.guest.orderId}
          </MuiLink>
        ) : (
          <Typography>#{row.guest.orderId}</Typography>
        ),
    },
    {
      field: 'guestStatus',
      headerName: 'Guest Status',
      sortable: false,
      minWidth: 145,
      renderCell: ({ row }) => {
        return <Chip label={formatToTitleCase(row.guest.status)} variant="outlined" color={getStatusColor(row.guest.status)} />
      },
    },
    {
      field: 'visaStatus',
      headerName: 'Visa Status',
      sortable: false,
      minWidth: 110,
      renderCell: ({ row }) => {
        return <Chip label={formatToTitleCase(row.guest.visaStatus)} variant="outlined" color={getStatusColor(row.guest.visaStatus)} />
      },
    },
    {
      field: 'download',
      headerName: 'Actions',
      sortable: false,
      minWidth: 110,
      renderCell: ({ row }) => {
        const { icon, loading, disabled } = (() => {
          switch (fileDownloadStatus[row.guest.id]) {
            case 'Downloading':
              return { icon: <MdDownload />, loading: true, disabled: false }
            case 'Downloaded':
              return { icon: <MdCheck />, loading: false, disabled: true }
            case 'Failed':
              return { icon: <MdClose />, loading: false, disabled: false }
            default:
              return { icon: <MdDownload />, loading: false, disabled: false }
          }
        })()

        const actions = [
          <Tooltip title="Preview Accreditation" key="view">
            <GridActionsCellItem label="View" icon={<MdRemoveRedEye />} onClick={() => handlePreviewAccreditation(row)} />
          </Tooltip>,
          <Tooltip title="Download Accreditation" key="download">
            <LoadingButton variant="text" disabled={disabled} loading={loading} onClick={() => downloadSingelAccreditation(row)} sx={style.downloadBtn}>
              {icon}
            </LoadingButton>
          </Tooltip>,
        ]

        if (showAccreditationPreview === row.guest.id && modifiedTemplate) actions.push(<PreviewAccreditation key="preview" template={modifiedTemplate} onCancel={() => setShowAccreditationPreview(null)} />)

        return (
          <Stack direction="row" gap={1}>
            {actions}
          </Stack>
        )
      },
    },
  ]

  return columns
}

export const useDownloadAccreditation = (template: string) => {
  const [generateAccreditationPdf, generateAccreditationPdfApiState] = useGenerateAccreditationPdfMutation()
  const organization = useReduxSelector((state) => state.organization)

  const downloadAccreditation = async (list: { event: EventDTO; guest: TGuest }[]) => {
    let width: string = '',
      height: string = ''

    const modifiedTemplates = list.map(({ guest, event }) => {
      const { template: modifiedTemplate, cardSettings } = applyCardValues({ template, organization, guest, event })

      width = `${cardSettings.size.width}${cardSettings.size.unit.value}`
      height = `${cardSettings.size.height}${cardSettings.size.unit.value}`

      return { html: modifiedTemplate, fileName: `#${guest.id} - ${guest.passportFirstName} ${guest.passportLastName}` }
    })

    await generateAccreditationPdf({ templates: modifiedTemplates, width, height })
      .unwrap()
      .then((blob) => {
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = modifiedTemplates.length > 1 ? `${modifiedTemplates.length} Guest Accreditation - ${moment().format()}` : `#${list[0].guest.id} - ${list[0].guest.passportFirstName} ${list[0].guest.passportLastName}`
        document.body.appendChild(a)
        a.click()
        a.remove()
      })
  }

  return { downloadAccreditation, downloadAccreditationApiState: generateAccreditationPdfApiState }
}

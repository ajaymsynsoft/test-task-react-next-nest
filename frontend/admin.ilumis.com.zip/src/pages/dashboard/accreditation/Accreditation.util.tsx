import QRCode from 'qrcode'
import { ApplyCardValuesParams, ModifyCardTemplateParams, TCardElement, TCardSettings } from './Accreditation.type'
import { attrDoubleQuoteToSingle } from '@/utils'

export const extractCardElementsData = (template: string) => {
  const parser = new DOMParser()
  const doc = parser.parseFromString(template, 'text/html')

  const cardElementsData: TCardElement[] = []
  const cardSettings = JSON.parse(doc.querySelector('script#settings')!.textContent as string) as TCardSettings

  doc.querySelectorAll('[data-info]').forEach((item) => {
    item.closest('#front, #back') &&
      cardElementsData.push({
        ...JSON.parse(item.getAttribute('data-info') as string),
        cardSide: item.closest('#front') ? 'front' : 'back',
      })
  })

  return { cardElementsData, cardSettings }
}

export const modifyCardTemplate = (params: ModifyCardTemplateParams) => {
  let { template, cardElementsData, cardSettings } = params

  const parser = new DOMParser()
  const doc = parser.parseFromString(template, 'text/html')

  doc.querySelectorAll('[data-info]').forEach((el) => {
    const elementData: TCardElement = JSON.parse(attrDoubleQuoteToSingle(el.getAttribute('data-info')!))
    el.setAttribute('data-id', elementData.id)
  })

  cardElementsData.forEach((item) => {
    doc.querySelectorAll(`[data-id="${item.id}"]`).forEach((el) => {
      const value = item.type === 'image' && (item.value as any) instanceof File ? URL.createObjectURL(item.value as any) : item.value
      el.setAttribute('data-info', JSON.stringify({ ...item, value }))
    })
  })

  doc.querySelector('script#settings')!.innerHTML = JSON.stringify(cardSettings)

  return doc.documentElement.outerHTML
}

export const applyCardValues = (params: ApplyCardValuesParams) => {
  let { template, organization, test, guest, event } = params
  const { cardSettings, cardElementsData } = extractCardElementsData(template)
  const defaultValues = cardSettings.defaultVariablesValue

  let qrCode: string = ''
  QRCode.toDataURL(test ? location.origin : `${location.origin}/dashboard/bookings/edit/${guest?.orderId}?tab=guests&selectedGuest=${guest!.id}`, { margin: 0 }, (err, url) => (qrCode = url))

  const DYNAMIC_VARIABLES: Record<string, string> = {
    organizationName: organization.organizationName,
    organizationLogo: organization.logo,
    photo:
      (test ? defaultValues.photo : guest?.photo) ||
      `https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEipAiWGfdmBmW4yjqmc8sFscgSMftVrrh6XLPGtzF0BrXyI_ZsjjUGI3G94fvAwOcQKG1GLE73BLnIv6UvyaGZAB3rrYIOpLQBha_zi35zErspGmnhGtdzYsM6E26bOZFMn1T-Ol1_LMICfmQV9SPmg0aXm_fbzQx-brN53UfsC7uwe1UfNEfOFYMeq1yE/s0/Profile_avatar_placeholder_large.jpg`,
    fullName: test ? defaultValues.fullName || `Abdullah Ali` : `${guest!.passportFirstName} ${guest!.passportLastName}`,
    role: test ? defaultValues.role || `Athlete` : guest!.role,
    country: test ? defaultValues.country || `Bahrain` : guest?.nationality || `n/a`,
    guestId: test ? defaultValues.guestId || `#001` : `#${guest!.id}`,
    qrCode: `${qrCode} `,
    accessibilities: test
      ? defaultValues.accessibilities.replaceAll(`'`, '&quot;') ||
        `<img src=&quot;https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgHFGI-MjqNU6_6eWn5Jz-xQUfMD5uxYkdN00etc9asaGFCqikfeht_lbFXlk3dg4Aij-b5-vOgW9wUUdSZrkHMKBEIU15OP4n3blPQEgh8b9BH5_dKj2GgQUoOZz_csPiaF8l6ggnj9VDVqKDOKM99na_Xfz9pXwe3I-4rtyrn9ht8CzAqoyr4vsTT43I/s0/accessible_24dp_000000%20(1).png&quot;/><img src=&quot;https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiAAKfYksf3MHhXBXin2mtCNEHJ0Y-ER2abnObdqG-DRDXoHHAWopIz2Cfdpo6DC4U9PkTGrGdyWGGln8AU2H8CB1SCzZgKEp9P6aTJ0NGL5yGJODFZFmIaMUpHb75IB4-rzRYVL2-jYPgsEELc9udfqPt51lkGPyX8IZfNVEetEziG-yV2J_CYo2HcKlo/s0/wheelchair_pickup_24dp_000000.png&quot;/>`
      : guest?.accessibilityInfoData.map((item) => `<img src='${item.imageURL}'/>`).join('') || '',
    code: test
      ? defaultValues.code.replaceAll(`'`, '&quot;') || `<div>SHO</div><div class=&quot;active&quot;>OLV</div><div>IBC</div><div>IBC</div>`
      : event!.roleWiseData.map((item) => `<div class=&quot;${guest!.role === item.role ? 'active' : ''}&quot;>${item.code}</div>`).join(''),
    // 'category': test ? (defaultValues.category || "Aa") : "Ba",
  }

  Object.keys(DYNAMIC_VARIABLES).forEach((key) => (template = template.replaceAll(`{{${key}}}`, DYNAMIC_VARIABLES[key])))

  return { template, cardSettings, cardElementsData }
}

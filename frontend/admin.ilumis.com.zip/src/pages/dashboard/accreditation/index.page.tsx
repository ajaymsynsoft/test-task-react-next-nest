import Link from 'next/link'
import { useCallback, useState } from 'react'
import { useRouter } from 'next/router'
import { LuSearch } from 'react-icons/lu'
import { MdOutlineEdit, MdOutlineFileDownload } from 'react-icons/md'
import { DataGrid, GridRowSelectionModel } from '@mui/x-data-grid'
import { LoadingButton } from '@mui/lab'
import { Autocomplete, Button, Container, Grid, debounce, InputAdornment, TextField, Stack } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import SetupTemplateMessage from './components/setupTemplateMessage/SetupTemplateMessage.component'
import { Page } from '@/types'
import { usePagination, useReduxSelector, useUrlParams } from '@/hooks'
import { useGetGuestListQuery } from '@/redux/api/guest.api'
import { useColumns, useDownloadAccreditation } from './Accreditation.hook'
import { useGetEventNameListQuery } from '@/redux/api/event.api'
import { TGuest } from '@/types/Guest.type'
import { formatToTitleCase } from '@/utils'
import { useGetAccreditationTemplateQuery } from '@/redux/api/accreditation.api'

const Accreditation: Page = () => {
  const router = useRouter()
  const [rowSelectionModel, setRowSelectionModel] = useState<GridRowSelectionModel>([])
  const { paginationModel, setPaginationModel, page, pageSize } = usePagination()
  const { modules } = useReduxSelector((state) => state.layout.profile)
  const { setUrlParams } = useUrlParams()

  const filter = {
    eventId: router.query.eventId as any,
    searchText: router.query.searchText as string,
    status: router.query.status as string,
    visaStatus: router.query.visaStatus as string,
  }

  const accreditationTemplateApiState = useGetAccreditationTemplateQuery()
  const eventListApiState = useGetEventNameListQuery()
  const { downloadAccreditation, downloadAccreditationApiState } = useDownloadAccreditation(accreditationTemplateApiState.data!)
  const { data, isFetching, isError, isLoading } = useGetGuestListQuery({ pageNo: page, pageSize, ...filter })

  const columns = useColumns(accreditationTemplateApiState.data!)
  const loading = isLoading || accreditationTemplateApiState.isLoading
  const isAccreditationSetup: null | boolean = accreditationTemplateApiState.isSuccess ? !!accreditationTemplateApiState.data : null

  const searchDebounce = useCallback(debounce(setUrlParams, 500), [JSON.stringify(filter)])

  const downloadBulkAccreditation = async () => {
    const tempalteData = rowSelectionModel.map((selectedItem) => data!.list.find((item) => item.guest.id === selectedItem)!)
    await downloadAccreditation(tempalteData)
    setRowSelectionModel([])
  }

  return (
    <>
      {/* Page Header */}
      <PageHeader
        heading="Accreditation"
        count={data?.totalCount}
        actions={
          modules[6].permissions.edit &&
          isAccreditationSetup &&
          !loading && (
            <Button LinkComponent={Link} startIcon={<MdOutlineEdit />} variant="contained" href="/dashboard/accreditation/edit-template">
              Edit Template
            </Button>
          )
        }
      />

      <Container>
        <RenderContent loading={loading} error={isError || accreditationTemplateApiState.isError}>
          {isAccreditationSetup !== false ? (
            <>
              {/* Filters */}
              <Stack direction="row" alignItems="center" mb={3} minHeight={54}>
                {rowSelectionModel.length ? (
                  <LoadingButton variant="outlined" startIcon={<MdOutlineFileDownload />} loading={downloadAccreditationApiState.isLoading} onClick={downloadBulkAccreditation}>
                    Download
                  </LoadingButton>
                ) : (
                  <Grid container spacing={2}>
                    {/* Search Guest */}
                    <Grid item xs={12} sm={6} md={3}>
                      <TextField
                        placeholder="Search guest..."
                        defaultValue={filter.searchText}
                        onChange={(e) => searchDebounce({ params: { searchText: e.target.value } })}
                        sx={{ '.MuiInputBase-root': { bgcolor: 'white' } }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <LuSearch />
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Grid>

                    {/* Select Event */}
                    <Grid item xs={12} sm={6} md={3}>
                      <Autocomplete
                        noOptionsText="No events"
                        disableClearable={false}
                        loading={eventListApiState.isLoading}
                        options={eventListApiState.data || []}
                        value={eventListApiState.data?.find((item) => item.id === Number(filter.eventId)) || null}
                        getOptionLabel={(option) => option.name}
                        onChange={(_, value) => setUrlParams({ params: { eventId: value?.id } })}
                        renderInput={(params) => <TextField {...params} label="Event" />}
                      />
                    </Grid>

                    {/* Status */}
                    <Grid item xs={12} sm={6} md={3}>
                      <Autocomplete
                        noOptionsText="No status"
                        disableClearable={false}
                        value={filter.status || null}
                        getOptionLabel={(option) => formatToTitleCase(option)}
                        options={['profileCompleted', 'profileIncomplete'] satisfies TGuest['status'][]}
                        onChange={(_, value) => setUrlParams({ params: { status: value || '' } })}
                        renderInput={(params) => <TextField {...params} label="Guest status" />}
                      />
                    </Grid>

                    {/* Visa Status */}
                    <Grid item xs={12} sm={6} md={3}>
                      <Autocomplete
                        noOptionsText="No status"
                        disableClearable={false}
                        value={filter.visaStatus || null}
                        getOptionLabel={(option) => formatToTitleCase(option)}
                        options={['issued', 'notApplied', 'pending'] satisfies TGuest['visaStatus'][]}
                        onChange={(_, value) => setUrlParams({ params: { visaStatus: value || '' } })}
                        renderInput={(params) => <TextField {...params} label="Visa status" />}
                      />
                    </Grid>
                  </Grid>
                )}
              </Stack>

              {/* Table */}
              <DataGrid
                loading={isFetching}
                columns={columns}
                rowCount={data?.totalCount || 0}
                rows={data?.list.map((item) => ({ ...item, id: item.guest.id })) || []}
                getRowHeight={() => 'auto'}
                paginationModel={paginationModel}
                onPaginationModelChange={setPaginationModel}
                checkboxSelection
                onRowSelectionModelChange={(newRowSelectionModel) => setRowSelectionModel(newRowSelectionModel)}
                rowSelectionModel={rowSelectionModel}
              />
            </>
          ) : (
            <SetupTemplateMessage />
          )}
        </RenderContent>
      </Container>
    </>
  )
}

Accreditation.rootLayoutProps = {
  title: 'Accreditation',
  pageType: 'protected',
  module: {
    id: 10,
    permission: 'view',
  },
}

export default Accreditation

import Link from 'next/link'
import { useRef, useState } from 'react'
import { useRouter } from 'next/router'
import { MdOutlineDesignServices, MdOutlineFileUpload, MdInfoOutline } from 'react-icons/md'
import { Button, ButtonGroup, useMediaQuery, Theme, Stack } from '@mui/material'
import { LoadingButton } from '@mui/lab'

import FullPageMessage from '@/components/fullPageMessage/FullPageMessage.component'
import PageHeader from '@/components/pageHeader/PageHeader.component'
import AccreditationForm from './components/accreditationForm/AccreditationForm.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import UploadAccreditation from '../components/uploadAccreditationPopup/UploadAccreditationPopup.component'
import SelectThemePopup from '../components/selectThemePopup/SelectThemePopup.component'
import { Page } from '@/types'
import { CARD_SIDES } from '@/pages/dashboard/accreditation/Accreditation.config'
import { TCardSides, TAccreditationFormRef } from '@/pages/dashboard/accreditation/Accreditation.type'
import { useGetAccreditationTemplateQuery } from '@/redux/api/accreditation.api'

const EditAccreditation: Page = () => {
  const router = useRouter()
  const accreditationFormRef = useRef<TAccreditationFormRef>(null)
  const isLgUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('lg'))
  const [savingTemplate, setSavingTemplate] = useState<boolean>(false)
  const [showUploadAccreditation, setShowUploadAccreditation] = useState(false)
  const [showChangeTheme, setShowChangeTheme] = useState(false)

  const { data: template, isError, isLoading, isSuccess, isFetching } = useGetAccreditationTemplateQuery()

  const [isThemeChanged, setIsThemeChanged] = useState(false)
  if (!isFetching && isThemeChanged) setIsThemeChanged(false)

  const loading = isLoading || (isThemeChanged && isFetching)

  let cardSide: TCardSides = router.query.cardSide as TCardSides
  if (!CARD_SIDES.includes(cardSide)) cardSide = CARD_SIDES[0]

  const handleSaveTemplate = async () => {
    setSavingTemplate(true)
    await accreditationFormRef.current?.saveTemplate()
    setSavingTemplate(false)
  }

  return (
    <>
      {/* Page Header */}
      <PageHeader
        heading="Edit Template"
        backUrl="/dashboard/accreditation"
        sx={{ mt: '0 !important', mb: loading ? undefined : '0 !important', borderColor: 'var(--border-color)' }}
        actions={
          isLgUp && (
            <>
              <ButtonGroup variant="outlined">
                <Button startIcon={<MdOutlineDesignServices />} onClick={() => setShowChangeTheme(true)}>
                  Change theme
                </Button>
                <Button startIcon={<MdOutlineFileUpload />} onClick={() => setShowUploadAccreditation(true)}>
                  Upload your own
                </Button>
              </ButtonGroup>
              <LoadingButton variant="contained" loading={savingTemplate} onClick={handleSaveTemplate}>
                Save
              </LoadingButton>
            </>
          )
        }
      />

      {isLgUp ? (
        <>
          {/* Upload Accreditation */}
          {showUploadAccreditation && <UploadAccreditation onCancel={() => setShowUploadAccreditation(false)} />}

          {/* Change Theme */}
          {showChangeTheme && (
            <SelectThemePopup
              onCancel={(isSubmitted) => {
                setShowChangeTheme(false)
                if (isSubmitted) setIsThemeChanged(true)
              }}
            />
          )}

          {/* Accreditation Form */}
          <RenderContent error={isError} loading={loading}>
            {isSuccess && <AccreditationForm template={template} cardSide={cardSide} ref={accreditationFormRef} />}
          </RenderContent>
        </>
      ) : (
        <FullPageMessage
          icon={<Stack component={MdInfoOutline} color="warning.main" />}
          heading="Please use desktop for editing"
          centerContent={false}
          ActionButton={
            <Button variant="contained" href="/dashboard/accreditation" component={Link}>
              Go Back
            </Button>
          }
        />
      )}

      {/* Global Style */}
      <style jsx global>{`
        main {
          margin-bottom: 0 !important;
        }
        body {
          overflow: hidden;
        }
      `}</style>
    </>
  )
}

EditAccreditation.rootLayoutProps = {
  title: 'Edit Accreditation Template',
  pageType: 'protected',
  module: {
    id: 10,
    permission: 'edit',
  },
}

export default EditAccreditation

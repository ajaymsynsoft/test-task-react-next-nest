import { Style } from '@/types/Style.type'
import { HEADER_HEIGHT } from '@/layouts/rootLayout/RootLayout.config'

export const style: Style = {
  root: {
    '--height': `calc(100vh - ${HEADER_HEIGHT}px)`,
    display: 'flex',
    overflow: 'hidden',
  },
  leftSidebar: {
    width: 300,
    flexShrink: 0,
    p: 2,
    gap: 1,
    overflow: 'auto',
    height: 'var(--height)',
  },
  rightSidebar: {
    width: 300,
    flexShrink: 0,
    py: 2,
    gap: 3.5,
    overflow: 'auto',
    height: 'var(--height)',
    '& > *:not(.MuiDivider-root)': {
      px: 2,
    },
  },
  body: {
    border: 1,
    borderColor: 'divider',
    borderWidth: '0 1px',
    flex: 1,
    height: 'var(--height)',
    bgcolor: 'background.bg1',
    overflow: 'auto',
    position: 'relative',
    display: 'flex',
    flexFlow: 'column',
    padding: 1.5,
    pt: 0,
  },
  accordian: {
    border: 1,
    borderColor: 'divider',
    borderRadius: 1,
  },
  accordianSummary: {
    justifyContent: 'space-between',
    py: 1.5,
    px: 1.5,
    borderRadius: 1,
    textAlign: 'left',
    '.icon': {
      color: 'text.disabled',
    },
  },
  accordianList: {},
  accordianListItem: {
    justifyContent: 'start',
    textAlign: 'left',
    ':hover': {
      bgcolor: 'action.hover',
    },
  },
  heading: {
    display: 'flex',
    gap: 1.5,
    alignItems: 'center',
    color: 'text.secondary',
    '.icon': {
      opacity: 0.5,
    },
  },
}

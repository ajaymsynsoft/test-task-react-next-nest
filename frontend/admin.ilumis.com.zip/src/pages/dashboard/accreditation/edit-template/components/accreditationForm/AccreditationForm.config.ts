import * as yup from 'yup'
import { TCardElement, TCardSettings, TCardSides } from '@/pages/dashboard/accreditation/Accreditation.type'

export const cardElementsDataSchema: yup.ObjectSchema<TCardElement> = yup.object({
  id: yup.string().required(),
  component: yup.string().required(),
  label: yup.string().required(),
  type: yup.string<TCardElement['type']>().required(),
  enable: yup.boolean().required(),
  value: yup
    .string()
    .defined()
    .when('enable', {
      is: true,
      then: (schema) => schema.required(),
      otherwise: (schema) => schema.notRequired(),
    }),
  cardSide: yup.string<TCardSides>().required(),
})

export const cardSettingsSchema: yup.ObjectSchema<TCardSettings> = yup.object({
  size: yup.object({
    width: yup.number().required().positive(),
    height: yup.number().required().positive(),
    unit: yup.object({
      value: yup.string().required(),
      label: yup.string().required(),
    }),
  }),
  defaultVariablesValue: yup.object<any>({}),
  version: yup.number().required(),
})

export const schema = yup.object({
  cardSettings: cardSettingsSchema,
  cardElementsData: yup.array().of(cardElementsDataSchema).required(),
})

export type TSchema = yup.InferType<typeof schema>

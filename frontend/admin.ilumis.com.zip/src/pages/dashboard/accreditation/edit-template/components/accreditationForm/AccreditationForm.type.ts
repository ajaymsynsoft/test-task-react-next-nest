import { TCardSides } from '@/pages/dashboard/accreditation/Accreditation.type'

export type AccreditationFormProps = {
  template: string
  cardSide: TCardSides
}

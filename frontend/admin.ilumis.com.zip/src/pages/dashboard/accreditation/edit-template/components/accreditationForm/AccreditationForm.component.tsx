import toast from 'react-hot-toast'
import { useRouter } from 'next/router'
import { forwardRef, memo, useImperativeHandle } from 'react'
import { yupResolver } from '@hookform/resolvers/yup'
import { Controller, useFieldArray, useForm } from 'react-hook-form'
import { MdExpandMore, MdOutlineSettings } from 'react-icons/md'
import { RxComponent1 } from 'react-icons/rx'
import { Alert, Box, ButtonBase, Checkbox, Collapse, Fade, Stack, TextField, Tooltip, Typography } from '@mui/material'

import AccreditationCard from '../../../components/accreditationCard/AccreditationCard.component'
import InputField from '@/components/_ui/inputField/InputField.component'
import ImageField from '@/components/_ui/imageField/ImageField.component'
import CardSideToggle from '../../../components/cardSideToggle/CardSideToggle.component'
import { style } from './AccreditationForm.style'
import { AccreditationFormProps } from './AccreditationForm.type'
import { schema, TSchema } from './AccreditationForm.config'
import { extractCardElementsData, modifyCardTemplate } from '@/pages/dashboard/accreditation/Accreditation.util'
import { TAccreditationFormRef } from '@/pages/dashboard/accreditation/Accreditation.type'
import { useSaveAccreditationTemplateMutation } from '@/redux/api/accreditation.api'
import { useUploadFileMutation } from '@/redux/api/common.api'
import { useUrlParams } from '@/hooks'

const AccreditationForm = forwardRef<TAccreditationFormRef, AccreditationFormProps>((props, ref) => {
  const { template, cardSide } = props
  const router = useRouter()
  const { setUrlParams } = useUrlParams()

  const [saveAccreditationTemplate] = useSaveAccreditationTemplateMutation()
  const [uploadFile] = useUploadFileMutation()

  const {
    watch,
    getValues,
    setValue,
    control,
    formState: { isValid },
  } = useForm<TSchema>({
    mode: 'onChange',
    resolver: yupResolver(schema),
    defaultValues: (() => {
      const { cardElementsData, cardSettings } = extractCardElementsData(template)

      return {
        cardSettings,
        cardElementsData,
      }
    })(),
  })

  const cardElementsDataFields = useFieldArray({ name: 'cardElementsData', control })
  const componentNames = [
    ...new Set(
      getValues('cardElementsData')
        .filter((item) => item.cardSide === cardSide)
        .map((item) => item.component),
    ),
  ]
  const getModifiedCardTemplate = () => modifyCardTemplate({ template, cardElementsData: watch('cardElementsData'), cardSettings: watch('cardSettings') })

  let componentAccordian = router.query.componentAccordian as string
  if (!componentNames.includes(componentAccordian)) componentAccordian = componentNames[1] || componentNames[0]

  const toggleComponentAccordian = (value: string) => {
    setUrlParams({ params: { componentAccordian: value } })
  }

  useImperativeHandle(
    ref,
    (): any => ({
      async saveTemplate() {
        if (!isValid) return toast.error('Please check all fields. Some form entries are invalid.')

        for (const [index, item] of getValues('cardElementsData').entries()) {
          if (item.type === 'image' && (item.value as any) instanceof File) {
            const [image] = await uploadFile({ files: item.value as any, folderName: 'assets' }).unwrap()
            setValue(`cardElementsData.${index}.value`, image)
          }
        }

        await saveAccreditationTemplate({ template: getModifiedCardTemplate() })
      },
    }),
    [isValid],
  )

  return (
    <>
      <Box sx={style.root}>
        {/* Left Sidebar */}
        <Stack sx={style.leftSidebar}>
          {componentNames.map((component, componentIndex) => (
            <Stack sx={style.accordian} key={componentIndex}>
              <ButtonBase sx={style.accordianSummary} onClick={() => toggleComponentAccordian(component)}>
                <Typography variant="subtitle" color="text.disabled">
                  {component}
                </Typography>
                <MdExpandMore />
              </ButtonBase>
              <Collapse in={componentAccordian === component}>
                <Stack sx={style.accordianList}>
                  {cardElementsDataFields.fields.map(
                    (item, index) =>
                      item.component === component &&
                      item.cardSide === cardSide && (
                        <Controller
                          name={`cardElementsData.${index}.enable`}
                          control={control}
                          key={item.id}
                          render={({ field: { onChange, value } }) => (
                            <ButtonBase component="label" sx={style.accordianListItem}>
                              <Checkbox size="small" disableRipple checked={value} onChange={onChange} />
                              <Typography>{item.label}</Typography>
                            </ButtonBase>
                          )}
                        />
                      ),
                  )}
                </Stack>
              </Collapse>
            </Stack>
          ))}
        </Stack>

        {/* Body */}
        <Box sx={style.body}>
          <CardSideToggle />
          <AccreditationCard template={getModifiedCardTemplate()} cardSide={cardSide} />
        </Box>

        {/* Right Sidebar */}
        <Stack sx={style.rightSidebar} key={componentAccordian}>
          {/* Settings */}
          <Stack gap={2}>
            <Typography variant="subtitle" sx={style.heading}>
              <MdOutlineSettings /> Settings
            </Typography>

            {/* Size */}
            <Stack direction="row" gap={2}>
              <InputField name="cardSettings.size.width" label="Width" type="number" control={control} InputProps={{ endAdornment: <Typography color="text.disabled">{watch('cardSettings.size.unit.label')}</Typography> }} />
              <InputField name="cardSettings.size.height" label="Height" type="number" control={control} InputProps={{ endAdornment: <Typography color="text.disabled">{watch('cardSettings.size.unit.label')}</Typography> }} />
            </Stack>
          </Stack>

          {/* Component Elements Fields */}
          {componentNames.map(
            (component, componentIndex) =>
              componentAccordian === component && (
                <Fade in timeout={300} key={componentIndex}>
                  <Stack gap={2}>
                    <Typography variant="subtitle" sx={style.heading}>
                      <RxComponent1 /> {component}
                    </Typography>
                    {!watch('cardElementsData').find((item) => item.component === component && item.enable) ? (
                      <Fade in timeout={300}>
                        <Alert variant="outlined" severity="info">
                          No any element enable.
                        </Alert>
                      </Fade>
                    ) : (
                      cardElementsDataFields.fields.map(
                        (item, index) =>
                          item.component === component &&
                          item.cardSide === cardSide &&
                          watch(`cardElementsData.${index}.enable`) && (
                            <Fade in key={item.id}>
                              <Stack>
                                {!item.value.trim().startsWith('{{') ? (
                                  <>
                                    {['text', 'number'].includes(item.type) && (
                                      <InputField name={`cardElementsData.${index}.value`} type={item.type} multiline={item.type == 'text'} maxRows={5} label={item.label} control={control} />
                                    )}
                                    {item.type === 'image' && (
                                      <Box mt={-0.5}>
                                        <ImageField name={`cardElementsData.${index}.value`} label={item.label} control={control} />
                                      </Box>
                                    )}
                                  </>
                                ) : (
                                  <Tooltip title="Dynamic Value" arrow placement="top" disableInteractive>
                                    <TextField value={item.value} label={item.label} disabled />
                                  </Tooltip>
                                )}
                              </Stack>
                            </Fade>
                          ),
                      )
                    )}
                  </Stack>
                </Fade>
              ),
          )}
        </Stack>
      </Box>
    </>
  )
})

AccreditationForm.displayName = 'AccreditationForm'
export default memo(AccreditationForm)

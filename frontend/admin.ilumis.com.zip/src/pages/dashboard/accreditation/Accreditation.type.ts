import { EventDTO, OrganizationDTO } from '@/dto'
import { TGuest } from '@/types/Guest.type'

export type TCardSides = 'front' | 'back'

export type TCardSettings = {
  size: {
    width: number
    height: number
    unit: {
      value: string
      label: string
    }
  }
  defaultVariablesValue: Record<string, string>
  version: number
}

export type TCardElement = {
  id: string
  component: string
  label: string
  type: 'text' | 'image' | 'number'
  value: string | ''
  enable: boolean
  cardSide: TCardSides
}

export type ApplyCardValuesParams = {
  template: string
  organization: Pick<OrganizationDTO, 'logo' | 'organizationName'>
} & ({ test?: void; guest: TGuest; event: EventDTO } | { test: true; guest?: void; event?: void })

export type ModifyCardTemplateParams = {
  template: string
  cardElementsData: TCardElement[]
  cardSettings: TCardSettings
}

export type TAccreditationFormRef = {
  saveTemplate: () => Promise<void>
}

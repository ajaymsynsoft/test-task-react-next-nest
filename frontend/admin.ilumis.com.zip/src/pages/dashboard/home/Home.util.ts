import { NextRouter } from 'next/router'

export const handleUrlQueryParams = ({ key, value, router }: { key: string; value?: string | number; router: NextRouter }) => {
  const query = { ...router.query } as Record<string, string | number>
  if (value) query[key] = value
  else delete query[key]
  if (key === 'year' || key === 'month') delete query['date']

  router.replace({ query }, undefined, { shallow: true })
}

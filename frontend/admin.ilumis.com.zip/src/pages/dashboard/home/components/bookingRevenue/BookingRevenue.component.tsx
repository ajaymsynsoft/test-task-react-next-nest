import { useRouter } from 'next/router'
import { FormControl, Grid, MenuItem, Select, Stack, Typography } from '@mui/material'

import BookingRevenueGraph from './components/bookingRevenueGraph/BookingRevenueGraph.component'
import { handleUrlQueryParams } from '../../Home.util'
import { style } from './BookingRevenue.style'

export default function BookingRevenue() {
  const router = useRouter()
  const CURRENT_YEAR = new Date().getFullYear()
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

  const selectedYear = (router.query.year as string) || CURRENT_YEAR
  const selectedMonth = (router.query.month as string) || ''

  return (
    <Stack gap={2.5}>
      <Stack sx={style.header}>
        {/* Headings */}
        <Typography variant="h3">Revenue</Typography>

        <Stack sx={style.filterContainer}>
          {/* Years Filter */}
          <Select value={selectedYear} size="small" onChange={(e) => handleUrlQueryParams({ key: 'year', value: e.target.value, router })}>
            {Array(5)
              .fill('')
              .map((item, index) => {
                const year = CURRENT_YEAR - index
                return (
                  <MenuItem value={year} key={index}>
                    {year}
                  </MenuItem>
                )
              })}
          </Select>

          {/* Months Filter */}
          <FormControl fullWidth={false}>
            <Select value={selectedMonth} size="small" displayEmpty onChange={(e) => handleUrlQueryParams({ key: 'month', value: e.target.value, router })}>
              <MenuItem value="" sx={{ color: 'text.disabled' }}>
                Month
              </MenuItem>
              {MONTHS.map((item, index) => (
                <MenuItem value={index + 1} key={index}>
                  {item}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Stack>
      </Stack>

      {/* Graph*/}
      <BookingRevenueGraph />
    </Stack>
  )
}

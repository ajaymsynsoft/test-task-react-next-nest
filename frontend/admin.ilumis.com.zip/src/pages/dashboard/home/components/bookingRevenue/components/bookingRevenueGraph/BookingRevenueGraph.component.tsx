import { useRouter } from 'next/router'
import { Skeleton, Stack, useTheme, Card } from '@mui/material'
import { BarChart } from '@mui/x-charts'

import RenderContent from '@/components/renderContent/RenderContent.component'
import { useGetSuperadminRevenueBarGraphQuery } from '@/redux/api/report.api'

export default function BookingRevenueGraph() {
  const router = useRouter()
  const theme = useTheme()

  const { data, isFetching, isError } = useGetSuperadminRevenueBarGraphQuery({
    organizationId: router.query.organizationId as string,
    month: router.query.month as string,
    year: (router.query.year as string) || new Date().getFullYear(),
  })

  return (
    <Card component={Stack} height={500}>
      <RenderContent loading={false} error={isError}>
        {!isFetching ? (
          <BarChart
            borderRadius={6}
            dataset={data}
            xAxis={[{ scaleType: 'band', dataKey: 'label', tickPlacement: 'middle' }]}
            series={[{ dataKey: 'value', label: 'Revenue', color: theme.palette.success.light }]}
            slotProps={{
              legend: {
                hidden: true,
              },
            }}
            margin={{
              left: 95,
            }}
          />
        ) : (
          <Stack width={1} height={1} p={2}>
            <Skeleton variant="rounded" width="100%" height="100%" />
          </Stack>
        )}
      </RenderContent>
    </Card>
  )
}

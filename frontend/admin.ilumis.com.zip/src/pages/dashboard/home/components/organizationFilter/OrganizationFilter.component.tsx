import { Autocomplete, TextField } from '@mui/material'
import { useRouter } from 'next/router'

import { useGetOrganizationListQuery } from '@/redux/api/organization.api'
import { handleUrlQueryParams } from '../../Home.util'

export default function OrganizationFilter() {
  const router = useRouter()
  const { data, isLoading } = useGetOrganizationListQuery({ pageNo: 1, pageSize: 1000 })

  return (
    <Autocomplete
      fullWidth
      disablePortal={false}
      noOptionsText="No organizations"
      size="small"
      loading={isLoading}
      disableClearable={false}
      options={data?.list || []}
      value={data?.list.find((item) => item.id === Number(router.query.organizationId)) || null}
      getOptionLabel={(option) => option.organizationName}
      onChange={(_, value) => handleUrlQueryParams({ key: 'organizationId', value: value?.id, router })}
      renderInput={(params) => <TextField {...params} placeholder="Select Organization" />}
      sx={{
        minWidth: 250,
        '.MuiOutlinedInput-root': { py: '8px !important' },
      }}
    />
  )
}

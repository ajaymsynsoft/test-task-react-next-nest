import { Autocomplete, TextField } from '@mui/material'
import { useRouter } from 'next/router'

import { useGetEventNameListQuery } from '@/redux/api/event.api'
import { handleUrlQueryParams } from '../../Home.util'

export default function EventFilter() {
  const router = useRouter()
  const { data, isLoading } = useGetEventNameListQuery()

  return (
    <Autocomplete
      fullWidth
      disablePortal={false}
      size="small"
      noOptionsText="No events"
      loading={isLoading}
      disableClearable={false}
      options={data || []}
      value={data?.find((item) => item.id === Number(router.query.eventId)) || null}
      getOptionLabel={(option) => option.name}
      onChange={(_, value) => handleUrlQueryParams({ key: 'eventId', value: value?.id, router })}
      renderInput={(params) => <TextField {...params} placeholder="Select event" />}
      sx={{
        minWidth: 250,
        '.MuiOutlinedInput-root': { py: '8px !important' },
      }}
    />
  )
}

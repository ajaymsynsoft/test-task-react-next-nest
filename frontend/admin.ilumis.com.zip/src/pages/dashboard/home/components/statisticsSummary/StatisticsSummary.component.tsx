import { Grid } from '@mui/material'
import { useRouter } from 'next/router'

import StatisticsCard from './components/statisticsCard/StatisticsCard.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { useReduxSelector } from '@/hooks'
import { ADMIN_SUMMARY, SUPERADMIN_SUMMARY } from './StatisticsSummary.config'
import { StatisticsSummaryProps } from './StatisticsSummary.type'
import { useGetAdminStatisticsSummaryQuery, useGetSuperadminStatisticsSummaryQuery } from '@/redux/api/report.api'

export default function StatisticsSummary(props: StatisticsSummaryProps) {
  const router = useRouter()
  const { role } = useReduxSelector((state) => state.layout.profile)
  const adminStatisticsSummaryApiState = useGetAdminStatisticsSummaryQuery({ eventId: router.query.eventId as string }, { skip: role === 'superAdmin' })
  const superadminStatisticsSummaryApiState = useGetSuperadminStatisticsSummaryQuery({ organizationId: router.query.organizationId as string }, { skip: role !== 'superAdmin' })

  const apiState = role === 'superAdmin' ? superadminStatisticsSummaryApiState : adminStatisticsSummaryApiState

  return (
    <RenderContent loading={false} error={apiState.isError}>
      <Grid container spacing={2.5}>
        {(role === 'superAdmin' ? SUPERADMIN_SUMMARY : ADMIN_SUMMARY).map((item, index) => (
          <Grid item xs key={index}>
            <StatisticsCard
              data={item}
              // @ts-ignore
              count={apiState.isSuccess ? apiState.data[item.key] : 0}
              updating={apiState.isFetching}
            />
          </Grid>
        ))}
      </Grid>
    </RenderContent>
  )
}

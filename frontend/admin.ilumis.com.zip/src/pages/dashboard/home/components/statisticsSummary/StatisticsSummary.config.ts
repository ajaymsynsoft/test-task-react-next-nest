import { MdCheck, MdCorporateFare, MdDoneAll, MdOutlineBorderAll, MdOutlineConfirmationNumber, MdOutlineEventAvailable, MdOutlineFlag, MdSchedule } from 'react-icons/md'
import { TbMoneybag, TbUsersGroup } from 'react-icons/tb'
import { LuUsers } from 'react-icons/lu'

import { TStatisticsSummary } from './StatisticsSummary.type'
import { TAdminStatisticsSummary, TSuperAdminPaymentSummary, TSuperAdminStatisticsSummary } from '@/redux/api/report.api'

export const ADMIN_SUMMARY: TStatisticsSummary<TAdminStatisticsSummary>[] = [
  { label: 'Bookings', key: 'totalBookings', Icon: MdOutlineEventAvailable },
  // { label: 'Revenue', key: 'totalRevenue', Icon: TbMoneybag, isPrice: true },
  { label: 'Countries', key: 'totalCountries', Icon: MdOutlineFlag },
  { label: 'Registrations', key: 'totalRegistrations', Icon: LuUsers },
  { label: 'Guests', key: 'totalGuests', Icon: TbUsersGroup },
]

export const SUPERADMIN_SUMMARY: TStatisticsSummary<TSuperAdminStatisticsSummary>[] = [
  { label: 'Customers', key: 'totalCustomers', Icon: LuUsers },
  { label: 'Events', key: 'totalEvents', Icon: MdOutlineConfirmationNumber },
  { label: 'Organizations', key: 'totalOrganizations', Icon: MdCorporateFare },
  { label: 'Revenue', key: 'totalRevenue', Icon: TbMoneybag, isPrice: true },
]

export const ADMIN_PAYMENT_SUMMARY: TStatisticsSummary<TSuperAdminPaymentSummary>[] = [
  { label: 'All Bookings', key: 'all', Icon: MdOutlineEventAvailable, isPrice: true },
  { label: 'Completed', key: 'completed', Icon: MdCheck, isPrice: true },
  { label: 'Pending', key: 'pending', Icon: MdSchedule, isPrice: true },
]

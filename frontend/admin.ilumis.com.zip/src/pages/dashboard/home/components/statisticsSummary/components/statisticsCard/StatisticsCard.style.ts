import { Style } from '@/types/Style.type'

export const style: Style = {
  root: {
    height: 1,
  },
  cardContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: 1.5,
  },
  count: {
    lineHeight: 1,
    color: 'text.secondary',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 1.5,
    '.icon': {
      color: 'text.disabled',
    },
  },
  iconBox: {},
  currencyCode: {
    typography: 'body1',
    color: 'text.disabled',
    ml: 0.5,
  },
}

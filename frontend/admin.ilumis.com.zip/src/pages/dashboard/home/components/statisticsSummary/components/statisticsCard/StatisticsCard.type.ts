import { TStatisticsSummary } from '../../StatisticsSummary.type'

export type StatisticsCardProps = {
  data: TStatisticsSummary<any>
  updating: boolean
  count?: number
  children?: React.ReactNode
}

import { IconType } from 'react-icons'

export type StatisticsSummaryProps = {}

export type TStatisticsSummary<T> = {
  label: string
  Icon: IconType
  key: keyof T
  isPrice?: boolean
}

import { Box, Skeleton, Stack, Typography, Card, CardContent, useTheme } from '@mui/material'

import { StatisticsCardProps } from './StatisticsCard.type'
import { useReduxSelector } from '@/hooks'
import { style } from './StatisticsCard.style'
import { formatNumber } from '@/utils'

export default function StatisticsCard({ data, updating, count, children }: StatisticsCardProps) {
  const theme = useTheme()
  const { displayCurrency } = useReduxSelector((state) => state.organization)
  const { role } = useReduxSelector((state) => state.layout.profile)

  return (
    <Card sx={style.root}>
      <CardContent sx={style.cardContent}>
        {/* Header */}
        <Stack sx={style.header}>
          <Typography flex={1} fontWeight={500}>
            {updating ? <Skeleton variant="text" /> : data.label}
          </Typography>
          {updating ? <Skeleton variant="rounded" width={24} height={24} /> : <data.Icon className="icon-xl" color={theme.palette.primary.light} />}
        </Stack>

        {/* Count */}
        <Typography variant="display1" sx={style.count}>
          {updating ? (
            <Skeleton variant="text" />
          ) : (
            <>
              {formatNumber(count!)}
              {data.isPrice && (
                <Box component="span" sx={style.currencyCode}>
                  {role === 'superAdmin' ? 'USD' : displayCurrency?.code}
                </Box>
              )}
            </>
          )}
        </Typography>

        {/* Children */}
        {children}
      </CardContent>
    </Card>
  )
}

import { useRouter } from 'next/router'
import { FormControl, Grid, MenuItem, Select, Stack, Typography } from '@mui/material'

import BookingStatusChart from './components/bookingStatusChart/BookingStatusChart.component'
import BookingCountChart from './components/bookingCountChart/BookingCountChart.component'
import { handleUrlQueryParams } from '../../Home.util'
import { style } from './BookingStatistics.style'

export default function BookingStatistics() {
  const router = useRouter()
  const CURRENT_YEAR = new Date().getFullYear()
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

  const selectedYear = (router.query.year as string) || CURRENT_YEAR
  const selectedMonth = (router.query.month as string) || ''

  return (
    <Stack gap={2.5}>
      <Stack sx={style.header}>
        {/* Headings */}
        <Typography variant="h2">Bookings</Typography>

        <Stack sx={style.filterContainer}>
          {/* Years Filter */}
          <Select value={selectedYear} size="small" onChange={(e) => handleUrlQueryParams({ key: 'year', value: e.target.value, router })}>
            {Array(5)
              .fill('')
              .map((item, index) => {
                const year = CURRENT_YEAR - index
                return (
                  <MenuItem value={year} key={index}>
                    {year}
                  </MenuItem>
                )
              })}
          </Select>

          {/* Months Filter */}
          <FormControl fullWidth={false}>
            <Select value={selectedMonth} size="small" displayEmpty onChange={(e) => handleUrlQueryParams({ key: 'month', value: e.target.value, router })}>
              <MenuItem value="" sx={{ color: 'text.disabled' }}>
                Month
              </MenuItem>
              {MONTHS.map((item, index) => (
                <MenuItem value={index + 1} key={index}>
                  {item}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Stack>
      </Stack>

      {/* Graphs */}
      <Grid container spacing={2.5} sx={style.graphGrid}>
        <Grid item xs={12} md={5}>
          <BookingStatusChart />
        </Grid>
        <Grid item xs={12} md={7}>
          <BookingCountChart />
        </Grid>
      </Grid>
    </Stack>
  )
}

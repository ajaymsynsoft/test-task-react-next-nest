import { useRouter } from 'next/router'
import { PieChart } from '@mui/x-charts'
import { Skeleton, Stack, useTheme, Card } from '@mui/material'

import RenderContent from '@/components/renderContent/RenderContent.component'
import { useGetAdminBookingPieChartQuery } from '@/redux/api/report.api'
import { formatNumber, formatToTitleCase, getStatusColor } from '@/utils'

export default function BookingStatusChart() {
  const theme = useTheme()
  const router = useRouter()

  const { data, isFetching, isError } = useGetAdminBookingPieChartQuery({
    eventId: router.query.eventId as string,
    month: router.query.month as string,
    year: (router.query.year as string) || new Date().getFullYear(),
  })

  const isBooking = data && data.find((item) => item.total)

  const colors = data?.map((item) => {
    const colorKey = getStatusColor(item.status)
    if (colorKey === 'default') return theme.palette.grey['300']
    // @ts-ignore
    return theme.palette?.[getStatusColor(item.status)]?.light
  })

  return (
    <Card component={Stack} justifyContent="center">
      <RenderContent loading={false} error={isError}>
        {!isFetching ? (
          <PieChart
            colors={colors || []}
            loading={isFetching}
            height={200}
            series={[
              {
                data: isBooking
                  ? data!.map((item, index) => ({
                      id: index,
                      label: `${formatToTitleCase(item.status)} - ${formatNumber(item.total)}`,
                      value: item.total,
                    }))
                  : [],
                innerRadius: 60,
                paddingAngle: 5,
                cornerRadius: 5,
              },
            ]}
            slots={{
              noDataOverlay: () => {
                return (
                  <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" fill={theme.palette.text.secondary}>
                    No data to display
                  </text>
                )
              },
            }}
            slotProps={{
              popper: {
                sx: {
                  '.MuiChartsTooltip-labelCell': { pr: 2 },
                  '.MuiChartsTooltip-valueCell': { display: 'none' },
                },
              },
            }}
          />
        ) : (
          <Stack width={1} height={1} p={2}>
            <Skeleton variant="rounded" width="100%" height="100%" />
          </Stack>
        )}
      </RenderContent>
    </Card>
  )
}

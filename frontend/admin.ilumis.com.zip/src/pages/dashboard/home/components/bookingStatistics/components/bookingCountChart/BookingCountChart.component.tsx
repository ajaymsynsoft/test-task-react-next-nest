import { useRouter } from 'next/router'
import { BarChart } from '@mui/x-charts'
import { Skeleton, Stack, useTheme, Card } from '@mui/material'

import RenderContent from '@/components/renderContent/RenderContent.component'
import { useGetAdminBookingBarGraphQuery } from '@/redux/api/report.api'

export default function BookingCountChart() {
  const router = useRouter()
  const theme = useTheme()

  const { data, isFetching, isError } = useGetAdminBookingBarGraphQuery({
    eventId: router.query.eventId as string,
    month: router.query.month as string,
    year: (router.query.year as string) || new Date().getFullYear(),
  })

  return (
    <Card component={Stack} justifyContent="center">
      <RenderContent loading={false} error={isError}>
        {!isFetching ? (
          <BarChart
            loading={isFetching}
            borderRadius={6}
            dataset={data}
            xAxis={[{ scaleType: 'band', dataKey: 'label', tickPlacement: 'middle' }]}
            series={[{ dataKey: 'value', label: 'Bookings', color: theme.palette.success.light }]}
            slotProps={{
              legend: {
                hidden: true,
              },
            }}
          />
        ) : (
          <Stack width={1} height={1} p={2}>
            <Skeleton variant="rounded" width="100%" height="100%" />
          </Stack>
        )}
      </RenderContent>
    </Card>
  )
}

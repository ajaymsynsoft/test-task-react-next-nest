import { Style } from '@/types/Style.type'

export const style: Style = {
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  filterContainer: {
    flexDirection: 'row',
    gap: 1,
    ml: 'auto',
  },
}

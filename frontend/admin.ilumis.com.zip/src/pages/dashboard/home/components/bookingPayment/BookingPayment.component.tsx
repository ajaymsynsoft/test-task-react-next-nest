import moment from 'moment'
import { useRouter } from 'next/router'
import { DatePicker } from '@mui/x-date-pickers'
import { Grid, Skeleton, Stack, Typography } from '@mui/material'

import SummaryCard from '../statisticsSummary/components/statisticsCard/StatisticsCard.component'
import { style } from './BookingStatistics.style'
import { useGetAdminPaymentSummaryQuery } from '@/redux/api/report.api'
import { ADMIN_PAYMENT_SUMMARY } from '../statisticsSummary/StatisticsSummary.config'
import { handleUrlQueryParams } from '../../Home.util'
import { validateDate } from '@/utils'

export default function BookingPayment() {
  const router = useRouter()
  const selectedDate = (router.query.date as string) || ''

  const adminPaymentSummaryApiState = useGetAdminPaymentSummaryQuery({
    eventId: router.query.eventId as string,
    month: router.query.month as string,
    date: router.query.date as string,
    year: (router.query.year as string) || new Date().getFullYear(),
  })

  return (
    <Stack gap={2.5}>
      <Stack sx={style.header}>
        {/* Headings */}
        <Typography variant="h2">Payment</Typography>

        <Stack sx={style.filterContainer}>
          {/* Date Filter */}
          <DatePicker
            value={selectedDate ? moment(selectedDate) : null}
            onChange={(value) => handleUrlQueryParams({ key: 'date', value: validateDate(value) ? value?.toISOString() : undefined, router })}
            slotProps={{
              textField: { size: 'small', placeholder: 'Date' },
              popper: { disablePortal: true },
            }}
          />
        </Stack>
      </Stack>

      <Grid container spacing={2.5}>
        {ADMIN_PAYMENT_SUMMARY.map((item, index) => {
          const itemData = adminPaymentSummaryApiState.isSuccess ? adminPaymentSummaryApiState.data[item.key] : undefined

          return (
            <Grid item xs={12} sm={4} key={index}>
              <SummaryCard data={item} count={itemData?.totalAmount} updating={adminPaymentSummaryApiState.isFetching}>
                <Typography textAlign="end">{adminPaymentSummaryApiState.isFetching ? <Skeleton variant="text" /> : <>{itemData?.totalOrders} Bookings</>}</Typography>
              </SummaryCard>
            </Grid>
          )
        })}
      </Grid>
    </Stack>
  )
}

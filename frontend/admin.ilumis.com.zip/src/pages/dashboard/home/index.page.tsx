import { Container, Stack } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import EventFilter from './components/eventFilter/EventFilter.component'
import StatisticsSummary from './components/statisticsSummary/StatisticsSummary.component'
import BookingStatistics from './components/bookingStatistics/BookingStatistics.component'
import BookingRevenue from './components/bookingRevenue/BookingRevenue.component'
import OrganizationFilter from './components/organizationFilter/OrganizationFilter.component'
import BookingPayment from './components/bookingPayment/BookingPayment.component'
import { useReduxSelector } from '@/hooks'
import { Page } from '@/types/Page.type'

const Dashboard: Page = () => {
  const { role } = useReduxSelector((state) => state.layout.profile)

  return (
    <>
      <PageHeader heading="Dashboard" actions={role === 'superAdmin' ? <OrganizationFilter /> : <EventFilter />} />

      <Stack component={Container} gap={5}>
        <StatisticsSummary />
        {role !== 'superAdmin' && <BookingStatistics />}
        {role !== 'superAdmin' && <BookingPayment />}
        {role === 'superAdmin' && <BookingRevenue />}
      </Stack>
    </>
  )
}

Dashboard.rootLayoutProps = {
  pageType: 'protected',
  title: 'Dashboard',
  module: {
    id: 6,
    permission: 'view',
  },
}

export default Dashboard

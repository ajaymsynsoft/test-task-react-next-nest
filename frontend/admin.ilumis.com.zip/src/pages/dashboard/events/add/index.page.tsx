import toast from 'react-hot-toast'
import Link from 'next/link'
import { useRouter } from 'next/router'
import { Alert, Button, Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import EventForm from '../components/eventForm/EventForm.component'
import { Page } from '@/types'
import { useReduxSelector } from '@/hooks'
import { useGetEventsListQuery } from '@/redux/api/event.api'

const AddEvent: Page = () => {
  const router = useRouter()
  const organization = useReduxSelector((state) => state.organization)
  const { plan } = useReduxSelector((state) => state.subscription)
  const { data, isLoading, isError, isSuccess } = useGetEventsListQuery({ pageNo: 1, pageSize: 10 })

  if (isSuccess && data?.totalRecords >= plan.noOfEvents) {
    toast.error(`You can create upto ${plan.noOfEvents} event or upgrade your subscription plan`, {
      duration: 6000,
      position: 'top-center',
    })
    router.replace('/dashboard/events')
    return null
  }

  return (
    <>
      <PageHeader heading="Create Event" backUrl="/dashboard/events" />

      <Container>
        {organization.defaultCurrency && organization.defaultCurrency && organization.displayCurrencyRate ? (
          <EventForm isEditMode={false} />
        ) : (
          <Alert
            severity="info"
            action={
              <Button color="inherit" size="small" href="/dashboard/settings" component={Link}>
                Setup Currency
              </Button>
            }
          >
            Setup currency before creating event.
          </Alert>
        )}
      </Container>
    </>
  )
}

AddEvent.rootLayoutProps = {
  title: 'Add Event',
  pageType: 'protected',
  module: {
    id: 3,
    permission: 'add',
  },
}

export default AddEvent

import { useRouter } from 'next/router'
import { Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import EventForm from '../components/eventForm/EventForm.component'
import { Page } from '@/types'
import { useGetEventQuery } from '@/redux/api/event.api'

const EditEvent: Page = () => {
  const router = useRouter()
  const { isFetching, isError, data } = useGetEventQuery({ eventId: Number(router.query.id) })

  return (
    <>
      <PageHeader heading="Edit Event" backUrl="/dashboard/events" />

      <Container>
        <RenderContent loading={isFetching} error={isError}>
          {data && <EventForm data={data} isEditMode />}
        </RenderContent>
      </Container>
    </>
  )
}

EditEvent.rootLayoutProps = {
  title: 'Edit Event',
  pageType: 'protected',
  module: {
    id: 3,
    permission: 'edit',
  },
}

export default EditEvent

import moment from 'moment'
import Image from 'next/image'
import Link from 'next/link'
import { Chip, Stack, Link as MuiLink } from '@mui/material'
import { useState } from 'react'
import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'
import { MdDelete, MdEdit } from 'react-icons/md'
import { useRouter } from 'next/router'

import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import { EventDTO } from '@/dto'
import { useDeleteEventMutation } from '@/redux/api/event.api'
import { formatToTitleCase, getStatusColor } from '@/utils'
import { useReduxSelector } from '@/hooks'

export const useColumns = () => {
  const router = useRouter()
  const [deleteItemId, setDeleteItemId] = useState<number | null>(null)
  const [deleteEvent, { isLoading }] = useDeleteEventMutation()
  const { modules } = useReduxSelector((state) => state.layout.profile)

  const columns: GridColDef<EventDTO>[] = [
    {
      field: 'id',
      headerName: 'ID',
      sortable: false,
      minWidth: 85,
      width: 85,
      renderCell: (row) => (
        <MuiLink component={Link} href={`/dashboard/events/edit/${row.value}`}>
          #{row.value}
        </MuiLink>
      ),
    },
    {
      field: 'name',
      headerName: 'Event',
      sortable: false,
      flex: 1,
      minWidth: 150,
    },
    {
      field: 'bannerImage',
      headerName: 'Banner',
      sortable: false,
      minWidth: 180,
      renderCell: ({ row }) => (
        <Stack sx={{ img: { borderRadius: 1, border: 1, borderColor: 'divider' } }}>
          <Image src={row.bannerImage} alt="banner" width={160} height={82} style={{ maxHeight: 100 }} />
        </Stack>
      ),
    },
    {
      field: 'address',
      headerName: 'Address',
      sortable: false,
      flex: 1,
      minWidth: 150,
      renderCell: ({ row }) => `${row.address}, ${row.city}, ${row.state}, ${row?.country}`,
    },
    {
      field: 'startDate',
      headerName: 'Start Date',
      sortable: false,
      minWidth: 125,
      renderCell: (params) => moment(params.row.startDate).format(),
    },
    {
      field: 'endDate',
      headerName: 'End Date',
      sortable: false,
      minWidth: 125,
      renderCell: (params) => moment(params.row.endDate).format(),
    },
    {
      field: 'status',
      headerName: 'Status',
      sortable: false,
      minWidth: 100,
      renderCell: (params) => {
        return <Chip label={formatToTitleCase(params.value)} variant="outlined" color={getStatusColor(params.value)} />
      },
    },
    {
      field: 'actions',
      headerName: 'Actions',
      sortable: false,
      minWidth: 80,
      width: 80,
      align: 'center',
      type: 'actions',
      getActions: (params) => {
        const actions = []

        if (modules[3].permissions.edit) actions.push(<GridActionsCellItem showInMenu key="edit" label="Edit" icon={<MdEdit />} onClick={(_) => router.push(`/dashboard/events/edit/${params.id}`)} />)

        if (modules[3].permissions.delete)
          actions.push(
            <GridActionsCellItem showInMenu key="delete" label="Delete" icon={<MdDelete />} onClick={(_) => setDeleteItemId(params.row.id)} />,
            <ConfirmationPopup
              key="deletePopup"
              heading="Delete event"
              subheading={`Sure to delete "${params.row.name}" event?`}
              acceptButtonText="Delete"
              loading={isLoading}
              open={params.id === deleteItemId}
              onCancel={() => setDeleteItemId(null)}
              onAccept={() =>
                deleteEvent(params.row.id)
                  .unwrap()
                  .then(() => setDeleteItemId(null))
              }
            />,
          )

        return actions
      },
    },
  ]

  return columns
}

import Link from 'next/link'
import { useCallback } from 'react'
import { useRouter } from 'next/router'
import { MdAdd } from 'react-icons/md'
import { LuSearch } from 'react-icons/lu'
import { DataGrid } from '@mui/x-data-grid'
import { Button, Container, debounce, InputAdornment, TextField, Grid } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { useColumns } from './Events.hook'
import { usePagination, useReduxSelector, useUrlParams } from '@/hooks'
import { useGetEventsListQuery } from '@/redux/api/event.api'

const Events: Page = () => {
  const columns = useColumns()
  const router = useRouter()
  const { modules } = useReduxSelector((state) => state.layout.profile)
  const { paginationModel, setPaginationModel, page, pageSize } = usePagination()
  const { setUrlParams } = useUrlParams()

  const filter = {
    searchText: router.query.searchText as string,
  }

  const { data, isFetching, isError, isLoading } = useGetEventsListQuery({ pageNo: page, pageSize, ...filter })

  const searchDebounce = useCallback(debounce(setUrlParams, 500), [JSON.stringify(filter)])

  return (
    <>
      <PageHeader
        heading="Events"
        count={data?.totalCount}
        actions={
          <>
            {modules[3].permissions.add && (
              <Button startIcon={<MdAdd />} LinkComponent={Link} variant="contained" href="/dashboard/events/add">
                Create Event
              </Button>
            )}
          </>
        }
      />

      <Container>
        {/* Filter */}
        <Grid container mb={3} spacing={2}>
          {/* Search Guest */}
          <Grid item xs={12} sm={4}>
            <TextField
              placeholder="Search"
              defaultValue={filter.searchText}
              onChange={(e) => searchDebounce({ params: { searchText: e.target.value } })}
              sx={{ '.MuiInputBase-root': { bgcolor: 'white' } }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LuSearch />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
        </Grid>

        {/* Table */}
        <RenderContent loading={isLoading} error={isError}>
          <DataGrid loading={isFetching} columns={columns} rowCount={data?.totalCount || 0} rows={data?.list || []} getRowHeight={() => 'auto'} paginationModel={paginationModel} onPaginationModelChange={setPaginationModel} />
        </RenderContent>
      </Container>
    </>
  )
}

Events.rootLayoutProps = {
  title: 'Events',
  pageType: 'protected',
  module: {
    id: 3,
    permission: 'view',
  },
}

export default Events

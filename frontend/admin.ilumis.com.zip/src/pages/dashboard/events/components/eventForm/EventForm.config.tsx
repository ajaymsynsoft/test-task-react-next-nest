import * as yup from 'yup'
import moment from 'moment'
import { fileTest, IMAGE_EXTENSIONS, stringTest, textEditorRequiredTest } from '@/utils'
import { EventDTO } from '@/dto'
import { PaymentMethods } from '@/types'

export const schema = yup.object({
  name: yup.string().trim().required().max(300).test(stringTest),
  status: yup.string<EventDTO['status']>().required(),
  bannerImage: yup
    .mixed<File | string>()
    .required()
    .test(fileTest({ required: true, size: 10, extensions: IMAGE_EXTENSIONS, message: { extensions: 'Only image file is accepted' } })),
  description: yup.string().trim().required().max(10000, 'Explain under 10,000 characters').test(textEditorRequiredTest),
  address: yup.string().trim().required().max(300),
  city: yup.string().trim().required().max(100).test(stringTest),
  state: yup.string().trim().required().max(100).test(stringTest),
  countryId: yup.number().required(),
  timeZoneId: yup.number().required(),
  startDate: yup.string().required(),
  endDate: yup
    .string()
    .required()
    .test('validate', 'It must be greater than "Start date and time"', function (endDate) {
      const startDate = this.parent.startDate
      if (startDate && endDate) return moment(endDate).isAfter(startDate)
      return true
    }),
  roleWiseData: yup
    .array()
    .of(
      yup.object({
        role: yup.string().trim().max(100).test(stringTest).required(),
        price: yup.number().min(0).max(10000000000).required(),
        code: yup.string().trim().max(100),
        access: yup.array().of(yup.string().max(100).defined()).max(100),
        currencyId: yup.number().required(),
      }),
    )
    .required()
    .min(1),
  paymentProviderId: yup.number().nullable(),
  paymentMethodSupported: yup
    .array()
    .of(
      yup.object({
        type: yup.string<PaymentMethods>().required(),
        value: yup.boolean().required(),
        label: yup.string().required(),
      }),
    )
    .test('required', 'Minimum 1 payment method required *', (value) => {
      if (!value?.some((item) => item.value)) return false
      return true
    })
    .required(),
  accessibilityInfo: yup.array().of(yup.number().defined()).required(),
  accommodationPackageInfo: yup.array().of(yup.string().max(300).defined()).required(),
  accommodationInfoFile: yup.mixed<File | string>().test(fileTest({ size: 10, extensions: ['pdf'] })),
  transportationInfoFile: yup.mixed<File | string>().test(fileTest({ size: 10, extensions: ['pdf'] })),
  penalties: yup
    .array()
    .of(
      yup.object({
        penaltyType: yup
          .number()
          .required()
          .when('enable', {
            is: true,
            then: (schema) => schema.required(),
            otherwise: (schema) => schema.notRequired(),
          }),
        deadline: yup.string().when('enable', {
          is: true,
          then: (schema) => schema.required(),
          otherwise: (schema) => schema.notRequired(),
        }),
        fees: yup
          .number()
          .nullable()
          .min(0)
          .when('isPercentage', {
            is: true,
            then: (schema) => schema.max(100, `Percentage cann't be more than 100`),
            otherwise: (schema) => schema.max(10000000000),
          })
          .when('enable', {
            is: true,
            then: (schema) => schema.required(),
          }),
        currencyId: yup.number().required(),
        isPercentage: yup.boolean().required(),
        enable: yup.boolean(),
        label: yup.string(),
      }),
    )
    .required(),
})

export type TSchema = yup.InferType<typeof schema>

export const ACCOMMODATION_PACKAGE_BENEFITS = [
  'Food',
  'Transportation',
  'Complimentary Breakfast',
  'Airport Shuttle Service',
  'Free Wi-Fi',
  'Fitness Center Access',
  '24-Hour Room Service',
  'Daily Housekeeping',
  'Swimming Pool Access',
  'Spa Discounts',
  'Concierge Service',
]

export const PAYMENT_METHODS: EventDTO['paymentMethodSupported'] = [
  { label: 'Debit/Credit Card', type: 'card', value: false },
  { label: 'Bank Transfer', type: 'bankTransfer', value: false },
  { label: 'Cash on Arrival', type: 'cash', value: false },
]

export const STATUS: EventDTO['status'][] = ['draft', 'inactive', 'active']

export const getFeesDefault = (currencyId: number): TSchema['roleWiseData'][0] => {
  return { role: '', price: null as any, access: [], code: '', currencyId }
}

export const getPenalties = (currencyId: number): TSchema['penalties'] => {
  return [
    { penaltyType: 1, label: 'Late Registration', enable: false, currencyId, deadline: null as any, fees: null, isPercentage: false },
    { penaltyType: 2, label: 'Cancellation', enable: false, currencyId, deadline: null as any, fees: null, isPercentage: false },
    { penaltyType: 3, label: 'Guest Replacement', enable: false, currencyId, deadline: null as any, fees: null, isPercentage: false },
  ]
}

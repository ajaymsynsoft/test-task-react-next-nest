import Link from 'next/link'
import moment from 'moment'
import Image from 'next/image'
import { useEffect } from 'react'
import { useRouter } from 'next/router'
import { Autocomplete, FormControl, createFilterOptions, FormHelperText, Link as MuiLink, Grid, InputLabel, MenuItem, Select, Stack, TextField, FormControlLabel, Switch } from '@mui/material'
import { RadioGroup, Radio, Typography, Button, IconButton, Grow, Chip, Box, Avatar, Collapse, Tooltip, Checkbox, InputAdornment } from '@mui/material'
import { Controller, useFieldArray, useForm } from 'react-hook-form'
import { LoadingButton } from '@mui/lab'
import { MobileDatePicker } from '@mui/x-date-pickers'
import { MdAccessTime, MdOutlinePayments, MdClose, MdOutlinePayment, MdOutlineInfo, MdGavel } from 'react-icons/md'
import { yupResolver } from '@hookform/resolvers/yup'

import ImageField from '@/components/_ui/imageField/ImageField.component'
import InputField from '@/components/_ui/inputField/InputField.component'
import TextEditorField from '@/components/_ui/textEditorField/TextEditorField.component'
import HeadingWithIcon from '@/components/_ui/headingWithIcon/HeadingWithIcon.component'
import FileUploadField from '@/components/_ui/fileUploadField/FileUploadField.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { EventDTO } from '@/dto'
import { useGetCountriesQuery, useUploadFileMutation } from '@/redux/api/common.api'
import { EventFormProps } from './EventForm.type'
import { formatToTitleCase } from '@/utils'
import { useGetPaymentProviderQuery } from '@/redux/api/payment.api'
import { useCreateEventMutation, useUpdateEventMutation } from '@/redux/api/event.api'
import { useGetAccessiblitiesQuery, useGetTimeZonesQuery } from '@/redux/api/common.api'
import { ACCOMMODATION_PACKAGE_BENEFITS, getPenalties, PAYMENT_METHODS, TSchema, schema, STATUS, getFeesDefault } from './EventForm.config'
import { useReduxSelector } from '@/hooks'

export default function EventForm({ isEditMode, data }: EventFormProps) {
  const router = useRouter()
  const filter = createFilterOptions<string>()
  const organization = useReduxSelector((state) => state.organization)
  const currencyId = organization.displayCurrency.id
  const currencyCode = organization.displayCurrency.code
  const feesDefault = getFeesDefault(currencyId)
  const penalties = getPenalties(currencyId)

  const timeZonesApiState = useGetTimeZonesQuery()
  const accessiblitiesApiState = useGetAccessiblitiesQuery()
  const paymentProviderApiState = useGetPaymentProviderQuery()
  const countriesApiState = useGetCountriesQuery()

  const [uploadFile] = useUploadFileMutation()
  const [createEvent] = useCreateEventMutation()
  const [updateEvent] = useUpdateEventMutation()

  const {
    control,
    handleSubmit,
    watch,
    trigger,
    setValue,
    getValues,
    setError,
    setFocus,
    formState: { isSubmitting, errors, isSubmitted },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      ...(isEditMode
        ? {
            name: data.name,
            status: data.status,
            bannerImage: data.bannerImage,
            description: data.description,
            address: data.address,
            city: data.city,
            state: data.state,
            countryId: data.countryId,
            timeZoneId: data.timeZoneId,
            startDate: data.startDate as any,
            endDate: data.endDate as any,
            roleWiseData: data.roleWiseData.length ? data.roleWiseData : [feesDefault],
            paymentProviderId: data.paymentproviderId,
            accessibilityInfo: data.accessibilityInfo,
            accommodationPackageInfo: data.accommodationPackageInfo,
            accommodationInfoFile: data.accommodationInfoFile,
            transportationInfoFile: data.transportationInfoFile,
            paymentMethodSupported: PAYMENT_METHODS.map((defaultMethod) => {
              const methodData = data.paymentMethodSupported.find((item) => item.type === defaultMethod.type)
              if (methodData) Object.assign(defaultMethod, methodData)
              return defaultMethod
            }),
            penalties: penalties.map((defaultPenalty) => {
              const panaltyData = data.penalties.find((item) => item.penaltyType === defaultPenalty.penaltyType)
              if (panaltyData) defaultPenalty = Object.assign({ ...defaultPenalty, enable: true }, panaltyData)
              return defaultPenalty
            }),
          }
        : {
            roleWiseData: [feesDefault],
            penalties: penalties,
          }),
    },
  })

  const paymentMethodSupportedField = useFieldArray({ name: 'paymentMethodSupported', control })
  const penaltiesField = useFieldArray({ name: 'penalties', control })
  const roleWiseDataField = useFieldArray({ name: 'roleWiseData', control })

  const addRoleWiseDataField = () => roleWiseDataField.append(feesDefault)
  const removeRoleWiseDataField = (index: number) => roleWiseDataField.remove(index)
  if (!roleWiseDataField.fields.length) addRoleWiseDataField()

  const triggerFeesAndAccessFields = (index: number) => {
    isSubmitted && trigger([`roleWiseData.${index}.role`, `roleWiseData.${index}.price`, `roleWiseData.${index}.code`, `roleWiseData.${index}.access`])
  }

  useEffect(() => {
    setValue('paymentProviderId', paymentProviderApiState.data?.id || null)
    if (paymentProviderApiState.data) setValue('paymentMethodSupported', PAYMENT_METHODS)
    else
      setValue(
        'paymentMethodSupported',
        PAYMENT_METHODS.filter((item) => item.type === 'cash'),
      )
  }, [paymentProviderApiState.isFetching])

  const onSubmit = async () => {
    const formData = schema.validateSync(getValues())
    formData.roleWiseData = formData.roleWiseData?.filter((item) => item.role)

    formData.penalties.forEach(({ deadline }, index) => {
      if (deadline && moment(deadline).isAfter(formData.startDate)) {
        setError(`penalties.${index}.deadline`, { type: 'validation', message: 'It must be less than "Start date and time"' }, { shouldFocus: true })
        setFocus(`penalties.${index}.deadline`)
        throw ''
      }
    })

    formData.penalties = formData.penalties?.filter((item) => item.enable)

    if (formData.accommodationInfoFile instanceof File) {
      const [image] = await uploadFile({ files: formData.accommodationInfoFile, folderName: 'event' }).unwrap()
      formData.accommodationInfoFile = image
      setValue('accommodationInfoFile', image)
    }

    if (formData.transportationInfoFile instanceof File) {
      const [image] = await uploadFile({ files: formData.transportationInfoFile, folderName: 'event' }).unwrap()
      formData.transportationInfoFile = image
      setValue('transportationInfoFile', image)
    }

    if (formData.bannerImage instanceof File) {
      const [image] = await uploadFile({ files: formData.bannerImage, folderName: 'event' }).unwrap()
      formData.bannerImage = image
      setValue('bannerImage', image)
    }

    const finalData = {
      ...formData,
      bannerImage: formData.bannerImage,
      accommodationInfoFile: formData.accommodationInfoFile,
      transportationInfoFile: formData.transportationInfoFile,
      roleWiseData: formData.roleWiseData as EventDTO['roleWiseData'],
      penalties: formData.penalties as EventDTO['penalties'],
    }

    if (isEditMode) await updateEvent({ ...finalData, id: data.id }).unwrap()
    else await createEvent(finalData).unwrap()

    router.push('/dashboard/events')
  }

  return (
    <RenderContent
      loading={timeZonesApiState.isLoading || accessiblitiesApiState.isLoading || paymentProviderApiState.isLoading || countriesApiState.isLoading}
      error={timeZonesApiState.isError || accessiblitiesApiState.isError || paymentProviderApiState.isError}
    >
      <Grid container component="form" noValidate onSubmit={handleSubmit(onSubmit)} spacing={2}>
        {/* Event name */}
        <Grid item xs={12} sm={9}>
          <InputField name="name" label="Event name *" control={control} />
        </Grid>

        {/* Status */}
        <Grid item xs={12} sm={3}>
          <Controller
            name="status"
            control={control}
            defaultValue={'' as any}
            render={({ fieldState: { error }, field: { ref, ...restField } }) => (
              <FormControl error={!!error}>
                <InputLabel>Status *</InputLabel>
                <Select {...restField} inputRef={ref} label="Status *">
                  {STATUS.map((item, index) => (
                    <MenuItem value={item} key={index}>
                      {formatToTitleCase(item)}
                    </MenuItem>
                  ))}
                </Select>
                <FormHelperText>{error?.message}</FormHelperText>
              </FormControl>
            )}
          />
        </Grid>

        {/* Banner Image */}
        <Grid item xs={12}>
          <ImageField name="bannerImage" label="Event banner image *" control={control} />
        </Grid>

        {/* Description */}
        <Grid item xs={12}>
          <TextEditorField name="description" control={control} />
        </Grid>

        {/* Heading */}
        <Grid item xs={12} mt={2}>
          <HeadingWithIcon Icon={MdAccessTime} text="Location and time" />
        </Grid>

        {/* Address */}
        <Grid item xs={12}>
          <InputField name="address" label="Address *" control={control} />
        </Grid>

        {/* City */}
        <Grid item xs={12} sm={4}>
          <InputField name="city" label="City *" control={control} />
        </Grid>

        {/* State */}
        <Grid item xs={12} sm={4}>
          <InputField name="state" label="State *" control={control} />
        </Grid>

        {/* Country */}
        <Grid item xs={12} sm={4}>
          <Controller
            name="countryId"
            control={control}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <Autocomplete
                {...restField}
                options={countriesApiState.data || []}
                value={countriesApiState.data!.find((item) => item.id === value) || null}
                onChange={(_, value) => onChange(value?.id)}
                getOptionLabel={(option) => option.name}
                renderInput={(params) => <TextField {...params} label="Country *" inputRef={ref} error={!!error} helperText={error?.message} inputProps={{ ...params.inputProps, autoComplete: 'new-password' }} />}
              />
            )}
          />
        </Grid>

        {/* Timezone */}
        <Grid item xs={12} sm={4}>
          <Controller
            name="timeZoneId"
            control={control}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <Autocomplete
                {...restField}
                value={timeZonesApiState.data?.find((item) => item.id === value) || null}
                options={timeZonesApiState.data || []}
                onChange={(_, value) => onChange(value?.id)}
                getOptionLabel={(option) => option.text}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                renderInput={(params) => <TextField {...params} inputRef={ref} label="Time zone *" error={!!error} helperText={error?.message} />}
              />
            )}
          />
        </Grid>

        {/* Start Date */}
        <Grid item xs={12} sm={4}>
          <Controller
            name="startDate"
            control={control}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <MobileDatePicker
                {...restField}
                label="Start date *"
                inputRef={ref}
                disablePast={true}
                value={value ? moment(value) : null}
                onChange={(value) => {
                  onChange(value?.toISOString())
                  isSubmitted && trigger('endDate')
                }}
                slotProps={{
                  textField: { error: !!error, helperText: error?.message },
                }}
              />
            )}
          />
        </Grid>

        {/* End Date */}
        <Grid item xs={12} sm={4}>
          <Controller
            name="endDate"
            control={control}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <MobileDatePicker
                {...restField}
                label="End date *"
                inputRef={ref}
                disablePast={true}
                value={value ? moment(value) : null}
                onChange={(value) => {
                  onChange(value?.toISOString())
                  isSubmitted && trigger('startDate')
                }}
                slotProps={{
                  textField: { error: !!error, helperText: error?.message },
                }}
              />
            )}
          />
        </Grid>

        {/* Heading */}
        <Grid item xs={12} mt={2}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" gap={2}>
            <HeadingWithIcon Icon={MdOutlinePayments} text="Fees and access" />
            <Button size="small" onClick={addRoleWiseDataField}>
              Add More
            </Button>
          </Stack>
        </Grid>

        {/* Fees & Access */}
        {roleWiseDataField.fields.map((item, index) => (
          <Grid item xs={12} key={item.id}>
            <Grow in timeout={400}>
              <Stack direction="row" alignItems="start" gap={2}>
                <Typography variant="subtitle" mt={1.8}>
                  {index + 1}.{' '}
                </Typography>
                <Grid container spacing={2}>
                  {/* Role */}
                  <Grid item xs={12} sm={3}>
                    <InputField
                      name={`roleWiseData.${index}.role`}
                      label="Role *"
                      control={control}
                      onChange={(event, field, value) => {
                        field.onChange(value)
                        triggerFeesAndAccessFields(index)
                      }}
                    />
                  </Grid>

                  {/* Price */}
                  <Grid item xs={12} sm={3}>
                    <InputField
                      name={`roleWiseData.${index}.price`}
                      label="Price *"
                      type="number"
                      control={control}
                      onChange={(event, field, value) => {
                        field.onChange(value)
                        triggerFeesAndAccessFields(index)
                      }}
                      InputProps={{
                        endAdornment: <InputAdornment position="end">{currencyCode}</InputAdornment>,
                      }}
                    />
                  </Grid>

                  {/* Code */}
                  <Grid item xs={12} sm={2}>
                    <InputField
                      name={`roleWiseData.${index}.code`}
                      label="Code"
                      control={control}
                      onChange={(event, field, value) => {
                        field.onChange(event.target.value.toUpperCase())
                        triggerFeesAndAccessFields(index)
                      }}
                    />
                  </Grid>

                  {/* Access */}
                  <Grid item xs={12} sm={4}>
                    <Controller
                      name={`roleWiseData.${index}.access`}
                      control={control}
                      defaultValue={[]}
                      render={({ fieldState: { error }, field: { ref, ...restField } }) => (
                        <Autocomplete
                          {...restField}
                          multiple
                          freeSolo
                          disableCloseOnSelect
                          options={[]}
                          onChange={(_, value) => {
                            restField.onChange(value.map((item) => item.replace(/^Add\s|"|"$/g, '')))
                            triggerFeesAndAccessFields(index)
                          }}
                          filterOptions={(options, params) => {
                            const { inputValue } = params
                            const filtered = filter(options, params)
                            const isExisting = options.some((option) => inputValue === option)
                            if (inputValue !== '' && !isExisting) filtered.push(`Add "${inputValue}"`)
                            return filtered
                          }}
                          renderInput={(params) => <TextField {...params} label="Access" inputRef={ref} error={!!error} />}
                        />
                      )}
                    />
                  </Grid>
                </Grid>
                <IconButton size="small" onClick={(_) => removeRoleWiseDataField(index)} sx={{ mt: 1.8 }}>
                  <MdClose />
                </IconButton>
              </Stack>
            </Grow>
          </Grid>
        ))}

        {/* Heading */}
        <Grid item xs={12} mt={2}>
          <Stack alignItems="start" gap={1}>
            <Stack direction="row" alignItems="center" gap={2}>
              <HeadingWithIcon Icon={MdOutlinePayment} text="Payment methods" />
              {paymentProviderApiState.data && (
                <Tooltip title="Payment provider added in settings" placement="top">
                  <Chip label={formatToTitleCase(paymentProviderApiState.data?.paymentMethod)} />
                </Tooltip>
              )}
            </Stack>
            {!paymentProviderApiState.data && (
              <Chip
                size="medium"
                variant="outlined"
                sx={{ mb: -1, borderColor: 'dividerDark', borderRadius: 1 }}
                label={
                  <>
                    Add payment provider for more payment options &nbsp;{' '}
                    <MuiLink component={Link} href="/dashboard/settings?tab=13" target="_blank">
                      Add
                    </MuiLink>
                  </>
                }
              />
            )}
          </Stack>
        </Grid>

        {/* Payment Methods */}
        <Grid item xs={12}>
          <Stack>
            <Stack gap={1.25}>
              {paymentMethodSupportedField.fields.map((item, index) => (
                <Controller
                  name={`paymentMethodSupported.${index}`}
                  control={control}
                  key={item.id}
                  render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                    <FormControl error={!!error}>
                      <FormControlLabel
                        label={value.label}
                        componentsProps={{ typography: { color: error ? 'error.main' : undefined } }}
                        control={
                          <Switch
                            {...restField}
                            inputRef={ref}
                            checked={value.value}
                            onChange={(_, newValue) => {
                              onChange({ ...value, value: newValue }), isSubmitted && trigger('paymentMethodSupported')
                            }}
                          />
                        }
                      />
                    </FormControl>
                  )}
                />
              ))}
            </Stack>
            <FormHelperText error>{errors.paymentMethodSupported?.root?.message || errors.paymentMethodSupported?.message}</FormHelperText>
          </Stack>
        </Grid>

        {/* Heading */}
        <Grid item xs={12} mt={2}>
          <HeadingWithIcon Icon={MdGavel} text="Penalties" />
        </Grid>

        {/* Penalties  */}
        <Grid item xs={12}>
          <Stack gap={1.25}>
            {penaltiesField.fields.map((item, index) => (
              <Stack key={item.id}>
                <Controller
                  name={`penalties.${index}.enable`}
                  control={control}
                  defaultValue={false}
                  render={({ fieldState: { error }, field: { ref, value, ...restField } }) => (
                    <FormControl error={!!error}>
                      <FormControlLabel label={item.label} componentsProps={{ typography: { color: error ? 'error.main' : undefined } }} control={<Switch {...restField} inputRef={ref} checked={value} />} />
                      <FormHelperText>{error?.message}</FormHelperText>
                    </FormControl>
                  )}
                />

                <Collapse in={watch(`penalties.${index}.enable`)}>
                  <Grid container spacing={2} pt={1.25} mb={penaltiesField.fields.length - 1 === index ? 0 : 1}>
                    {/* Deadline Date */}
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name={`penalties.${index}.deadline`}
                        control={control}
                        render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                          <MobileDatePicker
                            {...restField}
                            label="Deadline date *"
                            inputRef={ref}
                            disablePast={true}
                            value={value ? moment(value) : null}
                            onChange={(value) => onChange(value?.toISOString())}
                            slotProps={{
                              textField: { error: !!error, helperText: error?.message },
                            }}
                          />
                        )}
                      />
                    </Grid>

                    {/* Fees */}
                    <Grid item xs={12} sm={6}>
                      <InputField
                        name={`penalties.${index}.fees`}
                        label="Fees *"
                        type="number"
                        control={control}
                        InputProps={{
                          endAdornment: (
                            <Controller
                              name={`penalties.${index}.isPercentage`}
                              control={control}
                              render={({ field: { ref, onChange, ...restField } }) => (
                                <RadioGroup
                                  {...restField}
                                  onChange={(e, value) => {
                                    onChange(value === 'true')
                                    isSubmitted && trigger(`penalties.${index}.fees`)
                                  }}
                                  row
                                  sx={{ flexWrap: 'nowrap' }}
                                >
                                  <Tooltip title={`Fees in ${organization.displayCurrency.name}`} placement="top">
                                    <FormControlLabel label={currencyCode} inputRef={ref} value={false} control={<Radio />} />
                                  </Tooltip>
                                  <Tooltip title="Fees in percentage" placement="top">
                                    <FormControlLabel label="%" inputRef={ref} value={true} control={<Radio />} sx={{ mr: 0 }} />
                                  </Tooltip>
                                </RadioGroup>
                              )}
                            />
                          ),
                        }}
                      />
                    </Grid>
                  </Grid>
                </Collapse>
              </Stack>
            ))}
          </Stack>
        </Grid>

        {/* Heading */}
        <Grid item xs={12} mt={2}>
          <HeadingWithIcon Icon={MdOutlineInfo} text="Additional information" />
        </Grid>

        {/* Accessibility Type */}
        <Grid item xs={12} sm={6}>
          <Controller
            name="accessibilityInfo"
            control={control}
            defaultValue={[]}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <Autocomplete
                {...restField}
                multiple
                disableCloseOnSelect
                value={accessiblitiesApiState.data?.filter((item) => value.includes(item.id)) || []}
                options={accessiblitiesApiState.data || []}
                onChange={(_, value) => onChange(value.map((item) => item.id))}
                getOptionLabel={(option) => option.name}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                renderInput={(params) => <TextField {...params} label="Accessibility type" inputRef={ref} error={!!error} helperText={error?.message} />}
                renderTags={(value, getTagProps) => value.map((option, index) => <Chip size="medium" label={option.name} avatar={<Avatar alt="icon" src={option?.imageURL} />} {...getTagProps({ index })} key={index} />)}
                renderOption={(props, option, { selected }) => (
                  <li {...props} key={props.key}>
                    <Checkbox edge="start" size="small" checked={selected} disableRipple />
                    <Image src={option.imageURL} width={24} height={24} style={{ opacity: 0.8, marginRight: '8px' }} alt="accessibility icon" />
                    {option.name}
                  </li>
                )}
              />
            )}
          />
        </Grid>

        {/* Accommodation Package Benefits */}
        <Grid item xs={12} sm={6}>
          <Controller
            name="accommodationPackageInfo"
            control={control}
            defaultValue={[]}
            render={({ fieldState: { error }, field: { ref, onChange, ...restField } }) => (
              <Autocomplete
                {...restField}
                multiple
                freeSolo
                disableCloseOnSelect
                options={ACCOMMODATION_PACKAGE_BENEFITS}
                onChange={(_, value) => onChange(value.map((item) => item.replace(/^Add\s|"|"$/g, '')))}
                filterOptions={(options, params) => {
                  const { inputValue } = params
                  const filtered = filter(options, params as any)
                  const isExisting = options.some((option) => inputValue === option)
                  if (inputValue !== '' && !isExisting) filtered.push(`Add "${inputValue}"`)
                  return filtered as any
                }}
                renderInput={(params) => <TextField {...params} inputRef={ref} label="Accommodation package benefits" error={!!error} helperText={error?.message} />}
                renderOption={(props, option, { selected }) => (
                  <li {...props} key={props.key}>
                    {!option.startsWith('Add "') ? <Checkbox edge="start" size="small" checked={selected} disableRipple /> : ''}
                    {option}
                  </li>
                )}
              />
            )}
          />
        </Grid>

        {/* Accommodation Information */}
        <Grid item xs={12} sm={6}>
          <FileUploadField name="accommodationInfoFile" label="Upload Accommodation Information PDF" accept="application/pdf" control={control} />
        </Grid>

        {/* Accommodation Information */}
        <Grid item xs={12} sm={6}>
          <FileUploadField name="transportationInfoFile" label="Upload Transportation Information PDF" accept="application/pdf" control={control} />
        </Grid>

        {/* Footer */}
        <Grid item xs={12}>
          <Stack direction="row" justifyContent="end" gap={1}>
            <LoadingButton variant="text" disabled={isSubmitting} onClick={() => router.push('/dashboard/events')}>
              Cancel
            </LoadingButton>
            <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
              {isEditMode ? 'Update' : 'Save'}
            </LoadingButton>
          </Stack>
        </Grid>
      </Grid>
    </RenderContent>
  )
}

import { EventDTO } from '@/dto'

export type EventFormProps =
  | {
      isEditMode: false
      data?: void
    }
  | {
      isEditMode: true
      data: EventDTO
    }

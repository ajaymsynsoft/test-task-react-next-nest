import { Style } from '@/types'

export const style: Style = {
  messageBody: {
    whiteSpace: 'pre-wrap',
  },
  listItem: {
    alignItems: 'start',
  },
  listItemAvatar: {
    mt: 1,
  },
}

import moment from 'moment'
import { useState, useEffect, useRef } from 'react'
import { MdNotificationsNone } from 'react-icons/md'
import { Avatar, List, CircularProgress, ListItemAvatar, ListItemText, Typography, Container, Divider, Stack, ListItem, Alert } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { NotificationDTO } from '@/dto'
import { style } from './Notifications.style'
import { Page } from '@/types'
import { useLazyGetNotificationsQuery } from '@/redux/api/notification.api'

const Notifications: Page = () => {
  const loaderRef = useRef<HTMLElement>()
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(true)
  const [listData, setListData] = useState<NotificationDTO[]>([])
  const [getNotifications, { data, isFetching, isError, isLoading, isUninitialized }] = useLazyGetNotificationsQuery()

  const observer = new IntersectionObserver((entries) => {
    const fetching = loaderRef.current?.dataset.loading === 'true'
    if (entries[0].isIntersecting && !fetching) setPage((item) => item + 1)
  })

  useEffect(() => {
    getNotifications({ pageNo: page, pageSize: 25 }, true)
      .unwrap()
      .then((res) => {
        const updatedList = listData.concat(res.list)
        setListData(updatedList)

        if (updatedList.length >= res.totalCount) removeLoader()
        else {
          setTimeout(() => {
            const fetching = loaderRef.current?.dataset.loading === 'true'
            if (isElementInViewport(loaderRef.current) && !fetching && loading) setPage((item) => item + 1)
          }, 1000)
        }
      })
      .catch(() => removeLoader())
  }, [page])

  useEffect(() => {
    if (!isLoading && !isError && !isUninitialized) {
      setTimeout(() => {
        loaderRef.current && observer.observe(loaderRef.current)
      }, 1000)
      return () => {
        observer.disconnect()
      }
    }
  }, [isLoading, isError, isUninitialized])

  const removeLoader = () => {
    setLoading(false)
    loaderRef.current && observer.unobserve(loaderRef.current)
  }

  const isElementInViewport = (el: HTMLElement | undefined) => {
    if (!el) return false
    const rect = el.getBoundingClientRect()

    return rect.top >= 0 && rect.left >= 0 && rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  }

  return (
    <>
      {/* Page Header */}
      <PageHeader heading="Notifications" count={data?.totalCount} />

      {/* List */}
      <Container>
        <RenderContent loading={isLoading} error={isError}>
          {listData.length ? (
            <List component={Stack} divider={<Divider variant="middle" />} disablePadding>
              {listData.map((item, index) => (
                <ListItem key={index} sx={style.listItem}>
                  <ListItemAvatar sx={style.listItemAvatar}>
                    <Avatar>
                      <MdNotificationsNone className="icon-xl " />
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Stack gap={0.3}>
                        <Typography variant="h4">{item.messageTitle}</Typography>
                        <Typography sx={style.messageBody}>{item.message}</Typography>
                      </Stack>
                    }
                    secondary={
                      <Typography variant="body2" mt={1}>
                        {moment(item.notificationDateTime).calendar(null, { sameElse: 'MMM DD, YYYY' })}
                      </Typography>
                    }
                  />
                </ListItem>
              ))}
              {loading && <Stack component={CircularProgress} data-loading={!!isFetching} mx="auto" mt={2} ref={loaderRef} />}
            </List>
          ) : (
            <Alert variant="outlined" severity="info">
              No notification found
            </Alert>
          )}
        </RenderContent>
      </Container>
    </>
  )
}

Notifications.rootLayoutProps = {
  title: 'Notifications',
  pageType: 'protected',
}

export default Notifications

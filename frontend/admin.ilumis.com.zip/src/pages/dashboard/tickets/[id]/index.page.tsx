import { Chip, Skeleton, Stack, Typography } from '@mui/material'
import { useRouter } from 'next/router'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import TicketChat from '@/components/_ticket/ticketChat/TicketChat.component'
import MoreMenu from './components/moreMenu/MoreMenu.component'
import { useGetTicketMessagesQuery } from '@/redux/api/ticket.api'
import { Page } from '@/types/Page.type'
import { style } from './Ticket.style'
import { getStatusColor } from '@/utils'

const Ticket: Page = () => {
  const router = useRouter()
  const { data, isLoading, isError, isFetching } = useGetTicketMessagesQuery(Number(router.query.id), {
    pollingInterval: 15000,
    refetchOnMountOrArgChange: true,
    refetchOnFocus: true,
    refetchOnReconnect: true,
  })

  return (
    <>
      {/* Page Header */}
      <PageHeader
        backUrl="/dashboard/tickets"
        sx={{ my: 0, borderColor: 'var(--border-color)', h1: { flex: 1 } }}
        actions={!isLoading && !isError && <MoreMenu data={data![0]} />}
        heading={
          <Stack direction="row" gap={1.5}>
            {isLoading || isError ? (
              <>
                <Skeleton variant="rounded" height={40} width="50%" />
                <Skeleton variant="rounded" height={40} width={100} />
              </>
            ) : (
              <>
                <Typography variant="inherit" noWrap>
                  {data![0].subject}
                </Typography>
                <Chip label={data![0].status} variant="outlined" color={getStatusColor(data![0].status)} sx={{ fontWeight: 400 }} />
              </>
            )}
          </Stack>
        }
      />

      {/* Chat */}
      <Stack sx={style.container}>
        <TicketChat data={data} loading={isLoading} updating={isFetching} error={isError} />
      </Stack>

      {/* Style */}
      <style jsx global>{`
        main {
          margin-bottom: 0 !important;
        }
        body {
          overflow: hidden;
        }
      `}</style>
    </>
  )
}

Ticket.rootLayoutProps = {
  pageType: 'protected',
  title: 'Ticket Chat',
  module: {
    id: 18,
    permission: 'view',
  },
}

export default Ticket

import { useState } from 'react'
import { IconButton, ListItemIcon, ListItemText, Menu, MenuItem } from '@mui/material'
import { MdCheck, MdMoreHoriz, MdOutlinePersonOutline } from 'react-icons/md'

import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import AssignGuestPopup from '../assignGuestPopup/AssignGuestPopup.component'
import { useCloseTicketMutation } from '@/redux/api/ticket.api'
import { MoreMenuProps } from './MoreMenu.type'
import { useReduxSelector } from '@/hooks'

export default function MoreMenu({ data }: MoreMenuProps) {
  const { role } = useReduxSelector((state) => state.layout.profile)
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null)
  const [showCloseTicket, setShowCloseTicket] = useState(false)
  const [showAssignGuest, setShowAssignGuest] = useState(false)
  const [closeTicket, closeTicketApiState] = useCloseTicketMutation()

  const open = !!anchorEl
  const disableAssign = data.status === 'closed' || !(role === 'admin' || role === 'supportStaff')

  const handleClose = () => {
    setAnchorEl(null)
  }

  return (
    <>
      {/* Action */}
      <IconButton onClick={(e) => setAnchorEl(e.currentTarget)}>
        <MdMoreHoriz />
      </IconButton>

      {/* Menu */}
      <Menu anchorEl={anchorEl} open={open} onClose={handleClose}>
        <MenuItem
          onClick={() => {
            handleClose(), setShowCloseTicket(true)
          }}
          disabled={data.status === 'closed'}
        >
          <ListItemIcon>
            <MdCheck />
          </ListItemIcon>
          <ListItemText>Close Ticket</ListItemText>
        </MenuItem>
        <MenuItem
          onClick={() => {
            handleClose(), setShowAssignGuest(true)
          }}
          disabled={disableAssign}
        >
          <ListItemIcon>
            <MdOutlinePersonOutline />
          </ListItemIcon>
          <ListItemText>Assign Ticket</ListItemText>
        </MenuItem>
      </Menu>

      {/* Close Ticket Confirmation */}
      {showCloseTicket && (
        <ConfirmationPopup
          heading="Close ticket"
          subheading="Sure to close this ticket?"
          acceptButtonText="Close Ticket"
          loading={closeTicketApiState.isLoading}
          onCancel={() => setShowCloseTicket(false)}
          onAccept={() =>
            closeTicket(data.id)
              .unwrap()
              .then((_) => setShowCloseTicket(false))
          }
        />
      )}

      {/* Assign Ticket */}
      {showAssignGuest && <AssignGuestPopup data={data} onCancel={() => setShowAssignGuest(false)} />}
    </>
  )
}

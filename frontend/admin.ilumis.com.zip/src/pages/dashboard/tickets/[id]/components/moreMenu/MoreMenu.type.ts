import { TicketDTO } from '@/dto'

export type MoreMenuProps = {
  data: TicketDTO
}

import * as yup from 'yup'

export const schema = yup.object({
  assignedToId: yup.number().required(),
  ticketId: yup.number().required(),
})

export type TSchema = yup.InferType<typeof schema>

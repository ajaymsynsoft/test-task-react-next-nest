import { TicketDTO } from '@/dto'

export type AssignGuestPopupProps = {
  data: TicketDTO
  onCancel: () => void
}

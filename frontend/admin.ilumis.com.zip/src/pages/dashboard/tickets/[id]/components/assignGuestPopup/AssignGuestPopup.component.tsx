import { LoadingButton } from '@mui/lab'
import { yupResolver } from '@hookform/resolvers/yup'
import { Controller, useForm } from 'react-hook-form'
import { Chip, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormHelperText, InputLabel, MenuItem, Select } from '@mui/material'

import RenderContent from '@/components/renderContent/RenderContent.component'
import { AssignGuestPopupProps } from './AssignGuestPopup.type'
import { formatToTitleCase } from '@/utils'
import { useGetAssignStaffListQuery } from '@/redux/api/staff.api'
import { schema, TSchema } from './AssignGuestPopup.config'
import { useAssignedToSatffMutation } from '@/redux/api/ticket.api'

export default function AssignGuestPopup({ data, onCancel }: AssignGuestPopupProps) {
  const [assignedToSatff] = useAssignedToSatffMutation()
  const { data: staffList, isLoading, isError } = useGetAssignStaffListQuery()

  const {
    handleSubmit,
    control,
    getValues,
    formState: { isSubmitting },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      ticketId: data.id,
      assignedToId: data.assignedToId,
    },
  })

  const onSubmit = async () => {
    const formData = getValues()
    await assignedToSatff(formData).unwrap()
    onCancel()
  }

  return (
    <Dialog open fullWidth component="form" maxWidth="sm" onClose={() => !isSubmitting && onCancel()} onSubmit={handleSubmit(onSubmit)} {...{ noValidate: true }}>
      <DialogTitle>Assign Ticket</DialogTitle>
      <DialogContent dividers>
        <RenderContent loading={isLoading} error={isError}>
          {staffList && (
            <Controller
              name="assignedToId"
              control={control}
              render={({ fieldState: { error }, field: { ref, ...restField } }) => (
                <FormControl error={!!error}>
                  <InputLabel>Asign To *</InputLabel>
                  <Select {...restField} inputRef={ref} label="Asign To *">
                    {staffList.map((item, index) => (
                      <MenuItem value={item.id} key={index}>
                        #{item.staffId} - {item.firstName} {item.lastName} &nbsp; &nbsp; <Chip label={formatToTitleCase(item.role as string)} />
                      </MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>{error?.message}</FormHelperText>
                </FormControl>
              )}
            />
          )}
        </RenderContent>
      </DialogContent>
      <DialogActions>
        <LoadingButton variant="text" disabled={isSubmitting || isLoading} onClick={onCancel}>
          Cancel
        </LoadingButton>
        <LoadingButton variant="contained" type="submit" disabled={isLoading} loading={isSubmitting}>
          Assign
        </LoadingButton>
      </DialogActions>
    </Dialog>
  )
}

import { HEADER_HEIGHT } from '@/layouts/rootLayout/RootLayout.config'
import { Style } from '@/types/Style.type'

export const style: Style = {
  container: {
    display: 'flex',
    overflow: 'hidden',
    height: `calc(100vh - ${HEADER_HEIGHT}px)`,
  },
}

import { Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import TicketTable from '@/components/_ticket/ticketTable/TicketTable.component'
import { Page } from '@/types'
import { usePagination } from '@/hooks'
import { useGetTicketListQuery } from '@/redux/api/ticket.api'

const Tickets: Page = () => {
  const { page, pageSize } = usePagination()
  const { data, isError, isLoading } = useGetTicketListQuery(
    { pageNo: page, pageSize },
    {
      pollingInterval: 15000,
      refetchOnMountOrArgChange: true,
      refetchOnFocus: true,
      refetchOnReconnect: true,
    },
  )

  return (
    <>
      <PageHeader heading="Support Tickets" count={data?.totalCount} />

      <Container>
        <RenderContent loading={isLoading} error={isError}>
          {data && <TicketTable data={data} loading={isLoading} />}
        </RenderContent>
      </Container>
    </>
  )
}

Tickets.rootLayoutProps = {
  title: 'Support Tickets',
  pageType: 'protected',
  module: {
    id: 18,
    permission: 'view',
  },
}

export default Tickets

import { useRouter } from 'next/router'
import { Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import SubscriptionForm from '../components/SubscriptionForm.component'
import { Page } from '@/types'
import { useGetSubscriptionQuery } from '@/redux/api/subscription.api'

const EditSubscription: Page = () => {
  const router = useRouter()
  const { isFetching, isError, data } = useGetSubscriptionQuery(Number(router.query.id))

  return (
    <>
      <PageHeader heading="Edit Subscription" backUrl="/dashboard/subscriptions" />

      <Container>
        <RenderContent loading={isFetching} error={isError}>
          {data && <SubscriptionForm data={data} />}
        </RenderContent>
      </Container>
    </>
  )
}

EditSubscription.rootLayoutProps = {
  title: 'Edit Subscription',
  pageType: 'protected',
  module: {
    id: 5,
    permission: 'edit',
  },
}

export default EditSubscription

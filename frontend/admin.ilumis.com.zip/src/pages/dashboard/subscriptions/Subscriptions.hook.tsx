import Link from 'next/link'
import { useRouter } from 'next/router'
import { Box, Link as MuiLink } from '@mui/material'
import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'
import { MdEdit, MdOutlineClose, MdCheck } from 'react-icons/md'

import { formatNumber } from '@/utils'
import { SubscriptionPlanDTO } from '@/dto'
import { useReduxSelector } from '@/hooks'

export const useColumns = () => {
  const router = useRouter()
  const IncludeIcon = <Box component={MdCheck} color="success.light" />
  const NotIncludeIcon = <Box component={MdOutlineClose} color="error.light" />
  const { modules } = useReduxSelector((state) => state.layout.profile)

  const columns: GridColDef<SubscriptionPlanDTO>[] = [
    {
      field: 'id',
      headerName: 'ID',
      sortable: false,
      minWidth: 85,
      width: 85,
      renderCell: ({ row }) => (
        <MuiLink component={Link} href={`/dashboard/subscriptions/edit/${row.id}`}>
          #{row.id}
        </MuiLink>
      ),
    },

    { field: 'name', headerName: 'Plan Name', sortable: false, flex: 1, minWidth: 100, width: 200 },
    {
      field: 'isTicketingSystemEnabled',
      headerName: 'Ticket',
      sortable: false,
      minWidth: 70,
      width: 70,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (params.row.isTicketingSystemEnabled ? IncludeIcon : NotIncludeIcon),
    },
    {
      field: 'isAccreditationEnabled',
      headerName: 'Accreditation',
      sortable: false,
      minWidth: 140,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (params.row.isAccreditationEnabled ? IncludeIcon : NotIncludeIcon),
    },
    {
      field: 'isVisaEnabled',
      headerName: 'Visa',
      sortable: false,
      minWidth: 70,
      width: 70,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (params.row.isVisaEnabled ? IncludeIcon : NotIncludeIcon),
    },
    {
      field: 'isAccommodationEnabled',
      headerName: 'Accommodation',
      sortable: false,
      minWidth: 140,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (params.row.isAccommodationEnabled ? IncludeIcon : NotIncludeIcon),
    },
    {
      field: 'noOfEvents',
      headerName: 'Events',
      sortable: false,
      minWidth: 70,
      width: 70,
    },
    {
      field: 'noOfStaffs',
      headerName: 'Staff',
      sortable: false,
      minWidth: 60,
      width: 60,
    },
    {
      field: 'amount',
      headerName: 'Amount',
      sortable: false,
      minWidth: 80,
      width: 80,
      renderCell: (params) => `$${formatNumber(params.value)}`,
    },
    {
      field: 'duration',
      headerName: 'Duration',
      sortable: false,
      minWidth: 100,
      renderCell: (params) => <>{params.value} &nbsp;month</>,
    },
    {
      field: 'actions',
      headerName: 'Actions',
      sortable: false,
      minWidth: 80,
      width: 80,
      align: 'center',
      type: 'actions',
      getActions: (params) => {
        const actions = []

        if (modules[5].permissions.edit) actions.push(<GridActionsCellItem showInMenu key="edit" label="Edit" onClick={(_) => router.push(`/dashboard/subscriptions/edit/${params.id}`)} icon={<MdEdit />} />)

        return actions
      },
    },
  ]

  return columns
}

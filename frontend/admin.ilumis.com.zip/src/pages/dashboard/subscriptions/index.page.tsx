import { Container } from '@mui/material'
import { DataGrid } from '@mui/x-data-grid'
import { useRouter } from 'next/router'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { useGetSubscriptionListQuery } from '@/redux/api/subscription.api'
import { useColumns } from './Subscriptions.hook'

const Subscriptions: Page = () => {
  const columns = useColumns()
  const router = useRouter()
  const { data, isFetching, isError, isLoading } = useGetSubscriptionListQuery()

  return (
    <>
      <PageHeader heading="Subscriptions" count={data?.length} />

      <Container>
        <RenderContent loading={isLoading} error={isError}>
          <DataGrid hideFooter loading={isFetching} columns={columns} rows={data || []} />
        </RenderContent>
      </Container>
    </>
  )
}

Subscriptions.rootLayoutProps = {
  title: 'Subscriptions',
  pageType: 'protected',
  module: {
    id: 5,
    permission: 'view',
  },
}

export default Subscriptions

import * as yup from 'yup'
import { stringTest } from '@/utils'

export const schema = yup.object({
  currencyId: yup.number().required(),
  name: yup.string().trim().required().min(2).max(100).test(stringTest),
  priceId: yup.string().required().max(300),
  duration: yup.number().required().positive().max(300),
  amount: yup.number().required().min(0).max(1000000),
  isAccommodationEnabled: yup.boolean().required().defined(),
  isAccreditationEnabled: yup.boolean().required().defined(),
  isTicketingSystemEnabled: yup.boolean().required().defined(),
  isVisaEnabled: yup.boolean().required().defined(),
  noOfEvents: yup.number().required().min(0).max(1000000),
  noOfStaffs: yup.number().required().min(0).max(1000000),
})

export type TSchema = yup.InferType<typeof schema>

import { SubscriptionPlanDTO } from '@/dto'

export type SubscriptionFormProps = {
  data: SubscriptionPlanDTO
}

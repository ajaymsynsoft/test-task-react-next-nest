import { useRouter } from 'next/router'
import { LoadingButton } from '@mui/lab'
import { Divider, FormControl, FormControlLabel, FormHelperText, Grid, InputAdornment, InputLabel, MenuItem, Select, Stack, Switch } from '@mui/material'
import { Controller, useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'

import InputField from '@/components/_ui/inputField/InputField.component'
import { SubscriptionFormProps } from './SubscriptionForm.type'
import { TSchema, schema } from './SubscriptionForm.config'
import { useUpdateSubscriptionMutation } from '@/redux/api/subscription.api'

export default function SubscriptionForm({ data }: SubscriptionFormProps) {
  const router = useRouter()
  const [updateSubscription] = useUpdateSubscriptionMutation()

  const {
    handleSubmit,
    control,
    formState: { isSubmitting },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      currencyId: 1,
      name: data.name,
      duration: data.duration,
      amount: data.amount,
      isAccommodationEnabled: data.isAccommodationEnabled,
      isAccreditationEnabled: data.isAccreditationEnabled,
      isTicketingSystemEnabled: data.isTicketingSystemEnabled,
      isVisaEnabled: data.isVisaEnabled,
      noOfEvents: data.noOfEvents,
      noOfStaffs: data.noOfStaffs,
      priceId: data.priceId,
    },
  })

  const onSubmit = async (formData: TSchema) => {
    await updateSubscription({ ...formData, id: Number(router.query.id) }).unwrap()
    router.push('/dashboard/subscriptions')
  }

  return (
    <Grid container component="form" noValidate onSubmit={handleSubmit(onSubmit)} spacing={2}>
      {/* Plan Name  */}
      <Grid item xs={12} md={12}>
        <InputField name="name" label="Plan name *" control={control} />
      </Grid>

      {/* Package Duration */}
      <Grid item xs={12} sm={6}>
        <InputField
          name="duration"
          label="Plan duration *"
          type="number"
          control={control}
          InputProps={{
            endAdornment: <InputAdornment position="end">Month</InputAdornment>,
          }}
        />
      </Grid>

      {/* Plan Amount */}
      <Grid item xs={12} sm={6}>
        <InputField
          name="amount"
          label="Plan amount *"
          type="number"
          control={control}
          InputProps={{
            endAdornment: <InputAdornment position="end">$</InputAdornment>,
          }}
        />
      </Grid>

      {/* No Of Events */}
      <Grid item xs={12} sm={6}>
        <InputField name="noOfEvents" label="No of events *" type="number" control={control} />
      </Grid>

      {/* No Of Staffs */}
      <Grid item xs={12} sm={6}>
        <InputField name="noOfStaffs" label="No of staff *" type="number" control={control} />
      </Grid>

      {/* Price Id */}
      <Grid item xs={12} sm={12}>
        <InputField name="priceId" label="Price id *" control={control} />
      </Grid>

      <Grid item xs={12}>
        <Stack divider={<Divider />} gap={1}>
          {/* Ticketing System */}
          <Controller
            name="isTicketingSystemEnabled"
            control={control}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <FormControl error={!!error}>
                <FormControlLabel
                  label="Ticketing system"
                  labelPlacement="start"
                  sx={{ ml: 0, justifyContent: 'space-between' }}
                  componentsProps={{ typography: { color: error ? 'error.main' : undefined } }}
                  control={<Switch {...restField} inputRef={ref} checked={value} onChange={(_, checked) => onChange(checked)} />}
                />
                <FormHelperText>{error?.message}</FormHelperText>
              </FormControl>
            )}
          />

          {/* Enabled Accreditation */}
          <Controller
            name="isAccreditationEnabled"
            control={control}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <FormControl error={!!error}>
                <FormControlLabel
                  label="Accreditation system"
                  labelPlacement="start"
                  sx={{ ml: 0, justifyContent: 'space-between' }}
                  componentsProps={{ typography: { color: error ? 'error.main' : undefined } }}
                  control={<Switch {...restField} inputRef={ref} checked={value} onChange={(_, checked) => onChange(checked)} />}
                />
                <FormHelperText>{error?.message}</FormHelperText>
              </FormControl>
            )}
          />

          {/* Enabled Visa */}
          <Controller
            name="isVisaEnabled"
            control={control}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <FormControl error={!!error}>
                <FormControlLabel
                  label="Visa management"
                  labelPlacement="start"
                  sx={{ ml: 0, justifyContent: 'space-between' }}
                  componentsProps={{ typography: { color: error ? 'error.main' : undefined } }}
                  control={<Switch {...restField} inputRef={ref} checked={value} onChange={(_, checked) => onChange(checked)} />}
                />
                <FormHelperText>{error?.message}</FormHelperText>
              </FormControl>
            )}
          />

          {/* Accommodation System */}
          <Controller
            name="isAccommodationEnabled"
            control={control}
            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
              <FormControl error={!!error}>
                <FormControlLabel
                  label="Accommodation management"
                  labelPlacement="start"
                  sx={{ ml: 0, justifyContent: 'space-between' }}
                  componentsProps={{ typography: { color: error ? 'error.main' : undefined } }}
                  control={<Switch {...restField} inputRef={ref} checked={value} onChange={(_, checked) => onChange(checked)} />}
                />
                <FormHelperText>{error?.message}</FormHelperText>
              </FormControl>
            )}
          />
        </Stack>
      </Grid>

      {/* Footer */}
      <Grid item xs={12}>
        <Stack direction="row" justifyContent="end">
          <LoadingButton loading={isSubmitting} variant="contained" type="submit">
            Update
          </LoadingButton>
        </Stack>
      </Grid>
    </Grid>
  )
}

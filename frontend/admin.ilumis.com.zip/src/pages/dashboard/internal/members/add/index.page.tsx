import { Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import MemberForm from '../components/memberForm/MemberForm.component'
import { Page } from '@/types'

const AddMember: Page = () => {
  return (
    <>
      <PageHeader heading="Add Member" backUrl="/dashboard/internal/members" />

      <Container>
        <MemberForm isEditMode={false} />
      </Container>
    </>
  )
}

AddMember.rootLayoutProps = {
  title: 'Add Member',
  pageType: 'protected',
  module: {
    id: 20,
    permission: 'add',
  },
}

export default AddMember

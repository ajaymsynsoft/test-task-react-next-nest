import Link from 'next/link'
import { Button, Container } from '@mui/material'
import { DataGrid } from '@mui/x-data-grid'
import { MdAdd } from 'react-icons/md'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { usePagination, useReduxSelector } from '@/hooks'
import { useGetInternalMemberListQuery } from '@/redux/api/internalMember.api'
import { useColumns } from './Members.hook'

const Members: Page = () => {
  const columns = useColumns()
  const { modules } = useReduxSelector((state) => state.layout.profile)
  const { paginationModel, setPaginationModel, page, pageSize } = usePagination()
  const { data, isFetching, isError, isLoading } = useGetInternalMemberListQuery({ pageNo: page, pageSize })

  return (
    <>
      {/* Page Header */}
      <PageHeader
        heading="Internal Members"
        count={data?.totalCount}
        actions={
          modules[20].permissions.add && (
            <Button href="/dashboard/internal/members/add" variant="contained" startIcon={<MdAdd />} LinkComponent={Link}>
              Add Member
            </Button>
          )
        }
      />

      <Container>
        <RenderContent loading={isLoading} error={isError}>
          <DataGrid loading={isFetching} columns={columns} rowCount={data?.totalCount || 0} rows={data?.list || []} paginationModel={paginationModel} onPaginationModelChange={setPaginationModel} />
        </RenderContent>
      </Container>
    </>
  )
}

Members.rootLayoutProps = {
  title: 'Members',
  pageType: 'protected',
  module: {
    id: 20,
    permission: 'view',
  },
}

export default Members

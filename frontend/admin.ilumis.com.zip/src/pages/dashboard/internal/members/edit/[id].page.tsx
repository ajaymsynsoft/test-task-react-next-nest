import { Container } from '@mui/material'
import { useRouter } from 'next/router'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import MemberForm from '../components/memberForm/MemberForm.component'
import { Page } from '@/types'
import { useGetInternalMemberQuery } from '@/redux/api/internalMember.api'

const EditMember: Page = () => {
  const router = useRouter()
  const { isFetching, isError, data } = useGetInternalMemberQuery(Number(router.query.id))

  return (
    <>
      <PageHeader heading="Edit Member" backUrl="/dashboard/internal/members" />

      <Container>
        <RenderContent loading={isFetching} error={isError}>
          {data && <MemberForm isEditMode data={data} />}
        </RenderContent>
      </Container>
    </>
  )
}

EditMember.rootLayoutProps = {
  title: 'Edit Member',
  pageType: 'protected',
  module: {
    id: 20,
    permission: 'edit',
  },
}

export default EditMember

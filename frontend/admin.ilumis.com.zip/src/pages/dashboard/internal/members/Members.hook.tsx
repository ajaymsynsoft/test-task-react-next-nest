import Link from 'next/link'
import Image from 'next/image'
import { useState } from 'react'
import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'
import { Link as MuiLink } from '@mui/material'
import { MdDelete, MdEdit } from 'react-icons/md'
import { useRouter } from 'next/router'

import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import { InternalMemberDTO } from '@/dto'
import { useReduxSelector } from '@/hooks'
import { useDeleteInternalMemberMutation } from '@/redux/api/internalMember.api'

export const useColumns = () => {
  const router = useRouter()
  const [deleteItemId, setDeleteItemId] = useState<number | null>(null)
  const { modules } = useReduxSelector((state) => state.layout.profile)
  const [deleteInternalMember, { isLoading }] = useDeleteInternalMemberMutation()

  const columns: GridColDef<InternalMemberDTO>[] = [
    {
      field: 'id',
      headerName: 'ID',
      sortable: false,
      minWidth: 85,
      width: 85,
      renderCell: ({ row }) => (
        <MuiLink component={Link} href={`/dashboard/internal/members/edit/${row.id}`}>
          #{row.id}
        </MuiLink>
      ),
    },
    {
      field: 'photo',
      headerName: 'Photo',
      sortable: false,
      minWidth: 70,
      width: 70,
      display: 'flex',
      renderCell: ({ row }) => <Image src={row.photo} width={40} height={40} alt="photo" style={{ borderRadius: '100%', aspectRatio: '1/1' }} />,
    },
    {
      field: 'name',
      headerName: 'Full Name',
      sortable: false,
      minWidth: 175,
      renderCell: ({ row }) => `${row.firstName} ${row.lastName}`,
    },
    {
      field: 'email',
      headerName: 'Email',
      sortable: false,
      flex: 1,
      minWidth: 200,
    },
    {
      field: 'role',
      headerName: 'Role',
      sortable: false,
      minWidth: 150,
    },
    {
      field: 'accessCode',
      headerName: 'Access Code',
      sortable: false,
      minWidth: 110,
    },
    {
      field: 'country',
      headerName: 'Country',
      sortable: false,
      minWidth: 150,
    },
    {
      field: 'actions',
      headerName: 'Actions',
      sortable: false,
      minWidth: 80,
      width: 80,
      align: 'center',
      type: 'actions',
      getActions: ({ row }) => {
        const actions = []

        if (modules[20].permissions.edit) actions.push(<GridActionsCellItem showInMenu key="edit" label="Edit" onClick={(_) => router.push(`/dashboard/internal/members/edit/${row.id}`)} icon={<MdEdit />} />)

        if (modules[20].permissions.delete)
          actions.push(
            <GridActionsCellItem showInMenu key="delete" label="Delete" icon={<MdDelete />} onClick={() => setDeleteItemId(row.id)} />,
            <ConfirmationPopup
              key="deletePopup"
              heading="Delete member"
              subheading={`Sure to delete "${row.firstName} ${row.lastName}" member?`}
              acceptButtonText="Delete"
              loading={isLoading}
              open={row.id === deleteItemId}
              onCancel={() => setDeleteItemId(null)}
              onAccept={() =>
                deleteInternalMember(row.id)
                  .unwrap()
                  .then((_) => setDeleteItemId(null))
              }
            />,
          )

        return actions
      },
    },
  ]

  return columns
}

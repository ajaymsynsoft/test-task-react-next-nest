import * as yup from 'yup'
import { emailTest, fileTest, IMAGE_EXTENSIONS, stringTest } from '@/utils'

export const schema = yup.object({
  isEditMode: yup.boolean().required(),
  firstName: yup.string().trim().required().max(50).test(stringTest),
  lastName: yup.string().trim().required().max(50).test(stringTest),
  role: yup.string().trim().required().max(50).test(stringTest),
  email: yup.string().email().trim().required().max(300).test(emailTest),
  photo: yup
    .mixed<File | string>()
    .required()
    .test(fileTest({ required: true, size: 5, extensions: IMAGE_EXTENSIONS, message: { extensions: 'Only image file is accepted' } })),
  accessCode: yup.string().trim().required().max(50).test(stringTest),
  countryId: yup.number().required(),
})

export type TSchema = yup.InferType<typeof schema>

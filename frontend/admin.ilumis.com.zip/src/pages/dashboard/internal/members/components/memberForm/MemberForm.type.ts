import { InternalMemberDTO } from '@/dto'

export type MemberFormProps =
  | {
      isEditMode: false
      data?: void
    }
  | {
      isEditMode: true
      data: InternalMemberDTO
    }

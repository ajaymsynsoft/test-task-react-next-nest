import { useRouter } from 'next/router'
import { LoadingButton } from '@mui/lab'
import { Autocomplete, Grid, Stack, TextField } from '@mui/material'
import { Controller, useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'

import InputField from '@/components/_ui/inputField/InputField.component'
import UploadField from '@/components/_ui/uploadField/UploadField.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { TSchema, schema } from './MemberForm.config'
import { MemberFormProps } from './MemberForm.type'
import { useGetCountriesQuery, useUploadFileMutation } from '@/redux/api/common.api'
import { useAddInternalMemberMutation, useUpdateInternalMemberMutation } from '@/redux/api/internalMember.api'

export default function MemberForm({ isEditMode, data }: MemberFormProps) {
  const router = useRouter()

  const countriesApiState = useGetCountriesQuery()
  const [uploadFile] = useUploadFileMutation()
  const [addInternalMember] = useAddInternalMemberMutation()
  const [updateInternalMember] = useUpdateInternalMemberMutation()

  const {
    handleSubmit,
    control,
    formState: { isSubmitting },
    getValues,
    setValue,
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      isEditMode,
      ...(isEditMode && {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        role: data.role,
        accessCode: data.accessCode,
        countryId: data.countryId,
        photo: data.photo,
      }),
    },
  })

  const onSubmit = async () => {
    const formData = schema.validateSync(getValues())

    if (formData.photo instanceof File) {
      const [image] = await uploadFile({ files: formData.photo, folderName: 'internalMember' }).unwrap()
      formData.photo = image
      setValue('photo', image)
    }

    if (isEditMode) await updateInternalMember({ ...formData, id: Number(router.query.id), photo: formData.photo }).unwrap()
    else await addInternalMember({ ...formData, photo: formData.photo }).unwrap()

    router.push('/dashboard/internal/members')
  }

  return (
    <RenderContent loading={countriesApiState.isLoading} error={countriesApiState.isError}>
      {countriesApiState.isSuccess && (
        <Grid container component="form" noValidate onSubmit={handleSubmit(onSubmit)} spacing={2}>
          <Grid item container spacing={2} xs={12} sm={6}>
            {/* First Name  */}
            <Grid item xs={12}>
              <InputField name="firstName" label="First name *" control={control} />
            </Grid>

            {/* Last Name */}
            <Grid item xs={12}>
              <InputField name="lastName" label="Last name *" control={control} />
            </Grid>

            {/* Email */}
            <Grid item xs={12}>
              <InputField name="email" label="Email *" control={control} disabled={isEditMode} />
            </Grid>
          </Grid>

          <Grid item container spacing={2} xs={12} sm={6}>
            {/* Profile Photo */}
            <Grid item xs={12}>
              <UploadField name="photo" label="Personal photo *" heading="Upload personal photo" description="Required for accreditation" control={control} accept={{ 'image/*': [] }} />
            </Grid>
          </Grid>

          {/* Role  */}
          <Grid item xs={12} sm={6}>
            <InputField name="role" label="Role *" control={control} />
          </Grid>

          {/* Access Code  */}
          <Grid item xs={12} sm={6}>
            <InputField
              name="accessCode"
              label="Access Code *"
              control={control}
              onChange={(event, field, value) => {
                field.onChange(event.target.value.toUpperCase())
              }}
            />
          </Grid>

          {/* Country */}
          <Grid item xs={12}>
            <Controller
              name="countryId"
              control={control}
              render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                <Autocomplete
                  {...restField}
                  options={countriesApiState.data || []}
                  value={countriesApiState.data!.find((item) => item.id === value) || null}
                  onChange={(_, value) => onChange(value?.id)}
                  getOptionLabel={(option) => option.name}
                  renderInput={(params) => <TextField {...params} label="Country *" inputRef={ref} error={!!error} helperText={error?.message} inputProps={{ ...params.inputProps, autoComplete: 'new-password' }} />}
                />
              )}
            />
          </Grid>

          {/* Footer */}
          <Grid item xs={12}>
            <Stack direction="row" justifyContent="end" gap={1}>
              <LoadingButton variant="text" disabled={isSubmitting} onClick={() => router.push('/dashboard/internal/members')}>
                Cancel
              </LoadingButton>
              <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
                {isEditMode ? 'Update' : 'Save'}
              </LoadingButton>
            </Stack>
          </Grid>
        </Grid>
      )}
    </RenderContent>
  )
}

import moment from 'moment'
import Link from 'next/link'
import { useRouter } from 'next/router'
import { DataGrid } from '@mui/x-data-grid'
import { MdAdd } from 'react-icons/md'
import { DatePicker } from '@mui/x-date-pickers'
import { Autocomplete, Button, Container, Grid, TextField } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { usePagination, useReduxSelector, useUrlParams } from '@/hooks'
import { validateDate } from '@/utils'
import { useColumns } from './InternalBookings.hook'
import { useGetInternalBookingListQuery } from '@/redux/api/internalBooking.api'
import { useGetEventNameListQuery } from '@/redux/api/event.api'

const InternalBookings: Page = () => {
  const router = useRouter()
  const columns = useColumns()
  const { modules } = useReduxSelector((state) => state.layout.profile)
  const { setUrlParams } = useUrlParams()
  const { paginationModel, setPaginationModel, page, pageSize } = usePagination()

  const filter = {
    eventId: router.query.eventId as string,
    orderDate: router.query.orderDate as string,
  }

  const { data, isFetching, isError, isLoading } = useGetInternalBookingListQuery({ pageNo: page, pageSize, ...filter })
  const eventListApiState = useGetEventNameListQuery()

  return (
    <>
      {/* Page Header */}
      <PageHeader
        heading="Internal Bookings"
        count={data?.totalCount}
        actions={
          modules[22].permissions.add && (
            <Button href="/dashboard/internal/bookings/add" variant="contained" startIcon={<MdAdd />} LinkComponent={Link}>
              Add Booking
            </Button>
          )
        }
      />

      <Container>
        {/* Filter */}
        <Grid container mb={3} spacing={2}>
          {/* Select Event */}
          <Grid item xs={12} md={6} lg={4}>
            <Autocomplete
              noOptionsText="No events"
              disableClearable={false}
              loading={eventListApiState.isLoading}
              options={eventListApiState.data || []}
              value={eventListApiState.data?.find((item) => item.id === Number(filter.eventId)) || null}
              getOptionLabel={(option) => option.name}
              onChange={(_, value) => setUrlParams({ params: { eventId: value?.id } })}
              renderInput={(params) => <TextField {...params} label="Event" />}
            />
          </Grid>

          {/* Select Date */}
          <Grid item xs={12} md={6} lg={4}>
            <DatePicker
              label="Order date"
              value={filter.orderDate ? moment(filter.orderDate) : null}
              onChange={(value) => setUrlParams({ params: { orderDate: validateDate(value) ? value?.toISOString() : '' } })}
              slotProps={{ popper: { disablePortal: true } }}
            />
          </Grid>
        </Grid>

        {/* Table */}
        <RenderContent loading={isLoading} error={isError}>
          <DataGrid loading={isFetching} columns={columns} rowCount={data?.totalCount || 0} rows={data?.list || []} paginationModel={paginationModel} onPaginationModelChange={setPaginationModel} />
        </RenderContent>
      </Container>
    </>
  )
}

InternalBookings.rootLayoutProps = {
  title: 'Internal Bookings',
  pageType: 'protected',
  module: {
    id: 22,
    permission: 'view',
  },
}

export default InternalBookings

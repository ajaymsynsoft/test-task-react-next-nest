import { useRouter } from 'next/router'
import { Box, Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import InternalBookingForm from '../components/internalBookingForm/InternalBookingForm.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { useGetInternalBookingQuery } from '@/redux/api/internalBooking.api'

const ViewInternalBooking: Page = () => {
  const router = useRouter()
  const { isFetching, isError, data, isSuccess } = useGetInternalBookingQuery(Number(router.query.id))

  return (
    <>
      <PageHeader
        heading={
          <>
            Internal Booking{' '}
            <Box component="span" color="text.disabled" ml={1}>
              #{router.query.id}
            </Box>
          </>
        }
        backUrl="/dashboard/internal/bookings"
      />

      <Container>
        <RenderContent loading={isFetching} error={isError}>
          {isSuccess && <InternalBookingForm mode="view" data={data} />}
        </RenderContent>
      </Container>
    </>
  )
}

ViewInternalBooking.rootLayoutProps = {
  title: 'View Internal Booking',
  pageType: 'protected',
  module: {
    id: 22,
    permission: 'view',
  },
}

export default ViewInternalBooking

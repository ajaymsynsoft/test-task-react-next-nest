import { Container } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import InternalBookingForm from '../components/internalBookingForm/InternalBookingForm.component'
import { Page } from '@/types'

const AddInternalBooking: Page = () => {
  return (
    <>
      <PageHeader heading="Add Internal Booking" backUrl="/dashboard/internal/bookings" />

      <Container>
        <InternalBookingForm mode="add" />
      </Container>
    </>
  )
}

AddInternalBooking.rootLayoutProps = {
  title: 'Add Internal Booking',
  pageType: 'protected',
  module: {
    id: 22,
    permission: 'add',
  },
}

export default AddInternalBooking

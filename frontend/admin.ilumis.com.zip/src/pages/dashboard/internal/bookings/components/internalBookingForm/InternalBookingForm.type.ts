import { InternalBookingDTO } from '@/dto'

export type InternalBookingFormProps =
  | {
      mode: 'add'
      data?: void
    }
  | {
      mode: 'view'
      data: InternalBookingDTO
    }

import moment from 'moment'
import { useEffect } from 'react'
import { useRouter } from 'next/router'
import { LoadingButton } from '@mui/lab'
import { MobileDatePicker } from '@mui/x-date-pickers'
import { Controller, useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { Autocomplete, Card, Divider, Fade, FormControl, FormControlLabel, FormHelperText, FormLabel, Grid, Radio, RadioGroup, Stack, Switch, TextField, Typography } from '@mui/material'

import RenderContent from '@/components/renderContent/RenderContent.component'
import MemberInfoCard from '@/components/_card/memberInfoCard/MemberInfoCard.compoent'
import HotelInfoCard from '@/components/_card/hotelInfoCard/HotelInfoCard.compoent'
import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import { useReduxSelector } from '@/hooks'
import { TSchema, schema } from './InternalBookingForm.config'
import { InternalBookingFormProps } from './InternalBookingForm.type'
import { useGetInternalMemberListQuery } from '@/redux/api/internalMember.api'
import { useGetEventNameListQuery, useLazyGetEventQuery } from '@/redux/api/event.api'
import { useAddInternalBookingMutation } from '@/redux/api/internalBooking.api'

export default function InternalBookingForm({ data, mode }: InternalBookingFormProps) {
  const router = useRouter()
  const isViewMode = mode === 'view'
  const organization = useReduxSelector((state) => state.organization)

  const memberListApiState = useGetInternalMemberListQuery({ pageNo: 1, pageSize: 1000 })
  const eventListApiState = useGetEventNameListQuery()
  const [getEvent, eventApiState] = useLazyGetEventQuery()
  const [addInternalBooking] = useAddInternalBookingMutation()

  const {
    handleSubmit,
    control,
    watch,
    getValues,
    formState: { isSubmitting },
    resetField,
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      visaAssistanceRequired: false,
      visaOfficialLetterRequired: false,
      ...(isViewMode && {
        eventId: data.eventId,
        memberId: data.member.id,
        hotelId: data.hotelId,
        hotelRoomTypeId: data.hotelRoomTypeId,
        fromDate: data.fromDate,
        toDate: data.toDate,
        visaAssistanceRequired: data.visaAssistanceRequired,
        visaOfficialLetterRequired: data.visaOfficialLetterRequired,
      }),
    },
  })

  const filteredHotels = eventApiState.data?.hotels.filter((hotel) => hotel.roomType.filter((room) => room.status === 'active').length) || []
  const selectedHotel = filteredHotels.find((item) => item.id === watch('hotelId'))

  useEffect(() => {
    if (watch('eventId')) getEvent({ eventId: watch('eventId') }, true)
  }, [watch('eventId')])

  const onSubmit = async () => {
    if (mode !== 'add') return

    const formData = schema.validateSync(getValues())

    if (!formData.hotelId) {
      formData.fromDate = undefined
      formData.toDate = undefined
    }

    await addInternalBooking(formData).unwrap()

    router.push('/dashboard/internal/bookings')
  }

  return (
    <RenderContent
      loading={memberListApiState.isLoading || eventListApiState.isLoading || (isViewMode ? eventApiState.isLoading : false)}
      error={memberListApiState.isError || eventListApiState.isError || eventApiState.isError}
    >
      {memberListApiState.isSuccess && eventListApiState.isSuccess && (
        <Grid container component="form" noValidate onSubmit={handleSubmit(onSubmit)} spacing={2}>
          {/* Select Member */}
          <Grid item xs={12} sm={6}>
            <Controller
              name="memberId"
              control={control}
              render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                <Autocomplete
                  {...restField}
                  readOnly={isViewMode}
                  value={value ? memberListApiState.data.list.find((item) => item.id === value) : null}
                  options={memberListApiState.data.list}
                  onChange={(_, value) => onChange(value?.id)}
                  getOptionLabel={(option) => `${option.firstName} ${option.lastName}`}
                  isOptionEqualToValue={(option, value) => option.id === value.id}
                  getOptionKey={(option) => option.id}
                  renderInput={(params) => <TextField {...params} label="Select member *" inputRef={ref} error={!!error} helperText={error?.message} />}
                  renderOption={(props, option) => (
                    <li {...props} key={props.key}>
                      <MemberInfoCard data={option} />
                    </li>
                  )}
                />
              )}
            />
          </Grid>

          {/* Select Event */}
          <Grid item xs={12} sm={6}>
            <Controller
              name="eventId"
              control={control}
              render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                <Autocomplete
                  {...restField}
                  readOnly={isViewMode}
                  value={value ? eventListApiState.data.find((item) => item.id === value) : null}
                  options={eventListApiState.data}
                  onChange={(_, value) => {
                    onChange(value?.id)
                    resetField('hotelId')
                    resetField('hotelRoomTypeId')
                    resetField('fromDate')
                    resetField('toDate')
                  }}
                  getOptionLabel={(option) => option.name}
                  renderInput={(params) => <TextField {...params} label="Select event *" inputRef={ref} error={!!error} helperText={error?.message} />}
                />
              )}
            />
          </Grid>

          {!eventApiState.isUninitialized && (
            <Grid item xs={12}>
              <RenderContent loading={eventApiState.isFetching} error={eventApiState.isError}>
                {eventApiState.isSuccess && (
                  <Grid container spacing={2}>
                    {/* Select Hotel */}
                    <Grid item xs={12}>
                      <Controller
                        name="hotelId"
                        control={control}
                        render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                          <Autocomplete
                            {...restField}
                            readOnly={isViewMode}
                            value={value ? filteredHotels.find((item) => item.id === value) : null}
                            options={filteredHotels}
                            disableClearable={false}
                            onChange={(_, value) => {
                              onChange(value?.id)
                              resetField('hotelRoomTypeId')
                            }}
                            getOptionLabel={(option) => option.name}
                            isOptionEqualToValue={(option, value) => option.id === value.id}
                            getOptionKey={(option) => option.id}
                            renderInput={(params) => <TextField {...params} label="Select hotel" inputRef={ref} error={!!error} helperText={error?.message} />}
                            renderOption={(props, option) => (
                              <li {...props} key={props.key}>
                                <HotelInfoCard data={option} />
                              </li>
                            )}
                          />
                        )}
                      />
                    </Grid>

                    {watch('hotelId') && (
                      <>
                        {/* Room Type */}
                        <Grid item xs={12}>
                          <Controller
                            name="hotelRoomTypeId"
                            control={control}
                            defaultValue={null as any}
                            render={({ fieldState: { error }, field: { ref, onChange, ...restField } }) => (
                              <Fade in key={watch('hotelId')} timeout={500}>
                                <FormControl error={!!error}>
                                  <FormLabel sx={{ fontWeight: 500 }}>Select room type *</FormLabel>
                                  <RadioGroup {...restField} onChange={(_, value) => !isViewMode && onChange(value)}>
                                    {selectedHotel!.roomType
                                      .filter((item) => item.status === 'active')
                                      .map((item, index) => (
                                        <FormControlLabel
                                          key={index}
                                          inputRef={ref}
                                          value={item.id}
                                          control={<Radio size="small" />}
                                          label={
                                            <Stack direction="row" gap={1} alignItems="center">
                                              {item.roomSize}{' '}
                                              <Typography variant="body2">
                                                (<DisplayPrice price={item.nightPrice} /> per person per night)
                                              </Typography>
                                            </Stack>
                                          }
                                        />
                                      ))}
                                  </RadioGroup>
                                  <FormHelperText>{error?.message}</FormHelperText>
                                </FormControl>
                              </Fade>
                            )}
                          />
                        </Grid>

                        {/* From Date */}
                        <Grid item xs={12} sm={6}>
                          <Controller
                            name="fromDate"
                            control={control}
                            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                              <MobileDatePicker
                                {...restField}
                                readOnly={isViewMode}
                                label="From *"
                                inputRef={ref}
                                minDate={moment(eventApiState.data.startDate).subtract(1, 'weeks')}
                                maxDate={moment(eventApiState.data.endDate).add(1, 'weeks')}
                                value={value ? moment(value) : null}
                                onChange={(value) => onChange(value?.toISOString())}
                                slotProps={{
                                  textField: { error: !!error, helperText: error?.message },
                                }}
                              />
                            )}
                          />
                        </Grid>

                        {/* To Date */}
                        <Grid item xs={12} sm={6}>
                          <Controller
                            name="toDate"
                            control={control}
                            render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                              <MobileDatePicker
                                {...restField}
                                readOnly={isViewMode}
                                label="To *"
                                inputRef={ref}
                                minDate={moment(eventApiState.data.startDate).subtract(1, 'weeks')}
                                maxDate={moment(eventApiState.data.endDate).add(1, 'weeks')}
                                value={value ? moment(value) : null}
                                onChange={(value) => onChange(value?.toISOString())}
                                slotProps={{
                                  textField: { error: !!error, helperText: error?.message },
                                }}
                              />
                            )}
                          />
                        </Grid>
                      </>
                    )}
                  </Grid>
                )}
              </RenderContent>
            </Grid>
          )}

          <Grid item xs={12}>
            <Stack divider={<Divider />} gap={1} component={Card} variant="outlined" elevation={0} sx={{ p: 1.5, bgcolor: 'transparent' }}>
              {/* Visa Assistance */}
              <Controller
                name="visaAssistanceRequired"
                control={control}
                render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                  <FormControl error={!!error}>
                    <FormControlLabel
                      label={
                        <Stack direction="row" alignItems="center" columnGap={1} flexWrap="wrap">
                          Visa assistance require
                          <Typography variant="body1" color="text.disabled">
                            (fees <DisplayPrice price={organization.visaFees} />)
                          </Typography>
                        </Stack>
                      }
                      labelPlacement="start"
                      sx={{ ml: 0, justifyContent: 'space-between' }}
                      componentsProps={{ typography: { color: error ? 'error.main' : undefined } }}
                      control={<Switch {...restField} inputRef={ref} checked={value} onChange={(_, checked) => !isViewMode && onChange(checked)} />}
                    />
                    <FormHelperText>{error?.message}</FormHelperText>
                  </FormControl>
                )}
              />

              {/* Official Visa Letter */}
              <Controller
                name="visaOfficialLetterRequired"
                control={control}
                render={({ fieldState: { error }, field: { ref, value, onChange, ...restField } }) => (
                  <FormControl error={!!error}>
                    <FormControlLabel
                      label={
                        <Stack direction="row" alignItems="center" columnGap={1} flexWrap="wrap">
                          Official visa letter require
                          <Typography variant="body1" color="text.disabled">
                            (fees <DisplayPrice price={0} />)
                          </Typography>
                        </Stack>
                      }
                      labelPlacement="start"
                      sx={{ ml: 0, justifyContent: 'space-between' }}
                      componentsProps={{ typography: { color: error ? 'error.main' : undefined } }}
                      control={<Switch {...restField} inputRef={ref} checked={value} onChange={(_, checked) => !isViewMode && onChange(checked)} />}
                    />
                    <FormHelperText>{error?.message}</FormHelperText>
                  </FormControl>
                )}
              />
            </Stack>
          </Grid>

          {/* Footer */}
          {mode === 'add' && (
            <Grid item xs={12}>
              <Stack direction="row" justifyContent="end" gap={1}>
                <LoadingButton variant="text" disabled={isSubmitting} onClick={() => router.push('/dashboard/internal/bookings')}>
                  Cancel
                </LoadingButton>
                <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
                  Save
                </LoadingButton>
              </Stack>
            </Grid>
          )}
        </Grid>
      )}
    </RenderContent>
  )
}

import * as yup from 'yup'
import moment from 'moment'

export const schema = yup.object({
  memberId: yup.number().required(),
  eventId: yup.number().required(),
  hotelId: yup.number(),
  hotelRoomTypeId: yup.number().when('hotelId', {
    is: (value: number) => !!value,
    then: (schema) => schema.required(),
  }),
  fromDate: yup.string().when('hotelId', {
    is: (value: number) => !!value,
    then: (schema) => schema.required(),
  }),
  toDate: yup
    .string()
    .when('hotelId', {
      is: (value: number) => !!value,
      then: (schema) => schema.required(),
    })
    .test('validate', 'It must be greater than "From date"', function (toDate) {
      const fromDate = this.parent.fromDate
      if (fromDate && toDate) return moment(toDate).isAfter(fromDate)
      return true
    }),
  visaAssistanceRequired: yup.boolean().required(),
  visaOfficialLetterRequired: yup.boolean().required(),
})

export type TSchema = yup.InferType<typeof schema>

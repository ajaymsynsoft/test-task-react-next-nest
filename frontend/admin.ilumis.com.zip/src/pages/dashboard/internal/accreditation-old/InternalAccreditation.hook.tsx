import moment from 'moment'
import Link from 'next/link'
import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'
import { Card, CardContent, Link as MuiLink, Tooltip } from '@mui/material'
import { MdRemoveRedEye } from 'react-icons/md'
import { useRouter } from 'next/router'

import SmartPopover from '@/components/smartPopover/SmartPopover.component'
import MemberInfoCard from '@/components/_card/memberInfoCard/MemberInfoCard.compoent'
import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import { InternalBookingDTO } from '@/dto'
import { useReduxSelector } from '@/hooks'

export const useColumns = () => {
  const router = useRouter()
  const { modules } = useReduxSelector((state) => state.layout.profile)

  const columns: GridColDef<InternalBookingDTO>[] = [
    {
      field: 'id',
      headerName: 'ID',
      sortable: false,
      minWidth: 85,
      width: 85,
      renderCell: ({ row }) => (
        <MuiLink component={Link} href={`/dashboard/internal/bookings/view/${row.id}`}>
          #{row.id}
        </MuiLink>
      ),
    },
    {
      field: 'event',
      headerName: 'Event',
      sortable: false,
      flex: 1,
      minWidth: 190,
      renderCell: ({ row }) => row.event.name,
    },
    {
      field: 'member',
      headerName: 'Member',
      sortable: false,
      minWidth: 200,
      renderCell: ({ row: { member } }) => (
        <SmartPopover>
          <SmartPopover.Toggle>
            <MuiLink color="text.secondary" noWrap>
              {member.firstName} {member.lastName}
            </MuiLink>
          </SmartPopover.Toggle>
          <SmartPopover.Content>
            <Card>
              <CardContent>
                <MemberInfoCard data={member} />
              </CardContent>
            </Card>
          </SmartPopover.Content>
        </SmartPopover>
      ),
    },
    {
      field: 'totalAmountInDisplayCurrency',
      headerName: 'Amount',
      sortable: false,
      minWidth: 130,
      display: 'flex',
      renderCell: ({ row }) => <DisplayPrice price={row.totalAmountInDisplayCurrency} />,
    },
    {
      field: 'orderDate',
      headerName: 'Order Date',
      sortable: false,
      minWidth: 125,
      renderCell: ({ row }) => (row.orderDate ? moment(row.orderDate).format() : ''),
    },
    {
      field: 'actions',
      headerName: 'Actions',
      sortable: false,
      minWidth: 80,
      width: 80,
      align: 'center',
      type: 'actions',
      getActions: ({ row }) => {
        const actions = []

        if (modules[22].permissions.view)
          actions.push(
            <Tooltip title="View booking" key="view">
              <GridActionsCellItem label="View booking" onClick={(_) => router.push(`/dashboard/internal/bookings/view/${row.id}`)} icon={<MdRemoveRedEye />} />
            </Tooltip>,
          )

        return actions
      },
    },
  ]

  return columns
}

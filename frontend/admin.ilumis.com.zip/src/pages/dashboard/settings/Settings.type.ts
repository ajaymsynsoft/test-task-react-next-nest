import { MenuOption } from '@/types'

export type TabType = Omit<MenuOption, 'children'> & {
  id: number
  content: JSX.Element
}

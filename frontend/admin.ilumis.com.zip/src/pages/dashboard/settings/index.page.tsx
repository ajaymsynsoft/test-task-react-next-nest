import React, { useState } from 'react'
import { useRouter } from 'next/router'
import { Container, Fade, Stack, Tab } from '@mui/material'
import { LoadingButton, TabContext, TabList, TabPanel } from '@mui/lab'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import { Page } from '@/types'
import { style } from './Settings.style'
import { TAB } from './Settings.config'
import { useReduxSelector, useUrlParams } from '@/hooks'
import { useCancelSubscriptionMutation } from '@/redux/api/subscription.api'
import { useGetOrganizationQuery } from '@/redux/api/organization.api'

const Settings: Page = () => {
  const router = useRouter()
  const organizationId = useReduxSelector((state) => state.organization.id)
  const { modules, role } = useReduxSelector((state) => state.layout.profile)
  const { setUrlParams } = useUrlParams()
  const [cancelSubscriptionPopup, setCancelSubscriptionPopup] = useState<boolean>(false)

  // TODO: test it
  const organizationApiState = useGetOrganizationQuery(organizationId, { skip: role !== 'admin' })
  const [cancelSubscription, cancelSubscriptionApiState] = useCancelSubscriptionMutation()

  const FILTERED_TAB = TAB.filter((item) => modules?.[Number(item.id)].permissions.view)
  const tab = String(router.query.tab || FILTERED_TAB[0].id)
  const hideTabHeader = role === 'customer'

  return (
    <>
      <PageHeader
        heading="Settings"
        sx={{ my: 0, borderColor: 'var(--border-color)' }}
        actions={
          organizationApiState.isSuccess && (
            <LoadingButton color="error" loading={cancelSubscriptionApiState.isLoading} onClick={() => setCancelSubscriptionPopup(true)}>
              Cancel Subscription
            </LoadingButton>
          )
        }
      />

      <TabContext value={tab}>
        {/* Tab Headings */}
        {!hideTabHeader && (
          <Stack sx={style.tabHeadings}>
            <Container>
              <TabList onChange={(_, value) => setUrlParams({ params: { tab: value } })}>
                {FILTERED_TAB.map((item, index) => (
                  <Tab key={index} iconPosition="start" label={item.label} value={String(item.id)} sx={style.tab} icon={item.Icon && <item.Icon />} />
                ))}
              </TabList>
            </Container>
          </Stack>
        )}

        {/* Tab Content */}
        <Container sx={{ pt: hideTabHeader ? 0 : 4 }}>
          {FILTERED_TAB.map((item, index) => (
            <React.Fragment key={index}>
              <Fade in key={tab} timeout={300}>
                <TabPanel value={String(item.id)}>{item.content}</TabPanel>
              </Fade>
            </React.Fragment>
          ))}
        </Container>

        {/* Confirm Cancel Subscription */}
        {cancelSubscriptionPopup && (
          <ConfirmationPopup
            heading="Cancel subscription"
            subheading="Sure to cancel your subscription plan?"
            acceptButtonText="Cancel Subscription"
            cancelButtonText="Close"
            loading={cancelSubscriptionApiState.isLoading}
            onCancel={() => setCancelSubscriptionPopup(false)}
            onAccept={() =>
              cancelSubscription({ subscriptionId: organizationApiState?.data!.subscriptionId! })
                .unwrap()
                .then(() => setCancelSubscriptionPopup(false))
            }
          />
        )}
      </TabContext>
    </>
  )
}

Settings.rootLayoutProps = {
  title: 'Settings',
  pageType: 'protected',
  module: {
    id: 11,
    permission: 'view',
  },
}

export default Settings

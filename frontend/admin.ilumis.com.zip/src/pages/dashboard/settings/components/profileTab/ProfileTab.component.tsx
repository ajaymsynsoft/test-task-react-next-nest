import ProfileForm from '@/components/_form/profileForm/ProfileForm.component'

export default function ProfileTab() {
  return <ProfileForm />
}

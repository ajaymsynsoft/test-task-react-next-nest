import toast from 'react-hot-toast'
import { yupResolver } from '@hookform/resolvers/yup'
import { Grid, Stack } from '@mui/material'
import { useForm } from 'react-hook-form'
import { LoadingButton } from '@mui/lab'
import { RiMastercardLine } from 'react-icons/ri'
import { MdOutlineAccountBalance } from 'react-icons/md'

import InputField from '@/components/_ui/inputField/InputField.component'
import TextEditorField from '@/components/_ui/textEditorField/TextEditorField.component'
import HeadingWithIcon from '@/components/_ui/headingWithIcon/HeadingWithIcon.component'
import { schema, TSchema } from './PaymentFrom.config'
import { useAddPaymentProviderMutation } from '@/redux/api/payment.api'
import { PaymentFormProps } from './PaymentFrom.type'
import { htmlToText } from '@/utils'

export default function PaymentForm({ data }: PaymentFormProps) {
  const [addPaymentProvider] = useAddPaymentProviderMutation()

  const {
    handleSubmit,
    control,
    getValues,
    trigger,
    formState: { isSubmitting, isSubmitted, isDirty },
    reset,
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      paymentMethod: 'master_card',
      ...(data
        ? {
            paymentMethod: data.paymentMethod,
            apiPassword: data.apiPassword,
            merchantId: data.merchantId,
            bankDetails: data.bankDetails,
          }
        : {}),
    },
  })

  const onSubmit = async () => {
    if (!isDirty) return toast.error('Please make a change to update')

    const formData = getValues()
    const isBankDetails = !!htmlToText(String(formData.bankDetails))
    if (!isBankDetails) formData.bankDetails = ''

    await addPaymentProvider(formData).unwrap()

    reset(getValues())
  }

  return (
    <Grid container component="form" noValidate onSubmit={handleSubmit(onSubmit)} spacing={2}>
      {/* Heading */}
      <Grid item xs={12}>
        <HeadingWithIcon Icon={RiMastercardLine} text="Master Card" />
      </Grid>

      {/* Merchant ID */}
      <Grid item xs={12}>
        <InputField
          name="merchantId"
          label="Merchant id"
          control={control}
          onChange={(e, field, value) => {
            field.onChange(value)
            isSubmitted && trigger('apiPassword')
          }}
        />
      </Grid>

      {/* API Password  */}
      <Grid item xs={12}>
        <InputField
          name="apiPassword"
          label="API password"
          control={control}
          onChange={(e, field, value) => {
            field.onChange(value)
            isSubmitted && trigger('merchantId')
          }}
        />
      </Grid>

      {/* Heading */}
      <Grid item xs={12} mt={2}>
        <HeadingWithIcon Icon={MdOutlineAccountBalance} text="Bank" />
      </Grid>

      {/* Bank Details */}
      <Grid item xs={12}>
        <TextEditorField name="bankDetails" placeholder="Enter bank details..." control={control} />
      </Grid>

      {/* Footer */}
      <Grid item xs={12}>
        <Stack direction="row" justifyContent="end">
          <LoadingButton loading={isSubmitting} variant="contained" type="submit">
            Update
          </LoadingButton>
        </Stack>
      </Grid>
    </Grid>
  )
}

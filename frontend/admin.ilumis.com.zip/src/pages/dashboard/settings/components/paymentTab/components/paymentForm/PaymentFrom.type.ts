import { PaymentProviderDTO } from '@/dto'

export type PaymentFormProps = {
  data: PaymentProviderDTO | undefined
}

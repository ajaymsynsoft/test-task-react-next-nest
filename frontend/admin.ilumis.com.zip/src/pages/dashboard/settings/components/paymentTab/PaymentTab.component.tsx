import PaymentForm from './components/paymentForm/PaymentForm.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { useGetPaymentProviderQuery } from '@/redux/api/payment.api'

export default function PaymentTab() {
  const { data, isLoading, isError } = useGetPaymentProviderQuery()

  return (
    <RenderContent loading={isLoading} error={isError}>
      <PaymentForm data={data} />
    </RenderContent>
  )
}

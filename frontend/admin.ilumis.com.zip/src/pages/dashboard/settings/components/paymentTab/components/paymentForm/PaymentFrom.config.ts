import * as yup from 'yup'
import { stringTest } from '@/utils'
import { PaymentProviderDTO } from '@/dto'

export const schema = yup.object({
  bankDetails: yup.string().trim().max(1000),
  paymentMethod: yup.string<PaymentProviderDTO['paymentMethod']>().required(),
  merchantId: yup
    .string()
    .trim()
    .max(300)
    .matches(/^\S*$/)
    .test('validate', 'Required *', function (value) {
      const apiPassword = this.parent.apiPassword
      if (apiPassword) return !!value
      return true
    }),
  apiPassword: yup
    .string()
    .trim()
    .max(300)
    .matches(/^\S*$/)
    .test(stringTest)
    .test('validate', 'Required *', function (value) {
      const merchantId = this.parent.merchantId
      if (merchantId) return !!value
      return true
    }),
})

export type TSchema = yup.InferType<typeof schema>

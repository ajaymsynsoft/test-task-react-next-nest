import ChangePasswordForm from '@/components/_form/changePasswordForm/ChangePasswordForm.component'

export default function PasswordTab() {
  return <ChangePasswordForm />
}

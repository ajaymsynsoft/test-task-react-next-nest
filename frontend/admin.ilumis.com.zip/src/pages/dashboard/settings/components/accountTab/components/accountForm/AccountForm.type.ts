import { OrganizationDTO } from '@/dto'

export type AccountFormProps = {
  data: OrganizationDTO
}

import AccountForm from './components/accountForm/AccountForm.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { useReduxSelector } from '@/hooks'
import { useGetOrganizationQuery } from '@/redux/api/organization.api'

export default function AccountTab() {
  const organizationId = useReduxSelector((state) => state.organization.id)
  const { isLoading, isError, isSuccess, data } = useGetOrganizationQuery(organizationId)

  return (
    <RenderContent loading={isLoading} error={isError}>
      {isSuccess && <AccountForm data={data} />}
    </RenderContent>
  )
}

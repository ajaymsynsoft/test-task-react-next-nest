import { LoadingButton } from '@mui/lab'
import { yupResolver } from '@hookform/resolvers/yup'
import { Controller, useForm } from 'react-hook-form'
import { MdOutlinePanoramaHorizontal, MdOutlinePayments } from 'react-icons/md'
import { FormControl, FormHelperText, Grid, InputAdornment, InputLabel, MenuItem, Select, Stack, Tooltip } from '@mui/material'

import InputField from '@/components/_ui/inputField/InputField.component'
import ImageField from '@/components/_ui/imageField/ImageField.component'
import PhoneField from '@/components/_ui/phoneField/PhoneField.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import ColorField from '@/components/_ui/colorField/ColorField.component'
import HeadingWithIcon from '@/components/_ui/headingWithIcon/HeadingWithIcon.component'
import { useReduxSelector } from '@/hooks'
import { useUploadFileMutation } from '@/redux/api/common.api'
import { TSchema, schema } from './AccountForm.config'
import { AccountFormProps } from './AccountForm.type'
import { useUpdateSettingsMutation } from '@/redux/api/organization.api'
import { useGetCurrenciesListQuery } from '@/redux/api/common.api'
import { useEffect } from 'react'

export default function AccountForm({ data }: AccountFormProps) {
  const [uploadFile] = useUploadFileMutation()
  const [updateSettings] = useUpdateSettingsMutation()
  const currenciesListApiState = useGetCurrenciesListQuery()
  const organization = useReduxSelector((state) => state.organization)
  const currencyCode = organization.displayCurrency.code

  const {
    handleSubmit,
    control,
    setValue,
    trigger,
    watch,
    formState: { isSubmitting, isSubmitted },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      status: data.status,
      organizationName: data.organizationName,
      email: data.email,
      phone: data.phone,
      website: data.website,
      logo: data.logo,
      theme: data.theme,
      currencyId: data.defaultCurrency?.id,
      displayCurrencyId: data.displayCurrency?.id,
      displayCurrencyRate: data.displayCurrencyRate,
      bannerHeading: data.bannerHeading || '',
      bannerSubHeading: data.bannerSubHeading || '',
      bannerImage: data.bannerImage,
      visaFees: data.visaFees,
      domainName: data.domainName,
    },
  })

  useEffect(() => {
    if (isSubmitted) trigger('bannerHeading')
  }, [watch('bannerImage'), isSubmitted])

  const onSubmit = async (formData: TSchema) => {
    if (formData.bannerImage instanceof File) {
      const [image] = await uploadFile({ files: formData.bannerImage, folderName: 'organization' }).unwrap()
      formData.bannerImage = image
      setValue('bannerImage', image)
    }

    if (formData.logo instanceof File) {
      const [image] = await uploadFile({ files: formData.logo, folderName: 'organization' }).unwrap()
      formData.logo = image
      setValue('logo', image)
    }

    await updateSettings({ ...formData, logo: formData.logo, bannerImage: formData.bannerImage }).unwrap()
  }

  return (
    <RenderContent loading={currenciesListApiState.isFetching} error={currenciesListApiState.isError}>
      <Grid container component="form" noValidate onSubmit={handleSubmit(onSubmit)} spacing={2}>
        <Grid container item xs={12} sm={9} spacing={2} alignContent="start">
          {/* Organization Name */}
          <Grid item xs={12}>
            <InputField name="organizationName" label="Organization name *" control={control} />
          </Grid>

          {/* Select Color */}
          <Grid item xs={12}>
            <ColorField name="theme.color.primary" control={control} />
          </Grid>
        </Grid>

        {/* Logo */}
        <Grid item xs={12} sm={3}>
          <ImageField name="logo" label="Organization logo *" control={control} />
        </Grid>

        {/* Email */}
        <Grid item xs={12} sm={6}>
          <InputField name="email" label="Email *" control={control} disabled />
        </Grid>

        {/* Phone */}
        <Grid item xs={12} sm={6}>
          <PhoneField name="phone" placeholder="Phone *" control={control} />
        </Grid>

        {/* Website */}
        <Grid item xs={12} sm={6}>
          <InputField name="website" label="Website" control={control} />
        </Grid>

        {/* Domain Name */}
        <Grid item xs={12} sm={6}>
          <InputField name="domainName" label="Domain name *" control={control} />
        </Grid>

        {/* Visa Fees */}
        <Grid item xs={12} sm={6}>
          <InputField
            name="visaFees"
            label="Visa fees *"
            type="number"
            control={control}
            InputProps={{
              endAdornment: <InputAdornment position="end">{currencyCode}</InputAdornment>,
            }}
          />
        </Grid>

        {/* Heading */}
        <Grid item xs={12} mt={2}>
          <HeadingWithIcon Icon={MdOutlinePayments} text="Currency" />
        </Grid>

        {/* Display Currency */}
        <Grid item xs={12} sm={4}>
          <Tooltip title="Not editable" arrow placement="top">
            <Stack>
              <Controller
                name="displayCurrencyId"
                control={control}
                render={({ fieldState: { error }, field: { ref, ...restField } }) => (
                  <FormControl error={!!error}>
                    <InputLabel>Display currency</InputLabel>
                    <Select {...restField} inputRef={ref} label="Display currency" readOnly inputProps={{ tabIndex: -1 }} style={{ pointerEvents: 'none' }}>
                      {currenciesListApiState.data?.map((item, index) => <MenuItem value={item.id} key={index}>{`[${item.symbol}] - ${item.name}`}</MenuItem>)}
                    </Select>
                    <FormHelperText>{error?.message}</FormHelperText>
                  </FormControl>
                )}
              />
            </Stack>
          </Tooltip>
        </Grid>

        {/* Payment Currency */}
        <Grid item xs={12} sm={4}>
          <Controller
            name="currencyId"
            control={control}
            render={({ fieldState: { error }, field: { ref, ...restField } }) => (
              <FormControl error={!!error}>
                <InputLabel>Payment currency</InputLabel>
                <Select {...restField} inputRef={ref} label="Payment currency">
                  {currenciesListApiState.data?.map((item, index) => <MenuItem value={item.id} key={index}>{`[${item.symbol}] - ${item.name}`}</MenuItem>)}
                </Select>
                <FormHelperText>{error?.message}</FormHelperText>
              </FormControl>
            )}
          />
        </Grid>

        {/* Currency Rate */}
        <Grid item xs={12} sm={4}>
          <InputField name="displayCurrencyRate" label="Display currency rate" type="number" placeholder="Example: 0.5" control={control} />
        </Grid>

        {/* Heading */}
        <Grid item xs={12} mt={2}>
          <HeadingWithIcon Icon={MdOutlinePanoramaHorizontal} text="Home banner" />
        </Grid>

        {/* Banner Heading */}
        <Grid item xs={12}>
          <InputField
            multiline
            name="bannerHeading"
            label="Heading"
            control={control}
            onChange={(e, field, newValue) => {
              field.onChange(e)
              isSubmitted && trigger('bannerImage')
            }}
          />
        </Grid>

        {/* Banner Subheading */}
        <Grid item xs={12}>
          <InputField
            multiline
            name="bannerSubHeading"
            label="Subheading"
            control={control}
            onChange={(e, field, newValue) => {
              field.onChange(e)
              isSubmitted && trigger(['bannerHeading', 'bannerImage'])
            }}
          />
        </Grid>

        {/* Banner Image */}
        <Grid item xs={12}>
          <ImageField name="bannerImage" label="Background image" description="Recommended Size: 1152 x 270" control={control} />
        </Grid>

        {/* Footer */}
        <Grid item xs={12}>
          <Stack direction="row" justifyContent="end">
            <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
              Update
            </LoadingButton>
          </Stack>
        </Grid>
      </Grid>
    </RenderContent>
  )
}

import * as yup from 'yup'
import { schema as organizationFormSchema } from '@/pages/dashboard/organizations/components/organizationForm/OrganizationForm.config'
import { fileTest, IMAGE_EXTENSIONS } from '@/utils'

export const schema = organizationFormSchema.shape({
  isEditMode: yup.boolean().notRequired(),
  currencyId: yup.number().required(),
  visaFees: yup.number().required().min(0).max(100000000),
  displayCurrencyId: yup.number().required(),
  displayCurrencyRate: yup.number().required().min(0).max(10000),
  bannerHeading: yup
    .string()
    .trim()
    .max(300)
    .test('validate', 'Required *', function (bannerHeading) {
      const { bannerImage, bannerSubHeading } = this.parent
      if ((bannerImage && !bannerHeading) || (bannerSubHeading && !bannerHeading)) return false
      return true
    }),
  bannerSubHeading: yup.string().trim().max(300),
  bannerImage: yup
    .mixed<string | File>()
    .test('validate', 'Required *', function (bannerImage) {
      const { bannerHeading, bannerSubHeading } = this.parent
      if ((bannerHeading && !bannerImage) || (bannerSubHeading && !bannerImage)) return false
      return true
    })
    .test(fileTest({ size: 10, extensions: IMAGE_EXTENSIONS, message: { extensions: 'Only image file is accepted' } })),
})

export type TSchema = yup.InferType<typeof schema>

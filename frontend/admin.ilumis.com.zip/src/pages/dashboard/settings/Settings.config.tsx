import dynamic from 'next/dynamic'
import { MdKey, MdOutlineAccountCircle, MdCorporateFare, MdOutlineCreditCard } from 'react-icons/md'
import { TabType } from './Settings.type'

const AccountTab = dynamic(() => import('./components/accountTab/AccountTab.component'))
const ProfileTab = dynamic(() => import('./components/profileTab/ProfileTab.component'))
const PaymentTab = dynamic(() => import('./components/paymentTab/PaymentTab.component'))
const PasswordTab = dynamic(() => import('./components/passwordTab/PasswordTab.component'))

export const TAB: TabType[] = [
  { id: 15, label: 'Profile', Icon: MdOutlineAccountCircle, content: <ProfileTab /> },
  { id: 16, label: 'Organization', Icon: MdCorporateFare, content: <AccountTab /> },
  { id: 13, label: 'Payment', Icon: MdOutlineCreditCard, content: <PaymentTab /> },
  { id: 14, label: 'Password', Icon: MdKey, content: <PasswordTab /> },
]

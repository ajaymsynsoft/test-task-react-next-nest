import moment from 'moment'
import { useRouter } from 'next/router'
import { useState } from 'react'
import { DataGrid } from '@mui/x-data-grid'
import { MdOutlineFileUpload } from 'react-icons/md'
import { DatePicker } from '@mui/x-date-pickers'
import { LoadingButton } from '@mui/lab'
import { Autocomplete, Container, Grid, Stack, Switch, TextField, Typography } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { useColumns, useExport } from './Transportation.hook'
import { usePagination, useUrlParams } from '@/hooks'
import { useGetGuestTransportationListQuery } from '@/redux/api/guest.api'
import { style } from './Transportation.style'
import { useGetEventNameListQuery } from '@/redux/api/event.api'
import { useGetHotelNameListQuery } from '@/redux/api/hotel.api'
import { TFilter } from './Transportation.type'
import { validateDate } from '@/utils'

const Transportation: Page = () => {
  const router = useRouter()
  const { paginationModel, setPaginationModel, page, pageSize } = usePagination()
  const { setUrlParams } = useUrlParams()
  const [showArrival, setShowArrival] = useState(router.query.showArrival !== 'false')

  const filter: TFilter = {
    eventId: router.query.eventId as string,
    hotelId: router.query.hotelId as string,
    isArrival: showArrival,
    date: showArrival ? (router.query.arrivalDate as string) : (router.query.departureDate as string),
  }

  const columns = useColumns({ showArrival })
  const { exportToCsv, isExporting } = useExport({ filter })

  const eventListApiState = useGetEventNameListQuery()
  const hotelListApiState = useGetHotelNameListQuery()
  const transportationListApiState = useGetGuestTransportationListQuery({ pageNo: page, pageSize, ...filter })

  return (
    <>
      {/* Page Header */}
      <PageHeader
        heading="Transportation"
        count={transportationListApiState.data?.totalCount}
        actions={
          <LoadingButton variant="contained" startIcon={<MdOutlineFileUpload />} onClick={exportToCsv} loading={isExporting} disabled={!transportationListApiState.data?.totalCount}>
            Export as CSV
          </LoadingButton>
        }
      />

      <Container component={Stack} position="relative" zIndex={1}>
        {/* Filter */}
        <Grid container mb={3} spacing={2}>
          {/* Select Column */}
          <Grid item xs="auto" mr="auto">
            <Stack component="label" sx={style.switchBox}>
              <Typography>Departure</Typography>
              <Switch
                checked={showArrival}
                onChange={(_, value) => {
                  setUrlParams({ params: { showArrival: String(value) } })
                  setShowArrival(value)
                }}
              />
              <Typography>Arrival</Typography>
            </Stack>
          </Grid>

          {/* Select Event */}
          <Grid item xs={12} sm={3}>
            <Autocomplete
              noOptionsText="No events"
              disableClearable={false}
              loading={eventListApiState.isLoading}
              options={eventListApiState.data || []}
              value={eventListApiState.data?.find((item) => item.id === Number(filter.eventId)) || null}
              getOptionLabel={(option) => option.name}
              onChange={(_, value) => setUrlParams({ params: { eventId: value?.id } })}
              renderInput={(params) => <TextField {...params} label="Event" />}
            />
          </Grid>

          {/* Select Hotel */}
          <Grid item xs={12} sm={3}>
            <Autocomplete
              noOptionsText="No hotels"
              disableClearable={false}
              loading={hotelListApiState.isLoading}
              options={hotelListApiState.data || []}
              value={hotelListApiState.data?.find((item) => item.id === Number(filter.hotelId)) || null}
              getOptionLabel={(option) => option.name}
              onChange={(_, value) => setUrlParams({ params: { hotelId: value?.id } })}
              renderInput={(params) => <TextField {...params} label="Hotel" />}
            />
          </Grid>

          {/* Select Date */}
          <Grid item xs={2.5}>
            <DatePicker
              label={`${showArrival ? 'Arrival' : 'Departure'} Date`}
              value={filter.date ? moment(filter.date) : null}
              onChange={(value) => setUrlParams({ params: { [showArrival ? 'arrivalDate' : 'departureDate']: validateDate(value) ? value?.toISOString() : '' } })}
              slotProps={{ popper: { disablePortal: true } }}
            />
          </Grid>
        </Grid>

        {/* Table */}
        <RenderContent loading={transportationListApiState.isLoading} error={transportationListApiState.isError}>
          <DataGrid
            columns={columns}
            loading={transportationListApiState.isFetching}
            rows={transportationListApiState.data?.list || []}
            rowCount={transportationListApiState.data?.totalCount || 0}
            getRowHeight={() => 'auto'}
            paginationModel={paginationModel}
            onPaginationModelChange={setPaginationModel}
          />
        </RenderContent>
      </Container>
    </>
  )
}

Transportation.rootLayoutProps = {
  title: 'Transportation',
  pageType: 'protected',
  module: {
    id: 9,
    permission: 'view',
  },
}

export default Transportation

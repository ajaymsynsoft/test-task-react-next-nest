import { Style } from '@/types'

export const style: Style = {
  switchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 1,
    gap: 1,
    cursor: 'pointer',
  },
}

import moment from 'moment'
import Link from 'next/link'
import { useState } from 'react'
import { GridColDef } from '@mui/x-data-grid'
import { Typography, Link as MuiLink, Stack, Box, Chip, Avatar } from '@mui/material'
import { MdOutlineFlag } from 'react-icons/md'

import GuestInfoCard from '@/components/_card/guestInfoCard/GuestInfoCard.compoent'
import HotelInfoCard from '@/components/_card/hotelInfoCard/HotelInfoCard.compoent'
import SmartPopover from '@/components/smartPopover/SmartPopover.component'
import { TGuest } from '@/types/Guest.type'
import { useReduxSelector } from '@/hooks'
import { useLazyGetGuestTransportationListQuery } from '@/redux/api/guest.api'
import { UseExportProps } from './Transportation.type'
import { downloadFile, jsonToCsv } from '@/utils'

export const useColumns = ({ showArrival }: { showArrival: boolean }) => {
  const { modules } = useReduxSelector((state) => state.layout.profile)

  const createListItem = (label: string, value: string | number | undefined | null) => {
    return (
      <Stack direction="row">
        <Typography whiteSpace="nowrap" color="text.disabled">
          {label}:&nbsp;
        </Typography>
        {value ? <Typography>{value}</Typography> : null}
      </Stack>
    )
  }

  const columns: GridColDef<TGuest>[] = [
    {
      field: 'orderId',
      headerName: 'Booking ID',
      sortable: false,
      minWidth: 100,
      display: 'flex',
      renderCell: ({ row }) =>
        modules[12].permissions.edit ? (
          <MuiLink component={Link} href={`/dashboard/bookings/edit/${row.orderId}`} target="_blank">
            #{row.orderId}
          </MuiLink>
        ) : (
          <Typography>#{row.orderId}</Typography>
        ),
    },
    {
      field: 'guest',
      headerName: 'Guest',
      sortable: false,
      flex: 1,
      minWidth: 250,
      renderCell: ({ row }) => (
        <GuestInfoCard data={row}>
          <Stack gap={1}>
            {row.nationality && (
              <Stack direction="row" alignItems="center" gap={0.5} title="Nationality">
                <Box component={MdOutlineFlag} size={16} color="text.disabled" />
                <Typography variant="body2">{row.nationality}</Typography>
              </Stack>
            )}
            {row.accessibilityInfoData.length > 0 && (
              <Stack direction="row" gap={1} flexWrap="wrap">
                {row.accessibilityInfoData.map((item, index) => (
                  <Chip avatar={<Avatar alt="icon" src={item.imageURL} />} label={item.name} key={index} />
                ))}
              </Stack>
            )}
          </Stack>
        </GuestInfoCard>
      ),
    },
    showArrival
      ? {
          field: 'arrival',
          headerName: 'Arrival Information',
          sortable: false,
          flex: 1,
          minWidth: 250,
          renderCell: ({ row }) => (
            <Stack gap={0.25}>
              {createListItem('Airport', row.arrivalFlightAirport)}
              {createListItem('Flight number', row.arrivalFlightNumber)}
              {createListItem('Time', row.arrivalDateTime && moment(row.arrivalDateTime).format('lll'))}
              {createListItem('Notes', row.arrivalNotes)}
            </Stack>
          ),
        }
      : {
          field: 'departure',
          headerName: 'Departure Information',
          sortable: false,
          flex: 1,
          minWidth: 250,
          renderCell: ({ row }) => (
            <Stack gap={0.25}>
              {createListItem('Airport', row.departureFlightAirport)}
              {createListItem('Flight number', row.departureFlightNumber)}
              {createListItem('Time', row.departureDateTime && moment(row.departureDateTime).format('lll'))}
              {createListItem('Notes', row.departureNotes)}
            </Stack>
          ),
        },
    {
      field: 'hotel',
      headerName: 'Hotel',
      sortable: false,
      minWidth: 250,
      renderCell: ({ row }) => (
        <Stack gap={0.25}>
          {row.hotel ? (
            <>
              <SmartPopover>
                <SmartPopover.Toggle>
                  <MuiLink color="text.secondary">{row.hotel?.name}</MuiLink>
                </SmartPopover.Toggle>
                <SmartPopover.Content>
                  <HotelInfoCard data={row.hotel} p={2} />
                </SmartPopover.Content>
              </SmartPopover>
              {createListItem('Room Type', row.hotel?.roomType.roomSize)}
              {createListItem('Check In', moment(row.fromDate).format('lll'))}
              {createListItem('Check Out', moment(row.toDate).format('lll'))}
            </>
          ) : (
            <Typography color="text.disabled">Not booked</Typography>
          )}
        </Stack>
      ),
    },
  ]

  return columns
}

export const useExport = ({ filter }: UseExportProps) => {
  const [getGuesttransportationList] = useLazyGetGuestTransportationListQuery()
  const [isExporting, setIsExporting] = useState(false)

  const fetchAllGuest = async () => {
    const pageSize = 50
    let pageNo = 1
    let allGuest: TGuest[] = []

    const fetchGuest = async () => {
      const { list } = await getGuesttransportationList({ pageNo, pageSize, ...filter }, true).unwrap()
      pageNo++
      allGuest = [...allGuest, ...list]
      if (list.length === pageSize) await fetchGuest()
    }

    await fetchGuest()
    return allGuest
  }

  const formatDataToCsv = (guests: TGuest[]) => {
    const data: Record<string, string>[] = []

    for (const guest of guests) {
      const item = {
        'Booking ID': `#${guest.orderId}`,
        'Guest Information': `
Name: ${guest.passportFirstName + ' ' + guest.passportLastName || 'N/A'}
Role: ${guest.role || 'N/A'}
Passport Number: ${guest.passportNumber || 'N/A'}
passport Issue Date: ${guest.passportIssueDate ? moment(guest.passportIssueDate).format() : 'N/A'}
passport Expiry Date: ${guest.passportExpiryDate ? moment(guest.passportExpiryDate).format() : 'N/A'}
Nationality: ${guest.nationality || 'N/A'}
Date of Birth: ${guest.dob ? moment(guest.dob).format() : 'N/A'}
Occupation: ${guest.occupation || 'N/A'}
Workplace: ${guest.workPlace || 'N/A'}
Job Title: ${guest.jobTitle || 'N/A'}
Accessibility: ${guest.accessibilityInfoData?.length ? guest.accessibilityInfoData.map((item) => item.name).join(', ') : 'N/A'}
      `.trim(),
        'Departure Information': `
Airport: ${guest.departureFlightAirport || 'N/A'}
Flight number: ${guest.departureFlightNumber || 'N/A'}
Time: ${guest.departureDateTime ? moment(guest.departureDateTime).format('lll') : 'N/A'}
Notes: ${guest.departureNotes || 'N/A'}
            `.trim(),
        'Arrival Information': `
Airport: ${guest.arrivalFlightAirport || 'N/A'}
Flight number: ${guest.arrivalFlightNumber || 'N/A'}
Time: ${guest.arrivalDateTime ? moment(guest.arrivalDateTime).format('lll') : 'N/A'}
Notes: ${guest.arrivalNotes || 'N/A'}
      `.trim(),
        'Hotel Information': guest.hotel
          ? `
Hotel Name: ${guest.hotel?.name}
Room Type: ${guest.hotel?.roomType?.roomSize || 'N/A'}
Check In: ${guest.fromDate ? moment(guest.fromDate).format('lll') : 'N/A'}
Check Out: ${guest.toDate ? moment(guest.toDate).format('lll') : 'N/A'}
      `.trim()
          : 'Not booked',
      }

      data.push(item)
    }

    return jsonToCsv(data)
  }

  const exportToCsv = async () => {
    try {
      setIsExporting(true)

      const data = await fetchAllGuest()
      const csvData = formatDataToCsv(data)
      const blob = new Blob([csvData], { type: 'text/csv' })

      downloadFile({ file: blob, filename: `Transportation ${moment().format('ll')}` })
    } finally {
      setIsExporting(false)
    }
  }

  return { exportToCsv, isExporting }
}

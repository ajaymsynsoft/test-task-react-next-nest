export type UseExportProps = {
  filter: TFilter
}

export type TFilter = {
  isArrival: boolean
  eventId?: string
  hotelId?: string
  date?: string
}

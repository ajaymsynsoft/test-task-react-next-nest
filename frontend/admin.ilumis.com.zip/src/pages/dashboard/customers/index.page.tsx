import { Container } from '@mui/material'
import { DataGrid } from '@mui/x-data-grid'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { useColumns } from './Customers.hook'
import { usePagination } from '@/hooks'
import { useGetCustomerListQuery } from '@/redux/api/customer.api'

const Customers: Page = () => {
  const columns = useColumns()
  const { paginationModel, setPaginationModel, page, pageSize } = usePagination()
  const { data, isFetching, isError, isLoading } = useGetCustomerListQuery({ pageNo: page, pageSize })

  return (
    <>
      <PageHeader heading="Customers" count={data?.totalCount} />

      <Container>
        <RenderContent loading={isLoading} error={isError}>
          <DataGrid loading={isFetching} columns={columns} rowCount={data?.totalCount || 0} rows={data?.list || []} paginationModel={paginationModel} onPaginationModelChange={setPaginationModel} />
        </RenderContent>
      </Container>
    </>
  )
}

Customers.rootLayoutProps = {
  title: 'Customers',
  pageType: 'protected',
  module: {
    id: 17,
    permission: 'view',
  },
}

export default Customers

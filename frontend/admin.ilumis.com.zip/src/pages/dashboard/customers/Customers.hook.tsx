import moment from 'moment'
import { GridColDef } from '@mui/x-data-grid'
import { Chip } from '@mui/material'

import { formatToTitleCase, getStatusColor } from '@/utils'
import { CustomerDTO } from '@/dto'

export const useColumns = () => {
  const columns: GridColDef<CustomerDTO>[] = [
    {
      field: 'id',
      headerName: 'ID',
      sortable: false,
      minWidth: 85,
      width: 85,
      valueFormatter: (value) => `#${value}`,
    },
    {
      field: 'name',
      headerName: 'Full Name',
      sortable: false,
      minWidth: 199,
      renderCell: ({ row }) => `${row.firstName} ${row.lastName}`,
    },
    {
      field: 'email',
      headerName: 'Email',
      sortable: false,
      flex: 1,
      minWidth: 200,
    },
    {
      field: 'phone',
      headerName: 'Phone',
      sortable: false,
      minWidth: 140,
    },
    {
      field: 'country',
      headerName: 'Country',
      sortable: false,
      minWidth: 130,
    },
    {
      field: 'createdDate',
      headerName: 'Registration Date',
      sortable: false,
      minWidth: 170,
      valueFormatter: (value) => moment(value).format('lll'),
    },
    {
      field: 'status',
      headerName: 'Status',
      sortable: false,
      minWidth: 100,
      renderCell: (params) => <Chip label={formatToTitleCase(params.value)} variant="outlined" color={getStatusColor(params.value)} />,
    },
  ]

  return columns
}

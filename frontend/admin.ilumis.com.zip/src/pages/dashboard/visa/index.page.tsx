import { useRouter } from 'next/router'
import { Autocomplete, Container, Grid, TextField } from '@mui/material'
import { DataGrid } from '@mui/x-data-grid'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { useColumns } from './Visa.hook'
import { usePagination, useUrlParams } from '@/hooks'
import { useGetGuestVisaListQuery } from '@/redux/api/guest.api'
import { useGetEventNameListQuery } from '@/redux/api/event.api'

const Visa: Page = () => {
  const router = useRouter()
  const columns = useColumns()
  const { paginationModel, setPaginationModel, page, pageSize } = usePagination()
  const { setUrlParams } = useUrlParams()

  const filter = { eventId: router.query.eventId as string }

  const { data, isFetching, isError, isLoading } = useGetGuestVisaListQuery({ pageNo: page, pageSize, ...filter })
  const eventListApiState = useGetEventNameListQuery()

  return (
    <>
      <PageHeader heading="Visa" count={data?.totalCount} />

      <Container>
        {/* Filter */}
        <Grid container mb={3} spacing={2} position="relative" zIndex={1}>
          {/* Event */}
          <Grid item xs={12} sm={4}>
            <Autocomplete
              noOptionsText="No events"
              disableClearable={false}
              loading={eventListApiState.isLoading}
              options={eventListApiState.data || []}
              value={eventListApiState.data?.find((item) => item.id === Number(filter.eventId)) || null}
              getOptionLabel={(option) => option.name}
              onChange={(_, value) => setUrlParams({ params: { eventId: value?.id } })}
              renderInput={(params) => <TextField {...params} label="Event" />}
            />
          </Grid>
        </Grid>

        {/* Table */}
        <RenderContent loading={isLoading} error={isError}>
          <DataGrid loading={isFetching} columns={columns} rowCount={data?.totalCount || 0} rows={data?.list || []} getRowHeight={() => 'auto'} paginationModel={paginationModel} onPaginationModelChange={setPaginationModel} />
        </RenderContent>
      </Container>
    </>
  )
}

Visa.rootLayoutProps = {
  title: 'Visa',
  pageType: 'protected',
  module: {
    id: 8,
    permission: 'view',
  },
}

export default Visa

import { TVisa } from '@/redux/api/guest.api'

export type UpdateGuestVisaPopupProps = {
  onCancel: () => void
  data: TVisa
}

import * as yup from 'yup'
import { fileTest, IMAGE_EXTENSIONS } from '@/utils'
import { TGuest } from '@/types'

export const schema = yup.object({
  orderId: yup.number().required(),
  guestId: yup.number().required(),
  visaDocument: yup.mixed<File | string>().test(fileTest({ size: 10, extensions: [...IMAGE_EXTENSIONS, 'pdf'], message: { extensions: 'Image and PDF files are accepted' } })),
  visaOfficialLetterDocument: yup.mixed<File | string>().test(fileTest({ size: 10, extensions: [...IMAGE_EXTENSIONS, 'pdf'], message: { extensions: 'Image and PDF files are accepted' } })),
  visaStatus: yup
    .string<TGuest['visaStatus']>()
    .required()
    .test('validate', 'Visa status must be "issued" to upload', function (value) {
      const { visaDocument, visaOfficialLetterDocument } = this.parent
      if ((visaDocument || visaOfficialLetterDocument) && value !== 'issued') return false
      return true
    }),
})

export type TSchema = yup.InferType<typeof schema>

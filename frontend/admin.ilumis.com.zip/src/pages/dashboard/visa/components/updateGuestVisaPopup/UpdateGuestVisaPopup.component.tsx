import toast from 'react-hot-toast'
import { LoadingButton } from '@mui/lab'
import { Controller, useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { Card, CardContent, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormHelperText, FormLabel, Grid, MenuItem, Select, Stack } from '@mui/material'

import GuestDetails from '@/components/_booking/guestDetails/GuestDetails.component'
import FileUploadField from '@/components/_ui/fileUploadField/FileUploadField.component'
import { UpdateGuestVisaPopupProps } from './UpdateGuestVisaPopup.type'
import { schema, TSchema } from './UpdateGuestVisaPopup.config'
import { TGuest } from '@/types'
import { formatToTitleCase } from '@/utils'
import { useUploadFileMutation } from '@/redux/api/common.api'
import { useUpdateGuestTransportationMutation } from '@/redux/api/guest.api'

export default function UpdateGuestVisaPopup({ onCancel, data }: UpdateGuestVisaPopupProps) {
  const VISA_STATUS = ['pending', 'issued'] as TGuest['visaStatus'][]
  const [updateGuestTransportation] = useUpdateGuestTransportationMutation()
  const [uploadFile] = useUploadFileMutation()

  const {
    handleSubmit,
    control,
    getValues,
    setValue,
    formState: { isSubmitting, isDirty },
    setError,
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      orderId: data.orderId,
      guestId: data.id,
      visaDocument: data.visaDocument || '',
      visaOfficialLetterDocument: data.visaOfficialLetterDocument || '',
      visaStatus: data.visaStatus,
    },
  })

  const onSubmit = async () => {
    const formData = schema.validateSync(getValues())

    if (!isDirty) return toast.error('Please make a change to update')

    if (formData.visaStatus === 'issued' && data.visaAssistanceRequired && !formData.visaDocument) return setError('visaDocument', { type: 'validate', message: 'Required *' }, { shouldFocus: true })
    if (formData.visaStatus === 'issued' && data.visaOfficialLetterRequired && !formData.visaOfficialLetterDocument)
      return setError('visaOfficialLetterDocument', { type: 'validate', message: 'Required *' }, { shouldFocus: true })

    if (formData.visaDocument instanceof File) {
      const [image] = await uploadFile({ files: formData.visaDocument, folderName: 'guest' }).unwrap()
      formData.visaDocument = image
      setValue('visaDocument', image)
    }

    if (formData.visaOfficialLetterDocument instanceof File) {
      const [image] = await uploadFile({ files: formData.visaOfficialLetterDocument, folderName: 'guest' }).unwrap()
      formData.visaOfficialLetterDocument = image
      setValue('visaOfficialLetterDocument', image)
    }

    await updateGuestTransportation({ ...formData, visaDocument: formData.visaDocument as string, visaOfficialLetterDocument: formData.visaOfficialLetterDocument, userId: data.order.userId }).unwrap()
    onCancel()
  }

  return (
    <Dialog open fullWidth component="form" maxWidth="md" onClose={() => !isSubmitting && onCancel()} onSubmit={handleSubmit(onSubmit)} {...{ noValidate: true }}>
      <DialogTitle>Update guest visa</DialogTitle>
      <DialogContent dividers>
        <Stack gap={3}>
          {/* Form */}
          <Grid container spacing={2} width={1}>
            {/* Upload Visa */}
            {data.visaAssistanceRequired && (
              <Grid item xs={12} sm>
                <FileUploadField name="visaDocument" label="Upload visa *" control={control} accept="image/*, application/pdf" />
              </Grid>
            )}

            {/* Upload Visa Letter*/}
            {data.visaOfficialLetterRequired && (
              <Grid item xs={12} sm>
                <FileUploadField name="visaOfficialLetterDocument" label="Upload visa letter *" control={control} accept="image/*, application/pdf" />
              </Grid>
            )}

            {/* Status */}
            <Grid item xs={12} sm>
              <Controller
                name="visaStatus"
                control={control}
                render={({ fieldState: { error }, field: { ref, ...restField } }) => (
                  <FormControl error={!!error}>
                    <FormLabel sx={{ lineHeight: 1, mb: 0.75, mt: -0.25 }}>Visa status</FormLabel>
                    <Select {...restField} inputRef={ref}>
                      {VISA_STATUS.map((item, index) => (
                        <MenuItem value={item} disabled={item === 'pending'} key={index}>
                          {formatToTitleCase(item)}
                        </MenuItem>
                      ))}
                    </Select>
                    <FormHelperText>{error?.message}</FormHelperText>
                  </FormControl>
                )}
              />
            </Grid>
          </Grid>

          {/* Guest Details */}
          <Card variant="outlined">
            <CardContent>
              <GuestDetails data={data} />
            </CardContent>
          </Card>
        </Stack>
      </DialogContent>
      <DialogActions>
        <LoadingButton variant="text" disabled={isSubmitting} onClick={onCancel}>
          Cancel
        </LoadingButton>
        <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
          Update
        </LoadingButton>
      </DialogActions>
    </Dialog>
  )
}

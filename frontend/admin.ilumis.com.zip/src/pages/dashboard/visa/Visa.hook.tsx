import { useState } from 'react'
import { MdEdit } from 'react-icons/md'
import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'
import { Chip, Link as MuiLink, Typography, Stack } from '@mui/material'
import { SlEnvolopeLetter } from 'react-icons/sl'
import { FaRegAddressCard } from 'react-icons/fa6'

import GuestInfoCard from '@/components/_card/guestInfoCard/GuestInfoCard.compoent'
import UpdateGuestVisaPopup from './components/updateGuestVisaPopup/UpdateGuestVisaPopup.component'
import { formatToTitleCase, getStatusColor } from '@/utils'
import { TVisa } from '@/redux/api/guest.api'
import { useReduxSelector } from '@/hooks'

export const useColumns = () => {
  const [updateVisa, setUpdateVisa] = useState<number | null>(null)
  const { modules } = useReduxSelector((state) => state.layout.profile)

  const columns: GridColDef<TVisa>[] = [
    {
      field: 'id',
      headerName: 'IDs',
      sortable: false,
      width: 150,
      renderCell: ({ row }) => (
        <Stack gap={0.75}>
          {/* Guest ID */}
          <Typography>{`Guest ID : #${row.id}`}</Typography>

          {/* Booking ID */}
          {modules[12].permissions.edit ? (
            <Typography>
              Booking ID :{' '}
              <MuiLink href={`/dashboard/bookings/edit/${row.orderId}`} target="_blank">
                {' '}
                #{row.orderId}
              </MuiLink>
            </Typography>
          ) : (
            <Typography variant="body1">{`Booking ID : #${row.orderId}`}</Typography>
          )}

          {/* Event ID */}
          {modules[3].permissions.edit ? (
            <Typography>
              Event ID :{' '}
              <MuiLink href={`/dashboard/events/edit/${row.eventId}`} target="_blank">
                {' '}
                #{row.eventId}
              </MuiLink>
            </Typography>
          ) : (
            <Typography variant="body1">{`Event ID : #${row.eventId}`}</Typography>
          )}
        </Stack>
      ),
    },
    {
      field: 'guest',
      headerName: 'Guest',
      sortable: false,
      flex: 1,
      minWidth: 250,
      renderCell: ({ row }) => <GuestInfoCard data={row} />,
    },
    {
      field: 'guestStatus',
      headerName: 'Guest Status',
      sortable: false,
      width: 145,
      renderCell: ({ row }) => <Chip label={formatToTitleCase(row.status)} variant="outlined" color={getStatusColor(row.status)} />,
    },
    {
      field: 'status',
      headerName: 'Booking Status',
      sortable: false,
      width: 125,
      renderCell: ({ row }) => <Chip label={formatToTitleCase(row.order.status)} variant="outlined" color={getStatusColor(row.order.status)} />,
    },
    {
      field: 'paymentStatus',
      headerName: 'Payment Status',
      sortable: false,
      width: 130,
      renderCell: ({ row }) => <Chip label={formatToTitleCase(row.order.paymentStatus)} variant="outlined" color={getStatusColor(row.order.paymentStatus)} />,
    },
    {
      field: 'visaStatus',
      headerName: 'Visa Status',
      sortable: false,
      width: 100,
      renderCell: ({ row }) => <Chip label={formatToTitleCase(row.visaStatus)} variant="outlined" color={getStatusColor(row.visaStatus)} />,
    },
    {
      field: 'actions',
      headerName: 'Actions',
      sortable: false,
      width: 80,
      align: 'center',
      type: 'actions',
      getActions: ({ row }) => {
        const actions = []

        if (modules[2].permissions.edit) {
          actions.push(<GridActionsCellItem showInMenu label="Edit" icon={<MdEdit />} disabled={row.status === 'cancelled' || row.order.status === 'cancelled'} onClick={() => setUpdateVisa(row.id)} />)
        }

        if (row.visaAssistanceRequired) {
          actions.push(<GridActionsCellItem showInMenu label="View visa" icon={<FaRegAddressCard />} disabled={!row.visaDocument} component="a" {...{ target: '_blank', href: row.visaDocument }} />)
        }

        if (row.visaOfficialLetterRequired) {
          actions.push(
            <GridActionsCellItem showInMenu label="View visa letter" icon={<SlEnvolopeLetter />} disabled={!row.visaOfficialLetterDocument} component="a" {...{ target: '_blank', href: row.visaOfficialLetterDocument }} />,
          )
        }

        if (updateVisa === row.id) actions.push(<UpdateGuestVisaPopup key="updateVisa" data={row} onCancel={() => setUpdateVisa(null)} />)

        return actions
      },
    },
  ]

  return columns
}

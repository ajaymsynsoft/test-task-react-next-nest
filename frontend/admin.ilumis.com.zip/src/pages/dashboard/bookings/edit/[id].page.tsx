import { useRouter } from 'next/router'
import { Box } from '@mui/material'

import PageHeader from '@/components/pageHeader/PageHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import BookingDetailsTab from '@/components/_booking/bookingDetailsTab/BookingDetailsTab.component'
import BookingActions from '@/components/_booking/bookingActions/BookingActions.component'
import { Page } from '@/types'
import { useGetBookingQuery } from '@/redux/api/booking.api'

const EditBooking: Page = () => {
  const router = useRouter()
  const { isFetching, isSuccess, isLoading, isError, data: bookingDetails } = useGetBookingQuery(Number(router.query.id))

  return (
    <>
      <PageHeader
        sx={{ mb: isLoading ? undefined : '0 !important', mt: '0 !important', borderColor: 'var(--border-color)' }}
        heading={
          <>
            Booking{' '}
            <Box component="span" color="text.disabled" ml={1}>
              #{router.query.id}
            </Box>
          </>
        }
        backUrl="/dashboard/bookings"
        actions={isSuccess ? <BookingActions data={bookingDetails} /> : null}
      />

      <RenderContent error={isError} loading={isLoading}>
        {isSuccess && <BookingDetailsTab data={bookingDetails} loading={isFetching} />}
      </RenderContent>
    </>
  )
}

EditBooking.rootLayoutProps = {
  title: 'Edit Booking',
  pageType: 'protected',
  module: {
    id: 12,
    permission: 'edit',
  },
}

export default EditBooking

import moment from 'moment'
import { useEffect } from 'react'
import { useRouter } from 'next/router'
import { Box, Divider, Grid, Stack, Typography } from '@mui/material'

import RenderContent from '@/components/renderContent/RenderContent.component'
import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import FullPageMessage from '@/components/fullPageMessage/FullPageMessage.component'
import BankDetails from '@/components/_booking/bankDetails/BankDetails.component'
import { Style } from './BookingPdfMaker.style'
import { Page } from '@/types'
import { useReduxSelector } from '@/hooks'
import { useGetBookingQuery } from '@/redux/api/booking.api'

const BookingPdfMaker: Page = () => {
  const router = useRouter()
  const isReceipt = router.query.type === 'receipt'
  const organization = useReduxSelector((state) => state.organization)
  const { isSuccess, data, isError, isLoading } = useGetBookingQuery(Number(router.query.id))

  useEffect(() => {
    if (isSuccess) document.title = `Event Booking - #${data.id}`
  }, [isSuccess])

  if (isReceipt && isSuccess && data.paymentStatus !== 'paid') return <FullPageMessage hideButton />

  return (
    <RenderContent loading={isLoading} error={isError}>
      {isSuccess && (
        <Stack gap={5}>
          <Style />

          {/* Logo */}
          <Stack>
            <Box component="img" src={organization.logo} className="header-logo" />
          </Stack>

          {/* Header */}
          <Stack>
            <Grid container className="pdf-no-break">
              <Grid xs={6}>
                <Stack>
                  <Typography variant="display2">{organization.organizationName}</Typography>
                </Stack>
              </Grid>
              <Grid xs={6}>
                <Stack textAlign="right">
                  <Typography variant="display2" mb={2}>
                    {isReceipt ? `RECEIPT` : `TAX INVOICE`}
                  </Typography>
                  <Stack gap={0.75}>
                    <Box>
                      <b>Invoice Number:</b> INV-{data.id}
                    </Box>
                    <Box>
                      <b>Invoice Date:</b> {moment(data.orderDate).format()}
                    </Box>
                    <Box>
                      <b>Balance Due:</b> <DisplayPrice price={data.unpaidAmount} />
                    </Box>
                  </Stack>
                </Stack>
              </Grid>
            </Grid>

            <Stack mt={2} gap={0.75} className="pdf-no-break">
              <Box>
                <b>Event:</b> {data.event!.name}
              </Box>
              <Box>
                <b>Bill To:</b> {data.user!.customerOrganizationName} - {data.user!.country}
              </Box>
            </Stack>
          </Stack>

          <Divider />

          {/* Guests */}
          <Stack gap={2}>
            <Typography variant="h2">Guests</Typography>
            <table>
              <tr>
                <th className="serialNumber-column">S. No.</th>
                <th>Guest</th>
                <th>Fees</th>
              </tr>
              {data.guestDetails.map((item, index) => (
                <tr key={index}>
                  <td className="serialNumber-column">{index + 1}</td>
                  <td>
                    {item.passportFirstName} {item.passportLastName} - <Typography display="inline">{`(${item.role})`}</Typography>
                  </td>
                  <td>
                    <DisplayPrice price={item.registrationFee} />
                  </td>
                </tr>
              ))}
              <tr>
                <td colSpan={2}>
                  <b>Total</b>
                </td>
                <td>
                  <b>
                    <DisplayPrice price={data.orderDetails.find((item) => item.type === 'registration')?.amount || 0} />
                  </b>
                </td>
              </tr>
            </table>
          </Stack>

          {/* Accommodation */}
          {data.isAccommodationEnabled && !!data.accommodationInfo.length && (
            <Stack gap={2}>
              <Typography variant="h2">Accommodation</Typography>
              <table>
                <tr>
                  <th className="serialNumber-column">S. No.</th>
                  <th>Guest</th>
                  <th>Amount</th>
                </tr>
                {data.accommodationInfo.map((item, index) => (
                  <tr key={index}>
                    <td className="serialNumber-column">{index + 1}</td>
                    <td>
                      <Stack gap={0.5}>
                        <Typography>{item.guestNames.join(' | ')}</Typography>
                        {item.hotelId && (
                          <>
                            <Typography variant="body2">
                              <b>Room:</b> {item.hotel.roomType.roomSize}
                            </Typography>
                            <Typography variant="body2">
                              <b>Nights:</b> {item.numberOfNights}
                            </Typography>
                            <Typography variant="body2">
                              <b>Check In:</b> {moment(item.fromDate).format()}
                            </Typography>
                            <Typography variant="body2">
                              <b>Check Out:</b> {moment(item.toDate).format()}
                            </Typography>
                          </>
                        )}
                      </Stack>
                    </td>
                    <td>
                      <DisplayPrice price={item.amount} />
                    </td>
                  </tr>
                ))}
                <tr>
                  <td colSpan={2}>
                    <b>Total</b>
                  </td>
                  <td>
                    <b>
                      <DisplayPrice price={data.orderDetails.find((item) => item.type === 'accommodation')?.amount || 0} />
                    </b>
                  </td>
                </tr>
              </table>
            </Stack>
          )}

          {/* Visa assistance */}
          {data.isVisaEnabled && !!data.guestDetails.filter((item) => item.visaAssistanceRequired).length && (
            <Stack gap={2}>
              <Typography variant="h2">Visa assistance</Typography>
              <table>
                <tr>
                  <th className="serialNumber-column">S. No.</th>
                  <th>Guest</th>
                  <th>Amount</th>
                </tr>
                {data.guestDetails
                  .filter((item) => item.visaAssistanceRequired)
                  .map((item, index) => (
                    <tr key={index}>
                      <td className="serialNumber-column">{index + 1}</td>
                      <td>
                        {item.passportFirstName} {item.passportLastName}
                      </td>
                      <td>
                        <DisplayPrice price={organization.visaFees} />
                      </td>
                    </tr>
                  ))}
                <tr>
                  <td colSpan={2}>
                    <b>Total</b>
                  </td>
                  <td>
                    <b>
                      <DisplayPrice price={data.orderDetails.find((item) => item.type === 'visa')?.amount || 0} />
                    </b>
                  </td>
                </tr>
              </table>
            </Stack>
          )}

          {/* Summary */}
          <Grid container className="pdf-no-break">
            <Grid item xs></Grid>
            <Grid item xs="auto">
              <table border={1}>
                <tr>
                  <th>Total penalty fees</th>
                  <td>
                    <DisplayPrice price={data.penalties} />
                  </td>
                </tr>
                <tr>
                  <th>
                    {isReceipt ? `Total Paid Amount` : `Grand Total`} ({organization.displayCurrency.code})
                  </th>
                  <td>
                    <DisplayPrice price={data.totalAmountInDisplayCurrency} />
                  </td>
                </tr>
                <tr className="ignore-border">
                  <th>
                    {isReceipt ? `Total Paid Amount` : `Grand Total`} ({organization.defaultCurrency.code})
                  </th>
                  <td>
                    <DisplayPrice code={organization.defaultCurrency.code} price={data.totalAmountInDefaultCurrency} />
                  </td>
                </tr>
              </table>
            </Grid>
          </Grid>

          {/* Bank Details */}
          {data.paymentType == 'bankTransfer' && data.status !== 'cancelled' && (data.paymentStatus === 'partiallyPaid' || data.paymentStatus === 'unpaid') && (
            <Grid item xs={12}>
              <BankDetails />
            </Grid>
          )}
        </Stack>
      )}
    </RenderContent>
  )
}

BookingPdfMaker.rootLayoutProps = {
  title: 'Event Booking PDF',
  pageType: 'protected',
  header: false,
  footer: false,
  module: {
    id: 12,
    permission: 'view',
  },
}

export default BookingPdfMaker

import { useTheme } from '@mui/material'

export const Style = () => {
  const theme = useTheme()

  return (
    <style global jsx>{`
      body {
        padding-top: 30px;
        padding-bottom: 30px;
        margin: auto;
      }

      #__next {
        min-height: unset !important;
      }

      .header-logo {
        width: auto;
        height: auto;
        max-height: 50px;
        max-width: 220px;
        object-fit: contain;
        object-position: left center;
      }

      table {
        border-collapse: collapse;
      }

      table,
      tr,
      td,
      th {
        border: 1px solid ${theme.palette.dividerDark};
      }

      tr {
        break-inside: avoid;
      }

      td,
      th {
        padding: 13px;
      }

      th {
        background: #f1f1f1;
        font-weight: 600;
        text-align: left;
      }

      .serialNumber-column {
        width: 80px;
        text-align: center;
      }
    `}</style>
  )
}

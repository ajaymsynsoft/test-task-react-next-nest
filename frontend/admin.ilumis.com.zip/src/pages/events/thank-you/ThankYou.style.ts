import { Style } from '@/types/Style.type'

export const style: Style = {
  successIcon: {
    fontSize: '60px !important',
    color: 'success.light',
    mx: 'auto',
    mb: 1,
  },
  card: {
    p: 3,
    borderRadius: 1.5,
    display: 'flex',
    flexFlow: 'column',
    gap: 3,
  },
  listItem: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexFlow: 'row',
    gap: 2,
  },
  listItemHeading: {
    flexFlow: 'row',
    gap: 1,
    alignItems: 'center',
    '.icon': {
      color: 'text.disabled',
    },
  },
  countBox: {
    border: 1,
    borderColor: 'divider',
    borderRadius: 2,
    p: 2,
    gap: 2,
    justifyContent: 'space-around',
  },
  countBoxItem: {
    alignItems: 'center',
    gap: 0.5,
    '.icon': {
      color: 'text.secondary',
    },
  },
  imageBox: {
    alignItems: 'end',
    justifyContent: 'center',
    height: 1,
  },
}

import moment from 'moment'
import Link from 'next/link'
import { useRouter } from 'next/router'
import { BiDollar } from 'react-icons/bi'
import { IconType } from 'react-icons'
import { TbUsersGroup } from 'react-icons/tb'
import { PiIdentificationBadge } from 'react-icons/pi'
import { FaRegCircleCheck } from 'react-icons/fa6'
import { MdOutlineArticle, MdOutlineCalendarToday, MdOutlineHotel, MdOutlinePayment, MdPersonOutline } from 'react-icons/md'
import { Button, Container, Stack, Typography, Grid, Card, Divider, useMediaQuery, Theme, Box, Alert } from '@mui/material'

import RenderContent from '@/components/renderContent/RenderContent.component'
import DisplayPrice from '@/components/displayPrice/DisplayPrice.component'
import ThankYouImage from './components/thankYouImage/ThankYouImage.component'
import { Page } from '@/types/Page.type'
import { useGetBookingQuery } from '@/redux/api/booking.api'
import { style } from './ThankYou.style'
import { formatToTitleCase } from '@/utils'

const BookingThankYou: Page = () => {
  const router = useRouter()
  const bookingId = Number(router.query.bookingId)
  const isMdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'))
  const { data, isLoading, isError, isSuccess } = useGetBookingQuery(bookingId)

  type TListItem = {
    label: string
    value: React.ReactNode
    Icon: IconType
  }

  const createListItem = (data: TListItem) => {
    return (
      <Stack sx={style.listItem}>
        <Stack sx={style.listItemHeading}>
          <data.Icon className="icon-xl" />
          <Typography fontWeight={500}>{data.label}</Typography>
        </Stack>
        <Typography variant="h4">{data.value}</Typography>
      </Stack>
    )
  }

  return (
    <>
      <style global jsx>{`
        main {
          display: flex;
          justify-content: center;
          align-items: center;
        }
      `}</style>

      <Container className="section-spacing-my">
        <RenderContent loading={isLoading} error={isError}>
          {isSuccess && (
            <Grid container spacing={3}>
              <Grid item xs={12} md={5}>
                <Card sx={style.card}>
                  {/* Header */}
                  <Stack gap={1.5} alignItems="center">
                    {!isMdUp && <Box component={FaRegCircleCheck} sx={style.successIcon} />}
                    <Typography variant="display2" textAlign="center" fontWeight={700}>
                      Event Booked
                    </Typography>
                    {data.paymentStatus !== 'paid' && (
                      <Alert severity="warning">
                        <Typography>Your accommodation will not be confirmed until the full payment is settled.</Typography>
                      </Alert>
                    )}
                  </Stack>

                  {/* Details */}
                  <Stack gap={2} divider={<Divider />}>
                    <Stack gap={1.5}>
                      {(
                        [
                          { label: 'Date', value: moment(data.orderDate).format(), Icon: MdOutlineCalendarToday },
                          { label: 'Customer', value: `${data.user!.firstName} ${data.user!.lastName}`, Icon: MdPersonOutline },
                          { label: 'Payment Method', value: formatToTitleCase(data.paymentType), Icon: MdOutlinePayment },
                        ] as TListItem[]
                      ).map((item) => createListItem(item))}
                    </Stack>
                    <Stack gap={1.5}>
                      {(
                        [
                          { label: 'Booking Id', value: `#${data.id}`, Icon: MdOutlineArticle },
                          { label: 'Total', value: <DisplayPrice price={data.totalAmountInDisplayCurrency} />, Icon: BiDollar },
                        ] as TListItem[]
                      ).map((item) => createListItem(item))}
                    </Stack>
                    <Stack direction="row" divider={<Divider orientation="vertical" flexItem />} sx={style.countBox}>
                      {(
                        [
                          { label: 'Room', value: data.accommodationInfo.length, Icon: MdOutlineHotel },
                          { label: 'Guest', value: data.guestDetails.length, Icon: TbUsersGroup },
                          { label: 'Visa', value: data.guestDetails.filter((item) => item.visaAssistanceRequired).length, Icon: PiIdentificationBadge },
                        ] as TListItem[]
                      ).map((item, index) => (
                        <Stack sx={style.countBoxItem} key={index}>
                          <item.Icon className="icon-xl" />
                          <Typography fontWeight={500}>
                            {item.value} {item.label}
                          </Typography>
                        </Stack>
                      ))}
                    </Stack>
                  </Stack>

                  {/* Action */}
                  <Button variant="contained" size="large" fullWidth component={Link} href={`/customer/my-bookings/edit/${bookingId}`}>
                    Continue to Flight & Visa Details
                  </Button>
                </Card>
              </Grid>
              {isMdUp && (
                <Grid item xs>
                  <Stack sx={style.imageBox}>
                    <ThankYouImage />
                  </Stack>
                </Grid>
              )}
            </Grid>
          )}
        </RenderContent>
      </Container>
    </>
  )
}

BookingThankYou.rootLayoutProps = {
  title: 'Event Booked',
  pageType: 'protected',
  roles: ['customer'],
}

export default BookingThankYou

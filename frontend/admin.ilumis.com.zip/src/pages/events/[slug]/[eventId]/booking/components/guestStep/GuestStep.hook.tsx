import { useState } from 'react'
import { useRouter } from 'next/router'
import { MdDelete, MdEdit } from 'react-icons/md'
import { GridActionsCellItem, GridColDef } from '@mui/x-data-grid'

import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import GuestFormPopup from './components/GuestFormPopup/GuestFormPopup.component'
import { useGetBookingDetailsByEventQuery } from '@/redux/api/booking.api'
import { useDeleteGuestMutation } from '@/redux/api/guest.api'
import { TGuest } from '@/types/Guest.type'

export const useColumns = () => {
  const router = useRouter()
  const eventId = Number(router.query.eventId)

  const [deleteItemId, setDeleteItemId] = useState<number | null>(null)
  const [editItemId, setEditItemId] = useState<number | null>(null)

  const [deleteGuest, { isLoading }] = useDeleteGuestMutation()
  const { data: bookingDetails } = useGetBookingDetailsByEventQuery(eventId)

  const columns: GridColDef<TGuest & { serialNumber: number }>[] = [
    { field: 'serialNumber', headerName: 'SN', sortable: false, minWidth: 50, width: 50, align: 'center', headerAlign: 'center' },
    { field: 'name', headerName: 'Passport Name', sortable: false, flex: 1, minWidth: 200, width: 200, renderCell: ({ row }) => `${row.passportFirstName} ${row.passportLastName}` },
    { field: 'passportNumber', headerName: 'Passport Number', sortable: false, flex: 1, minWidth: 200, width: 200 },
    { field: 'role', headerName: 'Role', sortable: false, flex: 1, minWidth: 150, width: 150 },
    {
      field: 'actions',
      headerName: 'Actions',
      sortable: false,
      minWidth: 80,
      width: 80,
      align: 'center',
      type: 'actions',
      getActions: ({ row, id }) => [
        <GridActionsCellItem key="edit" label="Edit" icon={<MdEdit />} onClick={() => setEditItemId(row.id)} />,
        <GridActionsCellItem key="delete" label="Delete" icon={<MdDelete />} onClick={() => setDeleteItemId(row.id)} />,
        ...(id === deleteItemId
          ? [
              <ConfirmationPopup
                key="deletePopup"
                heading="Delete guest"
                subheading={`Sure to delete "${row.passportFirstName} ${row.passportLastName}" guest?`}
                acceptButtonText="Delete"
                loading={isLoading}
                onCancel={() => setDeleteItemId(null)}
                onAccept={() =>
                  deleteGuest({ guestId: row.id, eventId: Number(router.query.eventId) })
                    .unwrap()
                    .then((_) => setDeleteItemId(null))
                }
              />,
            ]
          : []),
        ...(id === editItemId ? [<GuestFormPopup open key="editPopup" isEditMode={true} data={bookingDetails!} guestId={id as number} onCancel={() => setEditItemId(null)} />] : []),
      ],
    },
  ]

  return columns
}

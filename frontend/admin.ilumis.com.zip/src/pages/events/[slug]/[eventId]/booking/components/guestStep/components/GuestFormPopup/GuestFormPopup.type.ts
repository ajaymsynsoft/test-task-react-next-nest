import { BookingDTO } from '@/dto/Booking.dto'

export type GuestFormPopupProps = {
  open: boolean
  onCancel: () => void
} & (
  | {
      isEditMode: false
      data: BookingDTO | null | undefined
      guestId?: void
    }
  | {
      isEditMode: true
      data: BookingDTO
      guestId: number
    }
)

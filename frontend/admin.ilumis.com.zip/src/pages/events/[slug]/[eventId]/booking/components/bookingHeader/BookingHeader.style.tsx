import { StepConnector, stepConnectorClasses, styled } from '@mui/material'
import { Style } from '@/types'

export const style: Style = {
  root: {
    bgcolor: 'background.bg2',
    py: 4,
    mt: 'calc(var(--header-bottom-margin) * -1)',
    mb: 'var(--section-spacing)',
  },
  content: {
    alignItems: 'center',
    textAlign: 'center',
    gap: 1,
  },
  iconBox: {
    '--size': '78px',
    '--border-width': '8px',
    width: 'var(--size)',
    height: 'var(--size)',
    mb: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: '100%',
    bgcolor: 'background.default',
    position: 'relative',
  },
  icon: {
    fontSize: '30px !important',
  },
  circularProgress: {
    width: 'calc(var(--size) + var(--border-width)) !important',
    height: 'calc(var(--size) + var(--border-width)) !important',
    position: 'absolute',
    top: 'calc(var(--border-width) / 2 * -1)',
    left: 'calc(var(--border-width) / 2 * -1)',
  },
  stepper: {
    maxWidth: 700,
    mx: 'auto',
    '.MuiStepLabel-label': {
      fontSize: 'body1.fontSize',
    },
  },
}

export const QontoConnector = styled(StepConnector)(({ theme }) =>
  theme.unstable_sx({
    [`&.${stepConnectorClasses.alternativeLabel}`]: {
      top: 10,
      left: 'calc(-50% + 16px)',
      right: 'calc(50% + 16px)',
    },
    [`&.${stepConnectorClasses.active}`]: {
      [`& .${stepConnectorClasses.line}`]: {
        borderColor: 'primary.light',
      },
    },
    [`&.${stepConnectorClasses.completed}`]: {
      [`& .${stepConnectorClasses.line}`]: {
        borderColor: 'primary.light',
      },
    },
    [`& .${stepConnectorClasses.line}`]: {
      borderColor: 'dividerDark',
      borderTopWidth: 2,
    },
  }),
)

import { useRouter } from 'next/router'
import { LoadingButton } from '@mui/lab'
import { Controller, useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { FormControl, FormHelperText, Grid, InputLabel, DialogTitle, DialogActions, MenuItem, Select, Stack, Dialog, Typography, Divider, DialogContent } from '@mui/material'

import InputField from '@/components/_ui/inputField/InputField.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { TSchema, schema } from './GuestFormPopup.config'
import { GuestFormPopupProps } from './GuestFormPopup.type'
import { useGetEventQuery } from '@/redux/api/event.api'
import { useAddGuestMutation, useUpdateGuestMutation } from '@/redux/api/guest.api'
import { removeSpace } from '@/utils'

export default function GuestFormPopup(props: GuestFormPopupProps) {
  const { onCancel, isEditMode, data, open, guestId } = props
  const router = useRouter()
  const eventId = Number(router.query.eventId)
  const guest = data?.guestDetails?.find((item) => item.id === guestId)

  const { data: event, isLoading, isError } = useGetEventQuery({ eventId })
  const [addGuest] = useAddGuestMutation()
  const [updateGuest] = useUpdateGuestMutation()

  const {
    handleSubmit,
    control,
    getValues,
    setError,
    formState: { isSubmitting },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
    defaultValues: {
      isEditMode,
      eventId,
      orderId: data?.id,
      ...(isEditMode && {
        guestId,
        passportFirstName: guest!.passportFirstName,
        passportLastName: guest!.passportLastName,
        passportNumber: guest!.passportNumber,
        role: guest!.role,
      }),
    },
  })

  const onSubmit = async () => {
    const formData = schema.validateSync(getValues())

    const samePassportNumberGuest = data?.guestDetails?.find((item) => removeSpace(item.passportNumber) === removeSpace(formData.passportNumber) && (isEditMode ? guestId !== item.id : true))
    if (samePassportNumberGuest)
      return setError(
        'passportNumber',
        { message: `"${samePassportNumberGuest.passportFirstName} ${samePassportNumberGuest.passportLastName}" guest already have that passport number`, type: 'validate' },
        { shouldFocus: true },
      )

    if (!isEditMode) await addGuest(formData).unwrap()
    else await updateGuest({ ...formData, guestId: formData.guestId as number, orderId: formData.orderId as number }).unwrap()
    onCancel()
  }

  return (
    <Dialog open={open} fullWidth component="form" maxWidth="sm" onClose={() => !isSubmitting && onCancel()} onSubmit={handleSubmit(onSubmit)} {...{ noValidate: true }}>
      <DialogTitle>{isEditMode ? 'Update' : 'Add'} Guest</DialogTitle>
      <DialogContent dividers>
        <RenderContent loading={isLoading} error={isError}>
          <Grid container component="form" noValidate spacing={2} onSubmit={handleSubmit(onSubmit)}>
            {/* First Name  */}
            <Grid item xs={12} sm={6}>
              <InputField name="passportFirstName" label="First name *" helperText="Must match from passport" control={control} />
            </Grid>

            {/* Last Name  */}
            <Grid item xs={12} sm={6}>
              <InputField name="passportLastName" label="Last name *" helperText="Must match from passport" control={control} />
            </Grid>

            {/* Passport Number */}
            <Grid item xs={12} sm={6}>
              <InputField name="passportNumber" label="Passport number *" control={control} />
            </Grid>

            {/* Select Role */}
            <Grid item xs={12} sm={6}>
              <Controller
                name="role"
                control={control}
                defaultValue={'' as any}
                render={({ fieldState: { error }, field: { ref, ...restField } }) => (
                  <FormControl error={!!error}>
                    <InputLabel>Select role *</InputLabel>
                    <Select {...restField} inputRef={ref} label="Select role *">
                      {event?.roleWiseData.map((item, index) => (
                        <MenuItem value={item.role} key={index}>
                          {item.role}
                        </MenuItem>
                      ))}
                    </Select>
                    <FormHelperText>{error?.message}</FormHelperText>
                  </FormControl>
                )}
              />
            </Grid>
          </Grid>
        </RenderContent>
      </DialogContent>
      <DialogActions>
        <LoadingButton variant="text" disabled={isSubmitting} onClick={onCancel}>
          Cancel
        </LoadingButton>
        <LoadingButton variant="contained" type="submit" loading={isSubmitting}>
          {isEditMode ? 'Update' : 'Save'}
        </LoadingButton>
      </DialogActions>
    </Dialog>
  )
}

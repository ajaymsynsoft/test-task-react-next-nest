import * as yup from 'yup'
import { passportNumberTest, stringTest } from '@/utils'

export const schema = yup.object({
  isEditMode: yup.boolean().required(),
  orderId: yup.number().when('isEditMode', {
    is: true,
    then: (schema) => schema.required(),
    otherwise: (schema) => schema.notRequired(),
  }),
  guestId: yup.number().when('isEditMode', {
    is: true,
    then: (schema) => schema.required(),
    otherwise: (schema) => schema.notRequired(),
  }),
  eventId: yup.number().required(),
  passportFirstName: yup.string().trim().required().max(100).test(stringTest),
  passportLastName: yup.string().trim().required().max(100).test(stringTest),
  passportNumber: yup.string().trim().required().test(passportNumberTest),
  role: yup.string().trim().required(),
})

export type TSchema = yup.InferType<typeof schema>

import { MdOutlineGroupAdd, MdOutlineHotel, MdOutlineAirplaneTicket, MdOutlineArticle } from 'react-icons/md'

import GuestStep from './components/guestStep/GuestStep.component'
import AccommodationStep from './components/accommodationStep/AccommodationStep.component'
import VisaStep from './components/visaStep/VisaStep.component'
import ReviewDetailsStep from './components/reviewDetailsStep/ReviewDetailsStep.component'
import { BookingDTO } from '@/dto/Booking.dto'
import { useReduxSelector } from '@/hooks'

export const useSteps = () => {
  const { isAccommodationEnabled, isVisaEnabled } = useReduxSelector((state) => state.subscription.plan)

  const STEPS = [
    {
      id: 1,
      label: 'Add Guests',
      Icon: MdOutlineGroupAdd,
      Content: GuestStep,
      validateStep: (bookingDetails: BookingDTO | null) => {
        const isValid = !!bookingDetails?.guestDetails?.length
        const message = !isValid ? 'Add minimum 1 guest' : null
        return { isValid, message }
      },
    },
    isAccommodationEnabled && {
      id: 2,
      label: 'Accommodation',
      Icon: MdOutlineHotel,
      Content: AccommodationStep,
      validateStep: (bookingDetails: BookingDTO) => {
        return { isValid: true, message: null }
      },
    },
    isVisaEnabled && {
      id: 3,
      label: 'Visa',
      Icon: MdOutlineAirplaneTicket,
      Content: VisaStep,
      validateStep: (bookingDetails: BookingDTO) => {
        return { isValid: true, message: null }
      },
    },
    {
      id: 4,
      label: 'Review Details',
      Icon: MdOutlineArticle,
      Content: ReviewDetailsStep,
      validateStep: (bookingDetails: BookingDTO) => {
        return { isValid: true, message: null }
      },
    },
  ].filter((item) => item !== false)

  return STEPS
}

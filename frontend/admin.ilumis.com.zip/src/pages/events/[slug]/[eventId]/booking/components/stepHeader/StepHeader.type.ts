export type StepHeaderProps = {
  heading: string
  actions: React.ReactNode
}

import { forwardRef } from 'react'
import { useRouter } from 'next/router'

import RenderContent from '@/components/renderContent/RenderContent.component'
import VisaForm from '../../../../../../../components/_booking/visaForm/VisaForm.component'
import { useGetBookingDetailsByEventQuery } from '@/redux/api/booking.api'

const VisaStep = forwardRef((props, ref) => {
  const router = useRouter()
  const { isLoading, isFetching, isError, data: bookingDetails } = useGetBookingDetailsByEventQuery(Number(router.query.eventId))

  return (
    <RenderContent loading={isLoading} error={isError}>
      {bookingDetails && <VisaForm data={bookingDetails} ref={ref} isViewMode={false} isDataUpdating={isFetching} />}
    </RenderContent>
  )
})

VisaStep.displayName = 'VisaStep'
export default VisaStep

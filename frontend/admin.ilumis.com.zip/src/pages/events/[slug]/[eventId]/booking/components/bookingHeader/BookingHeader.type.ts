export type BookingHeaderProps = {
  activeStepId: number
}

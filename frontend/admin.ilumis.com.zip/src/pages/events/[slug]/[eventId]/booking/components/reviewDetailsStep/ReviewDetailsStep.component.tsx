import { useRouter } from 'next/router'
import { forwardRef, useImperativeHandle } from 'react'
import { Alert } from '@mui/material'

import RenderContent from '@/components/renderContent/RenderContent.component'
import BookingDetails from '@/components/_booking/bookingDetails/BookingDetails.component'
import { useReduxSelector } from '@/hooks'
import { useGetBookingDetailsByEventQuery } from '@/redux/api/booking.api'
import { useGetEventQuery } from '@/redux/api/event.api'

const ReviewDetailsStep = forwardRef((props, ref) => {
  const router = useRouter()
  const organization = useReduxSelector((state) => state.organization)
  const eventApiState = useGetEventQuery({ eventId: Number(router.query.eventId) })
  const { isFetching, isError, data: bookingDetails, isSuccess } = useGetBookingDetailsByEventQuery(Number(router.query.eventId))

  useImperativeHandle(
    ref,
    () => ({
      async handleNextStep() {},
      async handlePrevStep() {},
    }),
    [],
  )

  return (
    <RenderContent loading={isFetching || eventApiState.isLoading} error={isError || eventApiState.isError}>
      {isSuccess && eventApiState.isSuccess && (
        <>
          {/* Message */}
          <Alert severity="warning" sx={{ mb: 5 }}>
            Please review and verify all details, then proceed to pay.
          </Alert>

          {/* Booking Details */}
          <BookingDetails data={{ ...bookingDetails!, event: eventApiState.data! }} headingVariant="h2" slotProps={{ amount: { show: false }, bankDetails: { show: false } }} />
          <Alert severity="info" sx={{ mt: 2 }}>
            Note: Payment will be made in {organization.defaultCurrency.name} ({organization.defaultCurrency.code}).
          </Alert>
        </>
      )}
    </RenderContent>
  )
})

ReviewDetailsStep.displayName = 'ReviewDetailsStep'
export default ReviewDetailsStep

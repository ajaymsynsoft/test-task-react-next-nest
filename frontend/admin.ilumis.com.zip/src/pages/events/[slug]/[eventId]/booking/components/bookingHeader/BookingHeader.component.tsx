import { Box, CircularProgress, Container, Stack, Step, StepLabel, Stepper, Theme, Typography, useMediaQuery } from '@mui/material'

import { BookingHeaderProps } from './BookingHeader.type'
import { QontoConnector, style } from './BookingHeader.style'
import { useSteps } from '../../Booking.hook'

export default function BookingHeader({ activeStepId }: BookingHeaderProps) {
  const steps = useSteps()
  const activeStep = steps!.find((item) => item.id === activeStepId)
  const activeStepIndex = steps.findIndex((item) => item.id === activeStepId)
  const progressPercentage = ((activeStepIndex + 1) / steps.length) * 100
  const isSmUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('sm'))

  return (
    <Stack sx={{ ...style.root }}>
      <Container>
        {isSmUp ? (
          <Stepper activeStep={activeStepIndex} alternativeLabel connector={<QontoConnector />} sx={style.stepper}>
            {steps.map((item, index) => (
              <Step key={index}>
                <StepLabel>{item.label}</StepLabel>
              </Step>
            ))}
          </Stepper>
        ) : (
          <Stack sx={style.content}>
            <Stack sx={style.iconBox}>
              <Box component={activeStep?.Icon} sx={style.icon} />
              <CircularProgress variant="determinate" thickness={2} value={progressPercentage} sx={style.circularProgress} />
            </Stack>
            <Typography>
              {activeStepIndex + 1}/{steps.length}
            </Typography>
            <Typography variant="h2" component="h1">
              {activeStep?.label}
            </Typography>
          </Stack>
        )}
      </Container>
    </Stack>
  )
}

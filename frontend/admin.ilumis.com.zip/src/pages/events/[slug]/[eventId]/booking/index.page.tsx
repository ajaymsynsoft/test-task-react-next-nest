import toast from 'react-hot-toast'
import { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/router'
import { MdKeyboardArrowLeft, MdKeyboardArrowRight } from 'react-icons/md'
import { TabContext, TabPanel } from '@mui/lab'
import { Container, Fade, Stack } from '@mui/material'
import { LoadingButton } from '@mui/lab'

import BookingHeader from './components/bookingHeader/BookingHeader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import SelectPaymentMethod from '@/components/_booking/selectPaymentMethod/SelectPaymentMethod.component'
import { Page } from '@/types'
import { useBookingPaymentMutation, useGetBookingDetailsByEventQuery } from '@/redux/api/booking.api'
import { useSteps } from './Booking.hook'
import { useGetEventQuery } from '@/redux/api/event.api'

const Booking: Page = () => {
  const router = useRouter()
  const eventId = Number(router.query.eventId)
  const stepContentRef = useRef<{ handleNextStep: () => Promise<void>; handlePrevStep: () => Promise<void> }>()
  const [stepChanging, setStepChanging] = useState<'next' | 'previous' | 'checkout' | null>(null)
  const [stepValidating, setStepValidating] = useState(true)
  const [showSelectPaymentMethod, setshowSelectPaymentMethod] = useState(false)

  const steps = useSteps()
  const activeStep = steps.find((item) => item.id === Number(router.query.step)) || steps[0]
  const activeStepIndex = steps.findIndex((item) => item.id === activeStep.id)
  const isLastStep = !steps[activeStepIndex + 1]

  // INFO: preloading event details, that are used in popups
  const eventApiState = useGetEventQuery({ eventId })
  const [bookingPayment] = useBookingPaymentMutation()
  const { isLoading, isSuccess, isFetching, isError, data: bookingDetails } = useGetBookingDetailsByEventQuery(eventId)

  useEffect(() => {
    const validateStep = async () => {
      const completedSteps = steps.slice(0, activeStep.id)
      for (const step of completedSteps) {
        const { isValid } = step.validateStep(bookingDetails!)
        if (!isValid) {
          await router.push({ query: { ...router.query, step: step.id } }, undefined, { shallow: true })
          break
        }
      }
      setStepValidating(false)
    }

    isSuccess && validateStep()
  }, [isSuccess])

  const changeStep = async (direction: 'next' | 'previous') => {
    try {
      const stepOffset = direction === 'next' ? 1 : -1
      const newStepIndex = activeStepIndex + stepOffset
      const newStep = steps[newStepIndex]?.id

      if (newStep) {
        const { isValid, message } = activeStep.validateStep(bookingDetails!)
        if (direction === 'next' && !isValid) return toast.error(message, { position: 'top-center' })

        const handleStep = direction === 'next' ? stepContentRef.current?.handleNextStep : stepContentRef.current?.handlePrevStep

        if (handleStep) {
          setStepChanging(direction)
          await handleStep()
        }

        router.push({ query: { ...router.query, step: newStep } }, undefined, { shallow: true, scroll: true })
      }
    } finally {
      setStepChanging(null)
    }
  }

  return (
    <>
      {/* Header */}
      <BookingHeader activeStepId={activeStep.id} />

      <Container>
        <RenderContent error={isError} loading={isLoading || stepValidating}>
          {!stepValidating && isSuccess && (
            <>
              {/* Content */}
              <TabContext value={String(activeStep.id)}>
                {steps.map((item, index) => (
                  <Stack key={index}>
                    <Fade in key={activeStep.id} timeout={300}>
                      <TabPanel value={String(item.id)}>{<item.Content ref={stepContentRef} />}</TabPanel>
                    </Fade>
                  </Stack>
                ))}
              </TabContext>

              {/* Footer */}
              <Stack direction="row" justifyContent="space-between" gap={2} mt={4}>
                <LoadingButton
                  variant="outlined"
                  startIcon={<MdKeyboardArrowLeft />}
                  loading={stepChanging === 'previous'}
                  disabled={!!stepChanging || isFetching || !steps[activeStepIndex - 1]}
                  onClick={() => changeStep('previous')}
                >
                  Previous
                </LoadingButton>
                {!isLastStep ? (
                  <LoadingButton variant="outlined" endIcon={<MdKeyboardArrowRight />} loading={stepChanging === 'next'} disabled={!!stepChanging || isFetching} onClick={() => changeStep('next')}>
                    Next
                  </LoadingButton>
                ) : (
                  <LoadingButton variant="contained" loading={stepChanging === 'checkout'} disabled={!!stepChanging || isFetching} onClick={() => setshowSelectPaymentMethod(true)}>
                    Proceed to Pay
                  </LoadingButton>
                )}
              </Stack>

              {/* Select Payment Method */}
              {showSelectPaymentMethod && bookingDetails && (
                <SelectPaymentMethod
                  data={bookingDetails}
                  amountPay={bookingDetails.totalAmountInDisplayCurrency}
                  onCancel={() => setshowSelectPaymentMethod(false)}
                  onSubmit={async (formData) => {
                    const { redirectUrl } = await bookingPayment({
                      ...formData,
                      successUrl: `${location.origin}/events/thank-you?bookingId=${bookingDetails.id}`,
                      cancelUrl: `${location.href}&bookingPaymentPopup=true&status=failed`,
                      isPayingUnpaidAmount: false,
                    }).unwrap()

                    window.location.href = redirectUrl
                  }}
                />
              )}
            </>
          )}
        </RenderContent>
      </Container>
    </>
  )
}

Booking.rootLayoutProps = {
  title: 'Booking',
  pageType: 'protected',
  roles: ['customer'],
}

export default Booking

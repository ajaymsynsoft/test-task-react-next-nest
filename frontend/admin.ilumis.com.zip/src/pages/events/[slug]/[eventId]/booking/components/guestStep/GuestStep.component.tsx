import { forwardRef, useImperativeHandle, useState } from 'react'
import { useRouter } from 'next/router'
import { Button, Stack } from '@mui/material'
import { DataGrid } from '@mui/x-data-grid'
import { MdAdd } from 'react-icons/md'

import NoRowMessage from '@/components/noRowMessage/NoRowMessage.component'
import GuestFormPopup from './components/GuestFormPopup/GuestFormPopup.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import StepHeader from '../stepHeader/StepHeader.component'
import { useColumns } from './GuestStep.hook'
import { useGetBookingDetailsByEventQuery } from '@/redux/api/booking.api'
import { addSerialNumber } from '@/utils'

const GuestStep = forwardRef((props, ref) => {
  const router = useRouter()
  const columns = useColumns()
  const eventId = Number(router.query.eventId)
  const [showAddPopup, setShowAddPopup] = useState(false)
  const { isLoading, isFetching, isError, data: bookingDetails } = useGetBookingDetailsByEventQuery(eventId)

  useImperativeHandle(
    ref,
    () => ({
      async handleNextStep() {},
      async handlePrevStep() {},
    }),
    [],
  )

  return (
    <RenderContent loading={isLoading} error={isError}>
      <Stack gap={3}>
        {/* Header */}
        <StepHeader
          heading="Guests"
          actions={
            <Button variant="contained" startIcon={<MdAdd />} disabled={isFetching} onClick={() => setShowAddPopup(true)}>
              Add Guest
            </Button>
          }
        />

        {/* Table */}
        <DataGrid
          hideFooter
          loading={isFetching}
          columns={columns}
          rows={bookingDetails?.guestDetails ? addSerialNumber(bookingDetails.guestDetails, 1, 1000) : []}
          slots={{ noRowsOverlay: () => <NoRowMessage variant="message" message="No guest added" /> }}
        />

        {/* Add Guest Popup */}
        {showAddPopup && <GuestFormPopup open isEditMode={false} data={bookingDetails} key={String(showAddPopup)} onCancel={() => setShowAddPopup(false)} />}
      </Stack>
    </RenderContent>
  )
})

GuestStep.displayName = 'GuestStep'
export default GuestStep

import toast from 'react-hot-toast'
import { forwardRef, useImperativeHandle, useState } from 'react'
import { useRouter } from 'next/router'
import { MdAdd } from 'react-icons/md'
import { Button, Checkbox, Divider, FormControlLabel, Stack } from '@mui/material'

import StepHeader from '../stepHeader/StepHeader.component'
import AccommodationFormPopup from '@/components/_booking/accommodationFormPopup/AccommodationFormPopup.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import AccommodationTable from '@/components/_booking/accommodationTable/AccommodationTable.component'
import ConfirmationPopup from '@/components/confirmationPopup/ConfirmationPopup.component'
import GuestInfoCard from '@/components/_card/guestInfoCard/GuestInfoCard.compoent'
import { useGetBookingDetailsByEventQuery } from '@/redux/api/booking.api'

const AccommodationStep = forwardRef((props, ref) => {
  const router = useRouter()
  const [showAddPopup, setShowAddPopup] = useState(false)
  const { isLoading, isFetching, isError, data: bookingDetails } = useGetBookingDetailsByEventQuery(Number(router.query.eventId))
  const [showConfirmationPopup, setShowConfirmationPopup] = useState(false)
  const [conditionAccept, setConditionAccept] = useState(false)
  const [proceedWithoutBooking, setProceedWithoutBooking] = useState<boolean | null>(null)

  const unbookedGuests = bookingDetails?.guestDetails.filter((item) => !item.hotelRoomTypeId) || []
  const guestText = unbookedGuests.length === 1 ? 'guest' : 'guests'

  useImperativeHandle(
    ref,
    () => ({
      async handleNextStep() {
        if (!unbookedGuests.length) return
        setShowConfirmationPopup(true)
        await new Promise<void>((resolve, reject) => {
          const interval = setInterval(() => {
            setProceedWithoutBooking((value) => {
              if (value === null) return value
              clearInterval(interval)
              setShowConfirmationPopup(false)
              if (value) resolve()
              else reject()
              return null
            })
          }, 100)
        })
      },
      async handlePrevStep() {},
    }),
    [unbookedGuests],
  )

  return (
    <RenderContent loading={isLoading} error={isError}>
      {bookingDetails && (
        <Stack gap={3}>
          {/* Header */}
          <StepHeader
            heading="Hotel Bookings"
            actions={
              <Button variant="contained" startIcon={<MdAdd />} onClick={() => setShowAddPopup(true)}>
                Add Hotel Booking
              </Button>
            }
          />

          {/* Table */}
          <AccommodationTable data={bookingDetails} loading={isFetching} />

          {/* Accommodation Form Popup */}
          {showAddPopup && <AccommodationFormPopup isEditMode={false} data={bookingDetails} key={String(showAddPopup)} onCancel={() => setShowAddPopup(false)} />}

          {/* Unbooked Guests Confirmation Popup */}
          {showConfirmationPopup && (
            <ConfirmationPopup
              key="deletePopup"
              heading={`Hotel not booked for ${unbookedGuests.length} ${guestText}:`}
              acceptButtonText="Proceed without Booking"
              onCancel={() => setProceedWithoutBooking(false)}
              onAccept={() => {
                if (!conditionAccept) return toast.error('Please select the checkbox to continue')
                setProceedWithoutBooking(true)
              }}
              subheading={
                <Stack gap={2} my={1}>
                  <Stack divider={<Divider />} gap={1} p={1.5} borderRadius={1} border={1} borderColor="divider">
                    {unbookedGuests.map((item, index) => (
                      <GuestInfoCard data={item} key={index} />
                    ))}
                  </Stack>
                  <FormControlLabel
                    sx={{ gap: 0.5, alignItems: 'start' }}
                    label="I acknowledge that I have not selected a hotel for the above guests and understand that the organizing committee is not responsible for accommodations."
                    control={<Checkbox onChange={(e, value) => setConditionAccept(value)} />}
                  />
                </Stack>
              }
            />
          )}
        </Stack>
      )}
    </RenderContent>
  )
})

AccommodationStep.displayName = 'AccommodationStep'
export default AccommodationStep

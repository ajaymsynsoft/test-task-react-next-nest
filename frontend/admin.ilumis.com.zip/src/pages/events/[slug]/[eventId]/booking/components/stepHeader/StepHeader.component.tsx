import { Stack, Typography } from '@mui/material'

import { style } from './StepHeader.style'
import { StepHeaderProps } from './StepHeader.type'

export default function StepHeader({ heading, actions }: StepHeaderProps) {
  return (
    <Stack sx={style.root}>
      <Typography variant="h2">{heading}</Typography>
      <Stack gap={1}>{actions}</Stack>
    </Stack>
  )
}

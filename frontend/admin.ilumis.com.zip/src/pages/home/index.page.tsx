import BannerSection from './components/bannerSection/BannerSection.component'
import AboutSection from './components/aboutSection/AboutSection.component'
import BlogSection from './components/blogSection/BlogSection.component'
import ContactSection from './components/contactSection/ContactSection.component'
import EventsSection from './components/eventsSection/EventsSection.component'
import { useReduxSelector } from '@/hooks'
import { Page } from '@/types'

const Home: Page = () => {
  const organization = useReduxSelector((state) => state.organization)

  if (!organization.id) return null
  else
    return (
      <>
        <BannerSection />
        <EventsSection className="section-spacing-pt" />
        {/* <BlogSection className="section-spacing-mt" /> */}
        <AboutSection className="section-spacing-mt" />
        <ContactSection className="section-spacing-mt" />
      </>
    )
}

Home.rootLayoutProps = {
  title: 'Home',
  pageType: 'public',
}

export default Home

import { Style } from '@/types'

export const style: Style = {
  listItem: {
    gap: 2.5,
    flexDirection: 'row',
    overflow: 'hidden',
    color: 'primary.main',
    ':hover': {
      textDecoration: 'underline',
    },
  },
  listItemLabel: {
    color: 'inherit',
  },
}

import Link from 'next/link'
import { MdCall, MdMailOutline } from 'react-icons/md'
import { FiArrowRight } from 'react-icons/fi'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { LoadingButton } from '@mui/lab'
import { Container, Grid, Stack, Typography } from '@mui/material'

import InputField from '@/components/_ui/inputField/InputField.component'
import { ContactSectionProps } from './ContactSection.type'
import { style } from './ContactSection.style'
import { schema, TSchema } from './ContactSection.config'
import { useContactUsMutation } from '@/redux/api/common.api'
import { useReduxSelector } from '@/hooks'

export default function ContactSection(props: ContactSectionProps) {
  const organization = useReduxSelector((state) => state.organization)
  const [contactUs] = useContactUsMutation()
  const {
    control,
    handleSubmit,
    reset,
    formState: { isSubmitting },
  } = useForm<TSchema>({ resolver: yupResolver(schema) })

  const onSubmit = async (data: TSchema) => {
    await contactUs(data).unwrap()
    reset()
  }

  return (
    <Stack {...props} component="section">
      <Container>
        <Grid container spacing={4}>
          {/* Content */}
          <Grid item xs={12} sm={6}>
            <Stack gap={2.5}>
              <Stack gap={1}>
                <Typography variant="subtitle">CONTACT US</Typography>
                <Typography variant="display2">Let's talk</Typography>
              </Stack>

              <Typography>Blandit amet at proin pulvinar suspendisse pretium purus rhoncus. Elementum ornare tincidunt orci.</Typography>

              <Stack gap={1.5}>
                <Stack sx={style.listItem} component={Link} href={`tel:${organization.phone}`}>
                  <MdCall />
                  <Typography sx={style.listItemLabel}>{organization.phone}</Typography>
                </Stack>
                <Stack sx={style.listItem} component={Link} href={`mailto:${organization.email}`}>
                  <MdMailOutline />
                  <Typography sx={style.listItemLabel}>{organization.email}</Typography>
                </Stack>
              </Stack>
            </Stack>
          </Grid>

          {/* Form */}
          <Grid container item xs={12} sm={6} spacing={2.5} component="form" onSubmit={handleSubmit(onSubmit)}>
            {/* Name */}
            <Grid item xs={12} sm={6}>
              <InputField variant="standard" name="name" placeholder="Name *" control={control} />
            </Grid>

            {/* Email */}
            <Grid item xs={12} sm={6}>
              <InputField variant="standard" name="email" placeholder="Email *" control={control} />
            </Grid>

            {/* Message */}
            <Grid item xs={12}>
              <InputField variant="standard" name="message" placeholder="Message *" control={control} multiline minRows={2} maxRows={10} />
            </Grid>

            {/* Action */}
            <Grid item xs={12} textAlign="right">
              <LoadingButton variant="rounded" type="submit" loading={isSubmitting} endIcon={<FiArrowRight />}>
                Send
              </LoadingButton>
            </Grid>
          </Grid>
        </Grid>
      </Container>
    </Stack>
  )
}

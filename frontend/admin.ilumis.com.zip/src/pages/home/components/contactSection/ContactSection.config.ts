import * as yup from 'yup'
import { stringTest, emailTest } from '@/utils'

export const schema = yup.object({
  name: yup.string().trim().required().max(150).test(stringTest),
  email: yup.string().email().trim().required().max(300).test(emailTest),
  message: yup.string().trim().required().max(1000, 'Explain under 1000 characters').test(stringTest),
})

export type TSchema = yup.InferType<typeof schema>

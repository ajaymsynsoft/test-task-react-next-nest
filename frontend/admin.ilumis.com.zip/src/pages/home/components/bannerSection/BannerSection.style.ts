import { Style } from '@/types'
import { HEADER_HEIGHT } from '@/layouts/rootLayout/RootLayout.config'

export const style: Style = {
  root: {
    bgcolor: 'background.bg1',
    minHeight: { xs: 'unset', sm: `calc(100vh - ${HEADER_HEIGHT}px)` },
    mt: 'calc(-1 * var(--header-bottom-margin))',
    position: 'relative',
    zIndex: 1,
    '.banner': {
      zIndex: -2,
    },
    ':before': {
      content: `''`,
      position: 'absolute',
      inset: 0,
      bgcolor: 'rgba(0, 0, 0, .45)',
      zIndex: -1,
    },
  },
  container: {
    py: 10,
    minHeight: 'inherit',
    display: 'flex',
    flexFlow: 'column',
    justifyContent: 'center',
    alignItems: 'start',
    color: 'white',
  },
  notSetupContent: {
    width: 1,
    textAlign: 'center',
    gap: 1.5,
    alignItems: 'center',
  },
  setupContent: {
    alignItems: 'start',
    gap: 2,
  },
  heading: {
    whiteSpace: 'pre-wrap',
    color: 'inherit',
  },
  subheading: {
    whiteSpace: 'pre-wrap',
    color: 'inherit',
    fontWeight: 400,
  },
  button: {
    mt: 3,
  },
  setupInstruction: {
    border: 1,
    bgcolor: 'rgb(255, 255, 255, .1)',
    borderColor: 'rgb(255, 255, 255, .4)',
    borderRadius: 10,
    p: 1,
  },
}

import Image from 'next/image'
import { FiArrowRight } from 'react-icons/fi'
import { Button, Container, Stack, SxProps, Typography } from '@mui/material'

import bgDefaultImage from '@/../public/images/default-banner-bg.jpg'
import { useReduxSelector } from '@/hooks'
import { style } from './BannerSection.style'
import { BannerSectionProps } from './BannerSection.type'

export default function BannerSection(props: BannerSectionProps) {
  const organization = useReduxSelector((state) => state.organization)
  const isBannerSetup = organization.bannerImage && organization.bannerHeading

  return (
    <Stack {...props} sx={{ ...style.root, ...props.sx } as SxProps} component="section">
      <Container sx={style.container}>
        {isBannerSetup ? (
          <Stack sx={style.setupContent}>
            <Typography variant="display1" component="h1" sx={style.heading}>
              {organization.bannerHeading}
            </Typography>
            {organization.bannerSubHeading && (
              <Typography variant="h3" component="strong" sx={style.subheading}>
                {organization.bannerSubHeading}
              </Typography>
            )}
            <Button variant="rounded" color="inherit" component="a" href="#events-section" sx={style.button} endIcon={<FiArrowRight />}>
              Join The Event
            </Button>
          </Stack>
        ) : (
          <Stack sx={style.notSetupContent}>
            <Typography variant="display1" color="inherit">
              Banner not setup{' '}
            </Typography>
            <Typography variant="subtitle" sx={style.setupInstruction}>
              Setup Banner From &nbsp; Dashboard &gt; Settings &gt; Organization
            </Typography>
          </Stack>
        )}
      </Container>
      <Image src={isBannerSetup ? organization.bannerImage! : bgDefaultImage.src} fill alt="banner" className="banner" />
    </Stack>
  )
}

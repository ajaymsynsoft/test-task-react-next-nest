import { StackProps } from '@mui/material'

export type BannerSectionProps = StackProps & {}

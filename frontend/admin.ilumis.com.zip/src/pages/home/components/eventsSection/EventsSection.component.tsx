import Link from 'next/link'
import { Container, Grid, Stack, Typography, Alert, Button } from '@mui/material'

import RenderContent from '@/components/renderContent/RenderContent.component'
import EventCard from '@/components/_card/eventCard/EventCard.component'
import { EventSectionProps } from './EventsSection.type'
import { useGetPublicEventsListQuery } from '@/redux/api/event.api'

export default function EventsSection(props: EventSectionProps) {
  const { data: events, isLoading, isError, isUninitialized } = useGetPublicEventsListQuery({ pageNo: 1, pageSize: 4, status: 'active' })

  return (
    <Stack {...props} component="section" id="events-section">
      <Container>
        {/* Heading */}
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={3} gap={3}>
          <Typography variant="display2">Our Events</Typography>
          <Button variant="outlined" component={Link} href="/events">
            View all
          </Button>
        </Stack>

        {/* Events */}
        <RenderContent error={isError} loading={isUninitialized || isLoading}>
          {events?.list.length ? (
            <Grid container spacing={3}>
              {events.list.map((item, index) => (
                <Grid item xs={12} md={6} key={index}>
                  <EventCard data={item} />
                </Grid>
              ))}
            </Grid>
          ) : (
            <Alert variant="outlined" severity="info">
              No upcoming events available at the moment
            </Alert>
          )}
        </RenderContent>
      </Container>
    </Stack>
  )
}

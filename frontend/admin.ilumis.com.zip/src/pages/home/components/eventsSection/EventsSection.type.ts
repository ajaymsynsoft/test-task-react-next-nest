import { StackProps } from '@mui/material'

export type EventSectionProps = StackProps & {}

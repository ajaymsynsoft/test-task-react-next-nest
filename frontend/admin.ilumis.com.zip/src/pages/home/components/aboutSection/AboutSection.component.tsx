import Image from 'next/image'
import { Container, Grid, Stack, Theme, Typography, useMediaQuery } from '@mui/material'
import { AboutSectionProps } from './AboutSection.type'
import { useReduxSelector } from '@/hooks'

export default function AboutSection(props: AboutSectionProps) {
  const organization = useReduxSelector((state) => state.organization)
  const isMdUp = useMediaQuery((theme: Theme) => theme.breakpoints.up('md'))

  const aboutImage = <Image src="/images/games/5.jpg" alt="game" width={600} height={600} style={{ display: 'flex', borderRadius: '12px' }} />

  return (
    <Stack {...props} component="section">
      <Container>
        <Grid container spacing={4} wrap="wrap-reverse">
          {/* Content */}
          <Grid item xs={12} md={6}>
            <Stack gap={2.5}>
              <Stack gap={1}>
                <Typography variant="subtitle">ABOUT US</Typography>
                <Typography variant="display2">{organization.organizationName}</Typography>
              </Stack>
              {!isMdUp && <Stack>{aboutImage}</Stack>}
              <Stack gap={1.75}>
                <Typography>
                  Following the resolution issued by His Highness Shaikh Nasser bin Hamad Al Khalifa, Chairman of the Supreme Council for Youth and Sport, and representative for His Majesty the King for charity work and Youth
                  Affairs, as an official entity to include and support all athletic competencies of People with Impairment.
                </Typography>
                <Typography>Following its establishment, the committee has been tasked with fulfilling several important objectives.</Typography>
                <Typography>
                  The Bahrain Paralympic Committee proudly works side-by-side with the many different organizations that are dedicated to supporting communities with the different impairments faced by our community and
                  athletes in sports through various means.
                </Typography>
              </Stack>
            </Stack>
          </Grid>

          {/* Image */}
          {isMdUp && (
            <Grid item xs={12} md={6}>
              {aboutImage}
            </Grid>
          )}
        </Grid>
      </Container>
    </Stack>
  )
}

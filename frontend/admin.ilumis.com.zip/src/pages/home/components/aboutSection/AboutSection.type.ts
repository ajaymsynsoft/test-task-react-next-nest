import { StackProps } from '@mui/material'

export type AboutSectionProps = StackProps & {}

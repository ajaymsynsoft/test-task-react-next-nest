import { Container, Grid, Stack, Typography, Alert, Button } from '@mui/material'

import RenderContent from '@/components/renderContent/RenderContent.component'
import BlogCard from '@/components/_card/blogCard/BlogCard.component'
import BLOG_DATA from './BlogSection.data.json'
import { BlogSectionProps } from './BlogSection.type'

export default function BlogSection(props: BlogSectionProps) {
  return (
    <Stack {...props} component="section">
      <Container>
        {/* Heading */}
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={3} gap={3}>
          <Typography variant="display2">Last Announcements</Typography>
          <Button variant="outlined">View all</Button>
        </Stack>

        {/* Blogs */}
        <RenderContent error={false} loading={false}>
          {BLOG_DATA.length ? (
            <Grid container spacing={3}>
              {BLOG_DATA.map((item, index) => (
                <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
                  <BlogCard data={item} />
                </Grid>
              ))}
            </Grid>
          ) : (
            <Alert variant="outlined" severity="info">
              No announcements available at the moment
            </Alert>
          )}
        </RenderContent>
      </Container>
    </Stack>
  )
}

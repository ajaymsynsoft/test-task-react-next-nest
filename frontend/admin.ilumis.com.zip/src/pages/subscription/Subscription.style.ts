import { Style } from '@/types'

export const style: Style = {
  plan: {
    p: 4,
    borderRadius: 2,
    bgcolor: 'background.default',
    border: 1,
    borderColor: 'dividerDark',
    gap: 4,
  },
  header: {
    textAlign: 'center',
    gap: 1,
    mb: 3,
  },
  planPrice: {
    fontSize: '2.5rem',
  },
  planList: {},
  detailItem: {
    flexDirection: 'row',
    gap: 2.5,
    '.icon': {
      '&.included': {
        color: 'success.light',
      },
      '&.not-included': {
        color: 'error.light',
      },
    },
  },
}

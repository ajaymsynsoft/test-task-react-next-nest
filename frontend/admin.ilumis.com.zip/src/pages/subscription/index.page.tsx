import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import { Container, Divider, Grid, Stack, Typography } from '@mui/material'
import { MdOutlineClose, MdCheck } from 'react-icons/md'
import { LoadingButton } from '@mui/lab'

import RenderContent from '@/components/renderContent/RenderContent.component'
import { style } from './Subscription.style'
import { SubscriptionPlanDTO } from '@/dto'
import { Page } from '@/types'
import { useReduxSelector } from '@/hooks'
import { useCreateCheckoutSessionMutation, useGetSubscriptionListQuery } from '@/redux/api/subscription.api'
import { formatNumber } from '@/utils'

const Subcription: Page = () => {
  const router = useRouter()
  const [planBuying, setPlanBuying] = useState<number | null>(null)
  const [createCheckoutUrl, createCheckoutUrlApiState] = useCreateCheckoutSessionMutation()
  const { isLoading, isError, data } = useGetSubscriptionListQuery()
  const profile = useReduxSelector((state) => state.layout.profile)

  // TODO: enable it
  // useEffect(() => {
  //   if (profile.role === 'admin' && profile.isSubscribed) router.push('/')
  // }, [])

  const handleBuyPlan = async (plan: SubscriptionPlanDTO, index: number) => {
    try {
      setPlanBuying(index)
      const response = await createCheckoutUrl({
        subscriptionPlanId: plan.id,
        successUrl: `${window.location.origin}/subscription/thank-you`,
        cancelUrl: `${window.location.origin}/subscription/error`,
      }).unwrap()
      window.location.href = response.sessionUrl
    } catch (error) {
      setPlanBuying(null)
    }
  }

  // TODO: enable it
  // if (profile.role === 'admin' && profile.isSubscribed) return null
  // else
  return (
    <Container className="section-spacing-my">
      <style global jsx>{`
        main {
          display: flex;
          justify-content: center;
          align-items: center;
        }
      `}</style>

      <RenderContent loading={isLoading} error={isError}>
        <Grid container justifyContent="center" spacing={3}>
          {/* Heading */}
          <Grid item xs={12}>
            <Stack sx={style.header}>
              <Typography variant="display1">Subscribe a plan</Typography>
              <Typography>Subscribe to unlock the dashboard</Typography>
            </Stack>
          </Grid>

          {data?.map((item, index) => {
            const isPopular = index == 1

            return (
              <Grid item key={index} xs={12} sm={6} md={4}>
                <Stack sx={style.plan}>
                  {/* Plan Heading */}
                  <Stack textAlign="center" gap={1}>
                    <Typography variant="h2">{item.name}</Typography>
                    <Typography variant="h1" sx={style.planPrice}>
                      ${formatNumber(item.amount)}
                    </Typography>
                    <Typography>{item.duration} &nbsp;Month</Typography>
                  </Stack>

                  {/* Buy */}
                  <LoadingButton
                    size="large"
                    loading={planBuying === index && createCheckoutUrlApiState.isLoading}
                    disabled={typeof planBuying === 'number'}
                    variant={isPopular ? 'contained' : 'outlined'}
                    onClick={() => handleBuyPlan(item, index)}
                  >
                    Subscribe Now
                  </LoadingButton>

                  {/* Plan Detail List */}
                  <Stack gap={1} sx={style.planList} divider={<Divider />}>
                    <DetailItem included={!!item.noOfEvents} content={`${item.noOfEvents} Events can add`} />
                    <DetailItem included={!!item.noOfStaffs} content={`${item.noOfStaffs} Staffs can add`} />
                    <DetailItem included={item.isTicketingSystemEnabled} content="Ticketing system" />
                    <DetailItem included={item.isAccreditationEnabled} content="Accreditation system" />
                    <DetailItem included={item.isVisaEnabled} content="Visa management" />
                    <DetailItem included={item.isAccommodationEnabled} content="Accommodation management" />
                  </Stack>
                </Stack>
              </Grid>
            )
          })}
        </Grid>
      </RenderContent>
    </Container>
  )
}

function DetailItem(props: { included: boolean; content: React.ReactNode }) {
  const { included, content } = props

  return (
    <Stack sx={style.detailItem}>
      {included ? <MdCheck className="icon included" /> : <MdOutlineClose className="icon not-included" />}
      <Typography>{content}</Typography>
    </Stack>
  )
}

Subcription.rootLayoutProps = {
  title: 'Subcriptions Plan',
  pageType: 'protected',
  roles: ['admin'],
}

export default Subcription

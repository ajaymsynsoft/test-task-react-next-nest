import Link from 'next/link'
import { useEffect } from 'react'
import { useRouter } from 'next/router'
import { Button, Container, Typography } from '@mui/material'

import FullPageMessage from '@/components/fullPageMessage/FullPageMessage.component'
import FullPageLoader from '@/components/fullPageLoader/FullPageLoader.component'
import RenderContent from '@/components/renderContent/RenderContent.component'
import { Page } from '@/types'
import { useCreateSubscriptionMutation, useLazyGetSubscriptionPlanQuery } from '@/redux/api/subscription.api'

const SubscriptionThankYou: Page = () => {
  const router = useRouter()
  const [createSubscription, createSubscriptionApiState] = useCreateSubscriptionMutation()
  const [getSubscriptionPlan, subscriptionPlanApiState] = useLazyGetSubscriptionPlanQuery()

  useEffect(() => {
    const handleCreateSubscription = async () => {
      await createSubscription({ sessionId: router.query.session_id as string })
      router.replace({ query: {} }, undefined, { shallow: true })
      await getSubscriptionPlan()
    }

    if (router.query.success === 'true') handleCreateSubscription()
    else router.replace('/')
  }, [])

  if (createSubscriptionApiState.isError || subscriptionPlanApiState.isError) {
    return (
      <Container>
        <RenderContent loading={false} error>
          ignore
        </RenderContent>
      </Container>
    )
  }

  return subscriptionPlanApiState.isUninitialized || subscriptionPlanApiState.isFetching ? (
    <FullPageLoader>
      <Typography variant="h3">Setting up your organization...</Typography>
    </FullPageLoader>
  ) : (
    <FullPageMessage
      type="success"
      heading="Plan Subscribed Successfully"
      ActionButton={
        <Button variant="contained" href="/dashboard/home" component={Link}>
          Go to Dashboard
        </Button>
      }
    />
  )
}

SubscriptionThankYou.rootLayoutProps = {
  title: 'Plan Subscribed Successfully',
  pageType: 'protected',
  roles: ['admin'],
}

export default SubscriptionThankYou

import Link from 'next/link'
import { Button } from '@mui/material'

import FullPageMessage from '@/components/fullPageMessage/FullPageMessage.component'
import { Page } from '@/types'

const SubscriptionError: Page = () => {
  // TODO: handle redirect conditions
  return (
    <FullPageMessage
      type="error"
      heading="Payment failed"
      ActionButton={
        <Button variant="contained" href="/subscription" component={Link}>
          Try Again
        </Button>
      }
    />
  )
}

SubscriptionError.rootLayoutProps = {
  title: 'Thank You',
  pageType: 'protected',
  roles: ['admin'],
}

export default SubscriptionError

export { default } from '@/pages/home/index.page'

import puppeteer from 'puppeteer'
import { NextApiRequest, NextApiResponse } from 'next'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const bookingId = req.query.bookingId as string
      const type = req.query.type as string

      const protocol = req.headers.referer?.startsWith('https') ? 'https' : 'http'
      const origin = `${protocol}://${req.headers.host}`

      const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'] })
      const page = await browser.newPage()

      await page.setCookie(...Object.keys(req.cookies).map((item) => ({ name: item, value: req.cookies[item]!, domain: req.headers.host! })))
      await page.goto(`${origin}/pdf-maker/booking/${bookingId}?type=${type}`, { waitUntil: 'networkidle0' })

      const pdfBuffer = await page.pdf({
        format: 'A4',
        printBackground: true,
        margin: {
          left: 30,
          right: 30,
          bottom: 15,
          top: 15,
        },
      })

      await browser.close()

      res.setHeader('Content-Type', 'application/pdf')
      res.setHeader('Content-Disposition', 'attachment; filename=output.pdf')
      res.status(200).send(pdfBuffer)
    } catch (error) {
      console.error('Error generating PDF:', error)
      res.status(500).json({ error: 'Error generating PDF' })
    }
  } else {
    res.status(405).json({ error: 'Method not allowed' })
  }
}

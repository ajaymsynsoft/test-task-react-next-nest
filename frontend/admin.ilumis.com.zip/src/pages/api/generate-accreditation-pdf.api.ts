import puppeteer from 'puppeteer'
import archiver from 'archiver'
import { NextApiRequest, NextApiResponse } from 'next'

export default async function handler(req: Request, res: NextApiResponse) {
  if (req.method === 'POST') {
    try {
      const { templates, width, height } = req.body

      const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'] })
      const page = await browser.newPage()

      if (templates.length === 1) {
        await page.setContent(templates[0].html, { waitUntil: 'networkidle0' })

        const pdfBuffer = await page.pdf({
          height,
          width,
          printBackground: true,
        })

        await browser.close()

        res.setHeader('Content-Type', 'application/pdf')
        res.setHeader('Content-Disposition', `attachment; filename=${templates[0].fileName}.pdf`)
        res.send(pdfBuffer)
      } else {
        const zip = archiver('zip')
        res.setHeader('Content-Type', 'application/zip')
        res.setHeader('Content-Disposition', 'attachment; filename=output.zip')
        zip.pipe(res)

        for (const template of templates) {
          await page.setContent(template.html, { waitUntil: 'networkidle0' })

          const pdfBuffer = await page.pdf({
            height,
            width,
            printBackground: true,
          })

          zip.append(pdfBuffer, { name: `${template.fileName}.pdf` })
        }

        await browser.close()
        await zip.finalize()
      }
    } catch (error) {
      console.error('Error generating PDF:', error)
      res.status(500).json({ error: 'Error generating PDF' })
    }
  } else {
    res.status(405).json({ error: 'Method not allowed' })
  }
}

export interface Request extends NextApiRequest {
  body: {
    templates: { html: string; fileName: string }[]
    width: string
    height: string
  }
}

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '4mb',
    },
  },
}

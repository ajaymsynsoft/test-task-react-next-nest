import * as yup from 'yup'
import { emailTest, passwordTest } from '@/utils'

export const schema = yup.object({
  email: yup.string().email().trim().required().max(300).test(emailTest),
  otp: yup.string().required().length(4, 'Enter valid OTP'),
  password: yup.string().trim().required().test(passwordTest).max(100),
  confirmPassword: yup
    .string()
    .trim()
    .required()
    .oneOf([yup.ref('password')], 'New password and confirm password is different'),
})

export type TSchema = yup.InferType<typeof schema>

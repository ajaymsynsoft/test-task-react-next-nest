import { useRouter } from 'next/router'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { LoadingButton } from '@mui/lab'
import { yupResolver } from '@hookform/resolvers/yup'
import { MdVisibility, MdVisibilityOff } from 'react-icons/md'
import { IconButton, Stack, Typography, Container, Button } from '@mui/material'

import InputField from '@/components/_ui/inputField/InputField.component'
import { Page } from '@/types'
import { useGenerateOTPMutation, useVerifyOTPAndPasswordMutation } from '@/redux/api/user.api'
import { style } from './ForgotPassword.style'
import { schema, TSchema } from './ForgotPassword.config'

const ForgotPassword: Page = () => {
  const router = useRouter()
  const [step, setStep] = useState<number>(1)
  const [showPassword, setShowPassword] = useState<boolean>(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false)
  const [generateOTP, { isLoading }] = useGenerateOTPMutation()
  const [verifyOTPAndPassword] = useVerifyOTPAndPasswordMutation()

  const {
    control,
    handleSubmit,
    getValues,
    trigger,
    formState: { isSubmitting },
  } = useForm<TSchema>({
    resolver: yupResolver(schema),
  })

  const handleGetOTP = async () => {
    const mail = getValues('email')
    if (!mail) trigger('email')
    const response = await generateOTP({ email: mail }).unwrap()
    setStep(2)
  }

  const onSubmit = async (formData: Partial<TSchema>) => {
    await verifyOTPAndPassword({ email: formData.email!, password: formData.password!, otp: formData.otp! }).unwrap()
    router.replace('/auth/login')
  }

  return (
    <>
      <style global jsx>{`
        main {
          display: flex;
          justify-content: center;
        }
      `}</style>

      <Container className="section-spacing-my">
        <Stack component="form" onSubmit={handleSubmit(onSubmit)} noValidate sx={style.box}>
          <Typography variant="display2" textAlign="center" fontWeight={700}>
            Forgot Password
          </Typography>
          <Stack gap={2}>
            {/* email */}
            {step === 1 && <InputField name="email" label="Email *" control={control} />}

            {step === 2 && (
              <>
                {/* OTP */}
                <InputField name="otp" label="Enter OTP *" type="number" control={control} />

                {/* Password */}
                <InputField
                  name="password"
                  label="New password *"
                  type={showPassword ? 'text' : 'password'}
                  control={control}
                  inputProps={{ autoComplete: 'new-password' }}
                  InputProps={{
                    endAdornment: <IconButton onClick={() => setShowPassword((v) => !v)}>{showPassword ? <MdVisibility /> : <MdVisibilityOff />}</IconButton>,
                  }}
                />
                {/* Confirm Password */}
                <InputField
                  name="confirmPassword"
                  label="Confirm password *"
                  type={showConfirmPassword ? 'text' : 'password'}
                  control={control}
                  inputProps={{ autoComplete: 'new-password' }}
                  InputProps={{
                    endAdornment: <IconButton onClick={() => setShowConfirmPassword((v) => !v)}>{showConfirmPassword ? <MdVisibility /> : <MdVisibilityOff />}</IconButton>,
                  }}
                />
              </>
            )}
            <Stack mt={1}>
              {step === 1 ? (
                <LoadingButton variant="contained" size="large" type="button" fullWidth loading={isLoading} onClick={handleGetOTP}>
                  Send OTP
                </LoadingButton>
              ) : (
                <Stack direction="row" gap={2}>
                  <Button variant="outlined" size="large" fullWidth onClick={() => setStep(1)}>
                    Go Back
                  </Button>
                  <LoadingButton variant="contained" size="large" type="submit" fullWidth loading={isSubmitting}>
                    Submit
                  </LoadingButton>
                </Stack>
              )}
            </Stack>
          </Stack>
        </Stack>
      </Container>
    </>
  )
}

ForgotPassword.rootLayoutProps = {
  pageType: 'auth',
  title: 'Forgot Password',
}

export default ForgotPassword

import * as yup from 'yup'
import { fileTest, IMAGE_EXTENSIONS, passwordTest, phoneTest, stringTest } from '@/utils'

export const schema = yup.object({
  organizationName: yup.string().trim().required().max(300).test(stringTest),
  email: yup.string().email().trim().required().max(300),
  phone: yup.string().trim().required().test(phoneTest),
  logo: yup
    .mixed<string | File>()
    .required()
    .test(fileTest({ required: true, size: 5, extensions: IMAGE_EXTENSIONS, message: { extensions: 'Only image file is accepted' } })),
  theme: yup.object({
    color: yup
      .object({
        primary: yup.string().trim().required().max(20),
      })
      .required(),
  }),
  password: yup.string().trim().required().test(passwordTest).max(100),
  confirmPassword: yup
    .string()
    .trim()
    .required()
    .oneOf([yup.ref('password')], 'Password and confirm password is different'),
})

export type TSchema = yup.InferType<typeof schema>

import { Pagination, PaginationApiResponse } from '@/types'
import { api } from './api.config'
import { AccreditationRequestDTO } from '@/dto/AccreditationRequest.dto'
import { Request as GeneratePdfRequest } from '@/pages/api/generate-accreditation-pdf.api'

export const extendedApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getAccreditationTemplate: builder.query<string, void>({
      query: () => '/v1/Organization/template',
      providesTags: (result, error) => (!error ? [{ type: 'accreditation', id: 'TEMPLATE' }] : []),
    }),

    getAccreditationTemplateList: builder.query<{ id: number; template: string }[], { type: 'customer' | 'internal' }>({
      query: (params) => ({ url: '/v1/Master/templates', params }),
      providesTags: (result, error) => (!error ? [{ type: 'accreditation', id: 'LIST' }] : []),
    }),

    saveAccreditationTemplate: builder.mutation<void, { template: string }>({
      query: (body) => ({ url: '/v1/Organization/template', method: 'PUT', body }),
      invalidatesTags: (result, error) =>
        !error
          ? [
              { type: 'accreditation', id: 'TEMPLATE' },
              { type: 'accreditation', id: 'LIST' },
            ]
          : [],
    }),

    accreditationRequest: builder.mutation<void, Partial<AccreditationRequestDTO>>({
      query: (body) => ({ url: '/v1/Admin/accreditation/template', method: 'POST', body }),
    }),

    getAccreditationRequestList: builder.query<PaginationApiResponse<any>, Pagination>({
      query: (params) => ({ url: '/v1/Admin/accreditation/all', params }),
    }),

    generateAccreditationPdf: builder.mutation<Blob, GeneratePdfRequest['body']>({
      query: (body) => ({
        url: `${location.origin}/api/generate-accreditation-pdf`,
        body,
        method: 'POST',
        headers: { hideToast: 'true' },
        responseHandler: (response) => response.blob(),
      }),
    }),
  }),
})

export const {
  useGetAccreditationTemplateQuery,
  useLazyGetAccreditationTemplateQuery,
  useGetAccreditationTemplateListQuery,
  useSaveAccreditationTemplateMutation,
  useAccreditationRequestMutation,
  useGetAccreditationRequestListQuery,
  useGenerateAccreditationPdfMutation,
} = extendedApi

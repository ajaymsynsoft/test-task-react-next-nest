import { Pagination, PaginationApiResponse } from '@/types'
import { api } from './api.config'
import { HotelDTO } from '@/dto'

export const extendedApi = api.injectEndpoints({
  endpoints: (builder) => ({
    addHotel: builder.mutation<void, Omit<HotelDTO, 'id' | 'country' | 'roomType'> & { roomType: Omit<HotelDTO['roomType'][0], 'hotelId' | 'id'>[] }>({
      query: (body) => ({ url: '/v1/Hotel', method: 'POST', body }),
      invalidatesTags: (result, error) => (!error ? [{ type: 'hotel', id: 'LIST' }] : []),
    }),

    updateHotel: builder.mutation<void, Omit<HotelDTO, 'country' | 'roomType'> & { roomType: Omit<HotelDTO['roomType'][0], 'hotelId'>[] }>({
      query: ({ id, ...body }) => ({ url: `/v1/Hotel/${id}`, method: 'PUT', body }),
      invalidatesTags: (result, error, { id }) => (!error ? [{ type: 'hotel', id }] : []),
    }),

    deleteHotel: builder.mutation<void, number>({
      query: (id) => ({ url: `/v1/Hotel/${id}`, method: 'DELETE' }),
      invalidatesTags: (result, error, id) =>
        !error
          ? [
              { type: 'hotel', id },
              { type: 'hotel', id: 'LIST' },
            ]
          : [],
    }),

    deleteRoomType: builder.mutation<void, { hotelId: number; roomId: number }>({
      query: ({ hotelId, roomId }) => ({ url: `/v1/Hotel/${hotelId}/RoomType/${roomId}`, method: 'DELETE' }),
      invalidatesTags: (result, error, { hotelId }) => (!error ? [{ type: 'hotel', id: hotelId }] : []),
    }),

    getHotel: builder.query<HotelDTO, number>({
      query: (id) => `/v1/Hotel/${id}`,
      providesTags: (result, error, id) => (!error ? [{ type: 'hotel', id }] : []),
    }),

    getHotelList: builder.query<PaginationApiResponse<HotelDTO>, Pagination>({
      query: (params) => ({ url: `/v1/Hotel/all`, params }),
      providesTags: (result, error) => (!error ? [...result!.list.map(({ id }) => ({ type: 'hotel' as const, id })), { type: 'hotel', id: 'LIST' }] : [{ type: 'hotel', id: 'LIST' }]),
    }),

    getHotelNameList: builder.query<{ id: number; name: string }[], void>({
      query: () => ({ url: '/v1/Hotel/details' }),
      providesTags: (result, error) => (!error ? [...result!.map(({ id }) => ({ type: 'hotel' as const, id })), { type: 'hotel', id: 'LIST' }] : [{ type: 'hotel', id: 'LIST' }]),
    }),

    getRoomAvailability: builder.mutation<number, { eventId: number; hotelId: number; roomTypeId: number }>({
      query: (body) => ({ url: '/v1/Hotel/getRoomAvailability', body, method: 'POST', headers: { hideToast: 'true' } }),
    }),
  }),
})

export const { useGetHotelQuery, useGetHotelListQuery, useAddHotelMutation, useUpdateHotelMutation, useDeleteHotelMutation, useGetHotelNameListQuery, useDeleteRoomTypeMutation, useGetRoomAvailabilityMutation } = extendedApi

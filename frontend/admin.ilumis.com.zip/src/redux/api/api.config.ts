import { getCookie } from '@/utils'
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { RootState } from '../store/store'

export const api = createApi({
  reducerPath: 'apis',
  tagTypes: [
    'profile',
    'organization',
    'staff',
    'event',
    'accreditation',
    'payment',
    'hotel',
    'notification',
    'currency',
    'subscription',
    'booking',
    'customer',
    'visa',
    'ticket',
    'ticketMessages',
    'wallet',
    'internalMember',
    'internalBooking',
  ],
  baseQuery: fetchBaseQuery({
    baseUrl: process.env.NEXT_PUBLIC_API_BASE_URL,
    prepareHeaders: (headers, { getState }) => {
      const state = getState() as RootState

      if (getCookie('token')) headers.set('Authorization', `Bearer ${getCookie('token')}`)
      if (state.organization.id) headers.set('organizationId', String(state.organization.id))

      return headers
    },
  }),
  endpoints: () => ({}),
})

import { api } from './api.config'
import { NotificationDTO } from '@/dto'
import { Pagination, PaginationApiResponse } from '@/types'

export const extendedApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getNotifications: builder.query<PaginationApiResponse<NotificationDTO>, Pagination>({
      query: (params) => ({ url: '/v1/Master/all/notification', params }),
      providesTags: ['notification'],
    }),
  }),
})

export const { useLazyGetNotificationsQuery } = extendedApi

import { api } from './api.config'
import { BookingDTO } from '@/dto/Booking.dto'
import { EventDTO } from '@/dto'
import { Pagination, PaginationApiResponse, PaymentMethods } from '@/types'

export const extendedApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getBookingDetailsByEvent: builder.query<BookingDTO | null, number>({
      query: (eventId) => `/v1/Customer/order/details/${eventId}`,
      providesTags: (result, error, eventId) => (!error ? [{ type: 'booking', eventId }] : []),
    }),

    getBookingsList: builder.query<PaginationApiResponse<TBookingList>, Pagination & { eventId?: number | string; orderDate?: string }>({
      query: (params) => ({ url: '/v1/Master/bookings/all', params }),
      providesTags: (result, error) => (!error ? [...result!.list.map(({ id }) => ({ type: 'booking' as const, id })), { type: 'booking', id: 'LIST' }] : [{ type: 'booking', id: 'LIST' }]),
    }),

    getBooking: builder.query<BookingDTO, number>({
      query: (orderId) => `/v1/Master/booking/${orderId}`,
      providesTags: (result, error, orderId) => (!error ? [{ type: 'booking', id: orderId }] : []),
    }),

    cancelBooking: builder.mutation<void, number>({
      query: (id) => ({ url: `/v1/Customer/cancel/${id}`, method: 'PUT' }),
      invalidatesTags: (result, error, id) =>
        !error
          ? [
              { type: 'booking', id },
              { type: 'booking', id: 'LIST' },
            ]
          : [],
    }),

    bookingPayment: builder.mutation<{ redirectUrl: string }, { orderId: number; useWalletBalance: boolean; paymentType: PaymentMethods; successUrl: string; cancelUrl: string; isPayingUnpaidAmount: boolean }>({
      query: (body) => ({ url: '/v1/Payment/booking', method: 'POST', body, headers: { hideToast: 'true' } }),
    }),

    updateAmount: builder.mutation<void, { bookingId: number; amount: number }>({
      query: (body) => ({ url: '/v1/Payment/status/update', method: 'PUT', body }),
      invalidatesTags: (result, error, { bookingId }) => (!error ? [{ type: 'booking', id: bookingId }] : []),
    }),

    uploadBankReceipt: builder.mutation<void, { bookingId: number; bankReceiptImage: string }>({
      query: (body) => ({ url: '/v1/Customer/upload/bankReceipt', method: 'PUT', body }),
      invalidatesTags: (result, error, { bookingId }) => (!error ? [{ type: 'booking', id: bookingId }] : []),
    }),

    generateBookingPdf: builder.query<Blob, { bookingId: string; type: 'receipt' | 'invoice' }>({
      query: (params) => ({
        url: `${location.origin}/api/generate-booking-pdf`,
        params,
        headers: { hideToast: 'true' },
        responseHandler: (response) => response.blob(),
      }),
      providesTags: (result, error, { bookingId }) => (!error ? [{ type: 'booking', id: bookingId }] : []),
    }),
  }),
})

export type TBookingList = BookingDTO & { event: EventDTO }

export const {
  useGetBookingDetailsByEventQuery,
  useGetBookingsListQuery,
  useGetBookingQuery,
  useBookingPaymentMutation,
  useLazyGenerateBookingPdfQuery,
  useCancelBookingMutation,
  useUpdateAmountMutation,
  useUploadBankReceiptMutation,
} = extendedApi

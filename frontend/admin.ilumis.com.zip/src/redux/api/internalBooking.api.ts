import { api } from './api.config'
import { Pagination, PaginationApiResponse } from '@/types'
import { InternalBookingDTO } from '@/dto'

export const extendedApi = api.injectEndpoints({
  endpoints: (builder) => ({
    addInternalBooking: builder.mutation<void, { memberId: number } & Pick<InternalBookingDTO, 'eventId' | 'hotelId' | 'hotelRoomTypeId' | 'fromDate' | 'toDate' | 'visaAssistanceRequired' | 'visaOfficialLetterRequired'>>({
      query: (body) => ({ url: '/v1/Master/internal/booking', method: 'POST', body }),
      invalidatesTags: (result, error) => (!error ? [{ type: 'internalBooking', id: 'LIST' }] : []),
    }),

    getInternalBookingList: builder.query<PaginationApiResponse<InternalBookingDTO>, Pagination>({
      query: (params) => ({ url: '/v1/Master/internal/bookings/all', params }),
      providesTags: (result, error) => (!error ? [...result!.list.map(({ id }) => ({ type: 'internalBooking' as const, id })), { type: 'internalBooking', id: 'LIST' }] : [{ type: 'internalBooking', id: 'LIST' }]),
    }),

    getInternalBooking: builder.query<InternalBookingDTO, number>({
      query: (id) => `/v1/Master/internal/booking/${id}`,
      providesTags: (result, error, id) => (!error ? [{ type: 'internalBooking', id }] : []),
    }),
  }),
})

export const { useAddInternalBookingMutation, useGetInternalBookingListQuery, useGetInternalBookingQuery } = extendedApi

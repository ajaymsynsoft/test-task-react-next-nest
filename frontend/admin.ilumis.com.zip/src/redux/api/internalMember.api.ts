import { Pagination, PaginationApiResponse } from '@/types'
import { api } from './api.config'
import { InternalMemberDTO } from '@/dto'

export const extendedApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getInternalMemberList: builder.query<PaginationApiResponse<InternalMemberDTO>, Pagination>({
      query: (params) => ({ url: `/v1/Staff/allInternalStaff`, params }),
      providesTags: (result, error) => (!error ? [...result!.list.map(({ id }) => ({ type: 'internalMember' as const, id })), { type: 'internalMember', id: 'LIST' }] : [{ type: 'internalMember', id: 'LIST' }]),
    }),

    addInternalMember: builder.mutation<void, Omit<InternalMemberDTO, 'id' | 'country'>>({
      query: (body) => ({ url: '/v1/Staff/addInternalStaff', method: 'POST', body }),
      invalidatesTags: (result, error) => (!error ? [{ type: 'internalMember', id: 'LIST' }] : []),
    }),

    updateInternalMember: builder.mutation<void, Omit<InternalMemberDTO, 'country'>>({
      query: (body) => ({ url: `/v1/Staff/updateInternalStaff/${body.id}`, method: 'PUT', body }),
      invalidatesTags: (result, error, { id }) => (!error ? [{ type: 'internalMember', id }] : []),
    }),

    getInternalMember: builder.query<InternalMemberDTO, number>({
      query: (id) => `/v1/Staff/getInternalStaffById/${id}`,
      providesTags: (result, error, id) => (!error ? [{ type: 'internalMember', id }] : []),
    }),

    deleteInternalMember: builder.mutation<void, number>({
      query: (id) => ({ url: `/v1/Staff/deleteInternalStaff/${id}`, method: 'DELETE' }),
      invalidatesTags: (result, error, id) =>
        !error
          ? [
              { type: 'internalMember', id },
              { type: 'internalMember', id: 'LIST' },
            ]
          : [],
    }),
  }),
})

export const { useGetInternalMemberListQuery, useAddInternalMemberMutation, useUpdateInternalMemberMutation, useGetInternalMemberQuery, useDeleteInternalMemberMutation } = extendedApi

import { api } from './api.config'
import { WalletDTO } from '@/dto/Wallet.dto'
import { WalletHistoryDTO } from '@/dto/WalletHistory.dto'
import { Pagination, PaginationApiResponse } from '@/types'

export const extendedApi = api.injectEndpoints({
  endpoints: (builder) => ({
    addWalletTopUp: builder.mutation<{ sessionId: string; paymentRedirectUrl: string }, { amount: number; successUrl: string; cancelUrl: string }>({
      query: (body) => ({
        url: '/v1/Customer/wallet/session',
        method: 'POST',
        body,
        headers: { hideToast: 'true' },
      }),
    }),

    getWalletBalance: builder.query<WalletDTO, void>({
      query: () => ({ url: '/v1/Customer/wallet' }),
      providesTags: (result, error) => (!error ? ['wallet'] : []),
    }),

    getWalletHistoryList: builder.query<PaginationApiResponse<WalletHistoryDTO>, Pagination>({
      query: (params) => ({ url: '/v1/Customer/wallet/summary', params }),
      providesTags: (result, error) => (!error ? [...result!.list.map(({ id }) => ({ type: 'wallet' as const, id })), { type: 'wallet', id: 'LIST' }] : [{ type: 'wallet', id: 'LIST' }]),
    }),
  }),
})

export const { useAddWalletTopUpMutation, useGetWalletBalanceQuery, useGetWalletHistoryListQuery } = extendedApi

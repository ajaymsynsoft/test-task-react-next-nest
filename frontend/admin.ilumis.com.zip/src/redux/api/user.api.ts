import { removeCookie } from '@/utils'
import { updateProfile } from '../slice/layout.slice'
import { api } from './api.config'
import { ProfileDTO } from '@/dto'
import { Module } from '@/types'

export const extendedApi = api.injectEndpoints({
  endpoints: (builder) => ({
    profile: builder.query<ProfileDTO & { modules: Record<string, Module> }, void>({
      query: () => '/v1/User/profile',
      providesTags: ['profile'],

      transformResponse(response: any) {
        const modules = response.data.modules.reduce((acc: Record<number, Module>, item: any) => {
          acc[item.id] = {
            id: item.id,
            name: item.name,
            permissions: { add: item.add, delete: item.delete, edit: item.update, view: item.view },
          }
          return acc
        }, {})

        return {
          ...response,
          data: { ...response.data, modules },
        }
      },

      async onQueryStarted(arg, { dispatch, queryFulfilled }) {
        await queryFulfilled
          .then(({ data }) => dispatch(updateProfile(data)))
          .catch((error) => {
            if (error.meta.response?.status === 401) {
              removeCookie('token')
              window.location.replace('/auth/login')
            }
          })
      },
    }),

    updateProfile: builder.mutation<void, Partial<ProfileDTO>>({
      query: (body) => ({ url: '/v1/User/profile/update', method: 'PUT', body }),
      invalidatesTags: (result, error) => (!error ? ['profile'] : []),
    }),

    updateFcmToken: builder.mutation<void, { fcmToken: string; userId: number }>({
      query: (body) => ({ url: '/v1/User/fcmToken/update', method: 'PUT', body, headers: { hideToast: 'true' } }),
      invalidatesTags: (result, error) => (!error ? ['profile'] : []),
    }),

    changePassword: builder.mutation<void, { userId: number; oldPassword: string; password: string; confirmPassword: string }>({
      query: (body) => ({
        url: '/v1/Auth/changePassword',
        method: 'PUT',
        body,
      }),
    }),

    // Forgot Password
    generateOTP: builder.mutation<{ generatedOtp: string }, { email: string }>({
      query: (body) => ({
        url: '/v1/Auth/generateOTP',
        method: 'POST',
        body,
      }),
    }),

    verifyOTPAndPassword: builder.mutation<void, { email: string; otp: string; password: string }>({
      query: (body) => ({
        url: '/v1/Auth/verifyOtpAndPassword',
        method: 'POST',
        body,
      }),
    }),
  }),
})

export const { useLazyProfileQuery, useUpdateProfileMutation, useChangePasswordMutation, useUpdateFcmTokenMutation, useGenerateOTPMutation, useVerifyOTPAndPasswordMutation } = extendedApi

importScripts('https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js')
importScripts('https://www.gstatic.com/firebasejs/8.10.1/firebase-messaging.js')



firebase.initializeApp({
  apiKey: "AIzaSyAURfxDHF-5xZ3uzdojNDFLcnlplXQ5DHo",
  authDomain: "saas-9d4f1.firebaseapp.com",
  projectId: "saas-9d4f1",
  storageBucket: "saas-9d4f1.appspot.com",
  messagingSenderId: "1012259600268",
  appId: "1:1012259600268:web:1d9c1dcfc1454300c808a9",
})


const messaging = firebase.messaging()
messaging.onBackgroundMessage(({ notification }) => { })